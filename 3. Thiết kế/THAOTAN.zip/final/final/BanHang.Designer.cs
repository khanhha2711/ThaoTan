﻿namespace final
{
    partial class BanHang
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(BanHang));
            title = new Panel();
            txtHangHoa = new TextBox();
            HoaDon = new Panel();
            txtThanhToan = new TextBox();
            lbThanhToan = new Label();
            btHuy = new Button();
            btHT = new Button();
            txtThue = new TextBox();
            lbThue = new Label();
            data = new DataGridView();
            STT = new DataGridViewTextBoxColumn();
            MaHH = new DataGridViewTextBoxColumn();
            TenHH = new DataGridViewTextBoxColumn();
            GiaBan = new DataGridViewTextBoxColumn();
            SL = new DataGridViewTextBoxColumn();
            ThanhTien = new DataGridViewTextBoxColumn();
            txtTong = new TextBox();
            lbTong = new Label();
            txtHTTT = new ComboBox();
            date = new DateTimePicker();
            lbHTTT = new Label();
            lbNgay = new Label();
            txtSDT = new TextBox();
            lbSDT = new Label();
            txt_MaDBH = new TextBox();
            lbMaDBH = new Label();
            sqlCommand1 = new Microsoft.Data.SqlClient.SqlCommand();
            sidebar = new Panel();
            btNH = new Button();
            btBH = new Button();
            btCNNCC = new Button();
            btCNKH = new Button();
            btHDN = new Button();
            btHDB = new Button();
            btNo = new Button();
            btHoaDon = new Button();
            btNCC = new Button();
            btKH = new Button();
            btHangHoa = new Button();
            logo = new PictureBox();
            title.SuspendLayout();
            HoaDon.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)data).BeginInit();
            sidebar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)logo).BeginInit();
            SuspendLayout();
            // 
            // title
            // 
            title.BackColor = Color.FromArgb(255, 255, 255);
            title.Controls.Add(txtHangHoa);
            title.Location = new Point(336, 0);
            title.Margin = new Padding(4, 3, 4, 3);
            title.Name = "title";
            title.Size = new Size(1644, 110);
            title.TabIndex = 2;
            // 
            // txtHangHoa
            // 
            txtHangHoa.BorderStyle = BorderStyle.None;
            txtHangHoa.Font = new Font("Arial", 20F, FontStyle.Bold);
            txtHangHoa.ForeColor = Color.FromArgb(0, 43, 92);
            txtHangHoa.Location = new Point(45, 31);
            txtHangHoa.Margin = new Padding(4, 3, 4, 3);
            txtHangHoa.Name = "txtHangHoa";
            txtHangHoa.Size = new Size(352, 39);
            txtHangHoa.TabIndex = 0;
            txtHangHoa.TabStop = false;
            txtHangHoa.Text = "HÓA ĐƠN BÁN HÀNG";
            txtHangHoa.TextChanged += txtHangHoa_TextChanged;
            // 
            // HoaDon
            // 
            HoaDon.BackColor = Color.FromArgb(255, 255, 255);
            HoaDon.Controls.Add(txtThanhToan);
            HoaDon.Controls.Add(lbThanhToan);
            HoaDon.Controls.Add(btHuy);
            HoaDon.Controls.Add(btHT);
            HoaDon.Controls.Add(txtThue);
            HoaDon.Controls.Add(lbThue);
            HoaDon.Controls.Add(data);
            HoaDon.Controls.Add(txtTong);
            HoaDon.Controls.Add(lbTong);
            HoaDon.Controls.Add(txtHTTT);
            HoaDon.Controls.Add(date);
            HoaDon.Controls.Add(lbHTTT);
            HoaDon.Controls.Add(lbNgay);
            HoaDon.Controls.Add(txtSDT);
            HoaDon.Controls.Add(lbSDT);
            HoaDon.Controls.Add(txt_MaDBH);
            HoaDon.Controls.Add(lbMaDBH);
            HoaDon.Location = new Point(372, 144);
            HoaDon.Margin = new Padding(4, 3, 4, 3);
            HoaDon.Name = "HoaDon";
            HoaDon.Size = new Size(1518, 787);
            HoaDon.TabIndex = 3;
            HoaDon.Paint += HoaDon_Paint;
            // 
            // txtThanhToan
            // 
            txtThanhToan.BackColor = SystemColors.InactiveBorder;
            txtThanhToan.Location = new Point(1240, 592);
            txtThanhToan.Name = "txtThanhToan";
            txtThanhToan.Size = new Size(189, 30);
            txtThanhToan.TabIndex = 7;
            txtThanhToan.TextChanged += txtThanhToan_TextChanged;
            // 
            // lbThanhToan
            // 
            lbThanhToan.AutoSize = true;
            lbThanhToan.ForeColor = SystemColors.ActiveCaptionText;
            lbThanhToan.Location = new Point(1110, 595);
            lbThanhToan.Name = "lbThanhToan";
            lbThanhToan.Size = new Size(107, 23);
            lbThanhToan.TabIndex = 16;
            lbThanhToan.Text = "Thanh toán";
            // 
            // btHuy
            // 
            btHuy.BackColor = Color.FromArgb(0, 43, 92);
            btHuy.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHuy.ForeColor = SystemColors.ButtonHighlight;
            btHuy.Location = new Point(1283, 682);
            btHuy.Name = "btHuy";
            btHuy.Size = new Size(146, 45);
            btHuy.TabIndex = 9;
            btHuy.Text = "Hủy bỏ";
            btHuy.UseVisualStyleBackColor = false;
            btHuy.Click += btHuy_Click;
            // 
            // btHT
            // 
            btHT.BackColor = Color.FromArgb(0, 43, 92);
            btHT.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHT.ForeColor = SystemColors.ButtonHighlight;
            btHT.Location = new Point(1093, 682);
            btHT.Name = "btHT";
            btHT.Size = new Size(146, 45);
            btHT.TabIndex = 8;
            btHT.Text = "Hoàn thành";
            btHT.UseVisualStyleBackColor = false;
            btHT.Click += btHT_Click;
            // 
            // txtThue
            // 
            txtThue.BackColor = SystemColors.InactiveBorder;
            txtThue.Location = new Point(557, 592);
            txtThue.Name = "txtThue";
            txtThue.Size = new Size(125, 30);
            txtThue.TabIndex = 6;
            txtThue.TextChanged += thue_TextChanged;
            txtThue.KeyDown += txtThue_KeyDown;
            // 
            // lbThue
            // 
            lbThue.AutoSize = true;
            lbThue.ForeColor = SystemColors.ActiveCaptionText;
            lbThue.Location = new Point(488, 596);
            lbThue.Name = "lbThue";
            lbThue.Size = new Size(53, 23);
            lbThue.TabIndex = 15;
            lbThue.Text = "Thuế";
            // 
            // data
            // 
            data.AllowUserToDeleteRows = false;
            data.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            data.BackgroundColor = Color.White;
            data.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            data.Columns.AddRange(new DataGridViewColumn[] { STT, MaHH, TenHH, GiaBan, SL, ThanhTien });
            data.GridColor = SystemColors.ScrollBar;
            data.Location = new Point(84, 144);
            data.Name = "data";
            data.RowHeadersWidth = 51;
            data.Size = new Size(1345, 368);
            data.TabIndex = 4;
            data.CellEndEdit += data_CellEndEdit;
            // 
            // STT
            // 
            STT.HeaderText = "STT";
            STT.MinimumWidth = 6;
            STT.Name = "STT";
            // 
            // MaHH
            // 
            MaHH.HeaderText = "Mã HH";
            MaHH.MinimumWidth = 6;
            MaHH.Name = "MaHH";
            // 
            // TenHH
            // 
            TenHH.HeaderText = "Tên HHDV";
            TenHH.MinimumWidth = 6;
            TenHH.Name = "TenHH";
            TenHH.ReadOnly = true;
            // 
            // GiaBan
            // 
            GiaBan.HeaderText = "Giá bán";
            GiaBan.MinimumWidth = 6;
            GiaBan.Name = "GiaBan";
            GiaBan.ReadOnly = true;
            // 
            // SL
            // 
            SL.HeaderText = "Số lượng";
            SL.MinimumWidth = 6;
            SL.Name = "SL";
            // 
            // ThanhTien
            // 
            ThanhTien.HeaderText = "Thành Tiền";
            ThanhTien.MinimumWidth = 6;
            ThanhTien.Name = "ThanhTien";
            ThanhTien.ReadOnly = true;
            // 
            // txtTong
            // 
            txtTong.BackColor = SystemColors.InactiveBorder;
            txtTong.Location = new Point(852, 593);
            txtTong.Name = "txtTong";
            txtTong.Size = new Size(189, 30);
            txtTong.TabIndex = 13;
            txtTong.TabStop = false;
            txtTong.TextChanged += txtTong_TextChanged;
            // 
            // lbTong
            // 
            lbTong.AutoSize = true;
            lbTong.ForeColor = SystemColors.ActiveCaptionText;
            lbTong.Location = new Point(739, 596);
            lbTong.Name = "lbTong";
            lbTong.Size = new Size(91, 23);
            lbTong.TabIndex = 12;
            lbTong.Text = "Tổng tiền";
            // 
            // txtHTTT
            // 
            txtHTTT.BackColor = SystemColors.InactiveBorder;
            txtHTTT.FormattingEnabled = true;
            txtHTTT.Items.AddRange(new object[] { "Chuyển khoản", "Tiền mặt" });
            txtHTTT.Location = new Point(289, 592);
            txtHTTT.Name = "txtHTTT";
            txtHTTT.Size = new Size(151, 31);
            txtHTTT.TabIndex = 5;
            // 
            // date
            // 
            date.Format = DateTimePickerFormat.Short;
            date.Location = new Point(1033, 57);
            date.Name = "date";
            date.Size = new Size(142, 30);
            date.TabIndex = 2;
            date.Value = new DateTime(2024, 12, 11, 0, 0, 0, 0);
            date.ValueChanged += date_ValueChanged;
            // 
            // lbHTTT
            // 
            lbHTTT.AutoSize = true;
            lbHTTT.ForeColor = SystemColors.ActiveCaptionText;
            lbHTTT.Location = new Point(83, 596);
            lbHTTT.Name = "lbHTTT";
            lbHTTT.Size = new Size(191, 23);
            lbHTTT.TabIndex = 6;
            lbHTTT.Text = "Hình thức thanh toán";
            // 
            // lbNgay
            // 
            lbNgay.AutoSize = true;
            lbNgay.ForeColor = SystemColors.ActiveCaptionText;
            lbNgay.Location = new Point(910, 64);
            lbNgay.Name = "lbNgay";
            lbNgay.Size = new Size(93, 23);
            lbNgay.TabIndex = 4;
            lbNgay.Text = "Ngày bán";
            // 
            // txtSDT
            // 
            txtSDT.BackColor = SystemColors.InactiveBorder;
            txtSDT.Location = new Point(579, 61);
            txtSDT.Name = "txtSDT";
            txtSDT.Size = new Size(219, 30);
            txtSDT.TabIndex = 1;
            txtSDT.TextChanged += txtSDT_TextChanged;
            txtSDT.KeyDown += txtsdt_KeyDown;
            // 
            // lbSDT
            // 
            lbSDT.AutoSize = true;
            lbSDT.ForeColor = SystemColors.ActiveCaptionText;
            lbSDT.Location = new Point(432, 64);
            lbSDT.Name = "lbSDT";
            lbSDT.Size = new Size(124, 23);
            lbSDT.TabIndex = 0;
            lbSDT.Text = "Số điện thoại";
            lbSDT.Click += lb_MaKH_Click;
            // 
            // txt_MaDBH
            // 
            txt_MaDBH.BackColor = SystemColors.InactiveBorder;
            txt_MaDBH.Location = new Point(196, 61);
            txt_MaDBH.Name = "txt_MaDBH";
            txt_MaDBH.Size = new Size(125, 30);
            txt_MaDBH.TabIndex = 0;
            txt_MaDBH.TextChanged += txt_MaDBH_TextChanged;
            // 
            // lbMaDBH
            // 
            lbMaDBH.AutoSize = true;
            lbMaDBH.ForeColor = SystemColors.ActiveCaptionText;
            lbMaDBH.Location = new Point(83, 64);
            lbMaDBH.Name = "lbMaDBH";
            lbMaDBH.Size = new Size(84, 23);
            lbMaDBH.TabIndex = 0;
            lbMaDBH.Text = "Mã DBH";
            // 
            // sqlCommand1
            // 
            sqlCommand1.CommandTimeout = 30;
            sqlCommand1.EnableOptimizedParameterBinding = false;
            // 
            // sidebar
            // 
            sidebar.BackColor = Color.FromArgb(0, 43, 92);
            sidebar.Controls.Add(btNH);
            sidebar.Controls.Add(btBH);
            sidebar.Controls.Add(btCNNCC);
            sidebar.Controls.Add(btCNKH);
            sidebar.Controls.Add(btHDN);
            sidebar.Controls.Add(btHDB);
            sidebar.Controls.Add(btNo);
            sidebar.Controls.Add(btHoaDon);
            sidebar.Controls.Add(btNCC);
            sidebar.Controls.Add(btKH);
            sidebar.Controls.Add(btHangHoa);
            sidebar.Controls.Add(logo);
            sidebar.Location = new Point(0, 0);
            sidebar.Margin = new Padding(4, 3, 4, 3);
            sidebar.Name = "sidebar";
            sidebar.Padding = new Padding(28, 23, 28, 23);
            sidebar.Size = new Size(336, 1178);
            sidebar.TabIndex = 8;
            // 
            // btNH
            // 
            btNH.FlatAppearance.BorderSize = 0;
            btNH.FlatAppearance.MouseDownBackColor = Color.White;
            btNH.FlatStyle = FlatStyle.Flat;
            btNH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btNH.ForeColor = Color.White;
            btNH.Location = new Point(39, 243);
            btNH.Margin = new Padding(4, 3, 4, 3);
            btNH.Name = "btNH";
            btNH.Size = new Size(210, 43);
            btNH.TabIndex = 11;
            btNH.TabStop = false;
            btNH.Text = "Nhập hàng";
            btNH.TextAlign = ContentAlignment.MiddleLeft;
            btNH.UseVisualStyleBackColor = true;
            btNH.Click += btNH_Click;
            // 
            // btBH
            // 
            btBH.FlatAppearance.BorderSize = 0;
            btBH.FlatAppearance.MouseDownBackColor = Color.White;
            btBH.FlatStyle = FlatStyle.Flat;
            btBH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btBH.ForeColor = Color.White;
            btBH.Location = new Point(44, 153);
            btBH.Margin = new Padding(4, 3, 4, 3);
            btBH.Name = "btBH";
            btBH.Size = new Size(210, 43);
            btBH.TabIndex = 10;
            btBH.TabStop = false;
            btBH.Text = "Bán hàng";
            btBH.TextAlign = ContentAlignment.MiddleLeft;
            btBH.UseVisualStyleBackColor = true;
            btBH.Click += btBH_Click;
            // 
            // btCNNCC
            // 
            btCNNCC.FlatAppearance.BorderSize = 0;
            btCNNCC.FlatAppearance.MouseDownBackColor = Color.White;
            btCNNCC.FlatStyle = FlatStyle.Flat;
            btCNNCC.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btCNNCC.ForeColor = Color.White;
            btCNNCC.Location = new Point(80, 856);
            btCNNCC.Margin = new Padding(4, 3, 4, 3);
            btCNNCC.Name = "btCNNCC";
            btCNNCC.Size = new Size(243, 43);
            btCNNCC.TabIndex = 9;
            btCNNCC.TabStop = false;
            btCNNCC.Text = "Nhà cung cấp";
            btCNNCC.TextAlign = ContentAlignment.MiddleLeft;
            btCNNCC.UseVisualStyleBackColor = true;
            btCNNCC.Visible = false;
            btCNNCC.Click += btCNNCC_Click;
            // 
            // btCNKH
            // 
            btCNKH.FlatAppearance.BorderSize = 0;
            btCNKH.FlatAppearance.MouseDownBackColor = Color.White;
            btCNKH.FlatStyle = FlatStyle.Flat;
            btCNKH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btCNKH.ForeColor = Color.White;
            btCNKH.Location = new Point(80, 807);
            btCNKH.Margin = new Padding(4, 3, 4, 3);
            btCNKH.Name = "btCNKH";
            btCNKH.Size = new Size(224, 43);
            btCNKH.TabIndex = 8;
            btCNKH.TabStop = false;
            btCNKH.Text = "Khách hàng";
            btCNKH.TextAlign = ContentAlignment.MiddleLeft;
            btCNKH.UseVisualStyleBackColor = true;
            btCNKH.Visible = false;
            btCNKH.Click += btCNKH_Click;
            // 
            // btHDN
            // 
            btHDN.FlatAppearance.BorderSize = 0;
            btHDN.FlatAppearance.MouseDownBackColor = Color.White;
            btHDN.FlatStyle = FlatStyle.Flat;
            btHDN.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHDN.ForeColor = Color.White;
            btHDN.Location = new Point(80, 709);
            btHDN.Margin = new Padding(4, 3, 4, 3);
            btHDN.Name = "btHDN";
            btHDN.Size = new Size(238, 43);
            btHDN.TabIndex = 7;
            btHDN.TabStop = false;
            btHDN.Text = "Nhập hàng";
            btHDN.TextAlign = ContentAlignment.MiddleLeft;
            btHDN.UseVisualStyleBackColor = true;
            btHDN.Visible = false;
            btHDN.Click += btHDN_Click;
            // 
            // btHDB
            // 
            btHDB.FlatAppearance.BorderSize = 0;
            btHDB.FlatAppearance.MouseDownBackColor = Color.White;
            btHDB.FlatStyle = FlatStyle.Flat;
            btHDB.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHDB.ForeColor = Color.White;
            btHDB.Location = new Point(80, 658);
            btHDB.Margin = new Padding(4, 3, 4, 3);
            btHDB.Name = "btHDB";
            btHDB.Size = new Size(238, 43);
            btHDB.TabIndex = 6;
            btHDB.TabStop = false;
            btHDB.Text = "Bán hàng";
            btHDB.TextAlign = ContentAlignment.MiddleLeft;
            btHDB.UseVisualStyleBackColor = true;
            btHDB.Visible = false;
            btHDB.Click += btHDB_Click;
            // 
            // btNo
            // 
            btNo.FlatAppearance.BorderSize = 0;
            btNo.FlatAppearance.MouseDownBackColor = Color.White;
            btNo.FlatStyle = FlatStyle.Flat;
            btNo.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btNo.ForeColor = Color.White;
            btNo.Location = new Point(44, 761);
            btNo.Margin = new Padding(4, 3, 4, 3);
            btNo.Name = "btNo";
            btNo.Size = new Size(205, 43);
            btNo.TabIndex = 5;
            btNo.TabStop = false;
            btNo.Text = "Công nợ";
            btNo.TextAlign = ContentAlignment.MiddleLeft;
            btNo.UseVisualStyleBackColor = true;
            btNo.MouseHover += btNo_MouseHover;
            // 
            // btHoaDon
            // 
            btHoaDon.FlatAppearance.BorderSize = 0;
            btHoaDon.FlatAppearance.MouseDownBackColor = Color.White;
            btHoaDon.FlatStyle = FlatStyle.Flat;
            btHoaDon.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHoaDon.ForeColor = Color.White;
            btHoaDon.Location = new Point(44, 613);
            btHoaDon.Margin = new Padding(4, 3, 4, 3);
            btHoaDon.Name = "btHoaDon";
            btHoaDon.Size = new Size(169, 43);
            btHoaDon.TabIndex = 4;
            btHoaDon.TabStop = false;
            btHoaDon.Text = "Hóa đơn";
            btHoaDon.TextAlign = ContentAlignment.MiddleLeft;
            btHoaDon.UseVisualStyleBackColor = true;
            btHoaDon.MouseHover += btHoaDon_MouseHover;
            // 
            // btNCC
            // 
            btNCC.FlatAppearance.BorderSize = 0;
            btNCC.FlatAppearance.MouseDownBackColor = Color.White;
            btNCC.FlatStyle = FlatStyle.Flat;
            btNCC.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btNCC.ForeColor = Color.White;
            btNCC.Location = new Point(39, 519);
            btNCC.Margin = new Padding(4, 3, 4, 3);
            btNCC.Name = "btNCC";
            btNCC.Size = new Size(279, 43);
            btNCC.TabIndex = 3;
            btNCC.TabStop = false;
            btNCC.Text = "Nhà cung cấp";
            btNCC.TextAlign = ContentAlignment.MiddleLeft;
            btNCC.UseVisualStyleBackColor = true;
            btNCC.Click += btNCC_Click;
            // 
            // btKH
            // 
            btKH.FlatAppearance.BorderSize = 0;
            btKH.FlatAppearance.MouseDownBackColor = Color.White;
            btKH.FlatStyle = FlatStyle.Flat;
            btKH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btKH.ForeColor = Color.White;
            btKH.Location = new Point(39, 430);
            btKH.Margin = new Padding(4, 3, 4, 3);
            btKH.Name = "btKH";
            btKH.Size = new Size(223, 43);
            btKH.TabIndex = 2;
            btKH.TabStop = false;
            btKH.Text = "Khách Hàng";
            btKH.TextAlign = ContentAlignment.MiddleLeft;
            btKH.UseVisualStyleBackColor = true;
            btKH.Click += btKH_Click;
            // 
            // btHangHoa
            // 
            btHangHoa.FlatAppearance.BorderSize = 0;
            btHangHoa.FlatAppearance.MouseDownBackColor = Color.White;
            btHangHoa.FlatStyle = FlatStyle.Flat;
            btHangHoa.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHangHoa.ForeColor = Color.White;
            btHangHoa.Location = new Point(39, 335);
            btHangHoa.Margin = new Padding(4, 3, 4, 3);
            btHangHoa.Name = "btHangHoa";
            btHangHoa.Size = new Size(210, 43);
            btHangHoa.TabIndex = 1;
            btHangHoa.TabStop = false;
            btHangHoa.Text = "Hàng hóa";
            btHangHoa.TextAlign = ContentAlignment.MiddleLeft;
            btHangHoa.UseVisualStyleBackColor = true;
            btHangHoa.Click += btHangHoa_Click;
            // 
            // logo
            // 
            logo.Image = (Image)resources.GetObject("logo.Image");
            logo.Location = new Point(32, 14);
            logo.Margin = new Padding(4, 3, 4, 3);
            logo.Name = "logo";
            logo.Size = new Size(94, 76);
            logo.SizeMode = PictureBoxSizeMode.StretchImage;
            logo.TabIndex = 0;
            logo.TabStop = false;
            // 
            // BanHang
            // 
            AutoScaleDimensions = new SizeF(11F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(1924, 984);
            Controls.Add(sidebar);
            Controls.Add(HoaDon);
            Controls.Add(title);
            Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ForeColor = SystemColors.ControlDark;
            Margin = new Padding(2, 3, 2, 3);
            Name = "BanHang";
            WindowState = FormWindowState.Maximized;
            Load += BanHang_Load;
            title.ResumeLayout(false);
            title.PerformLayout();
            HoaDon.ResumeLayout(false);
            HoaDon.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)data).EndInit();
            sidebar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)logo).EndInit();
            ResumeLayout(false);
        }

        private void txtHangHoa_TextChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void lbTong_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void Thue_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        

        

#endregion
        private Panel title;
        private TextBox txtHangHoa;
        private Panel HoaDon;
        private object txtTenHHDV;
        private TextBox txt_MaDBH;
        private Label lbMaDBH;
        private Label lbHTTT;
        private Label lbNgay;
        private TextBox txtSDT;
        private Label lbSDT;
        private DateTimePicker date;
        private ComboBox txtHTTT;
        private TextBox txtTong;
        private Label lbTong;
        private Microsoft.Data.SqlClient.SqlCommand sqlCommand1;
        private TextBox txtThue;
        private Label lbThue;
        private Button btHuy;
        private Button btHT;
        private Panel sidebar;
        private Button btNH;
        private Button btBH;
        private Button btCNNCC;
        private Button btCNKH;
        private Button btHDN;
        private Button btHDB;
        private Button btNo;
        private Button btHoaDon;
        private Button btNCC;
        private Button btKH;
        private Button btHangHoa;
        private PictureBox logo;
        private DataGridView data;
        private DataGridViewTextBoxColumn STT;
        private DataGridViewTextBoxColumn MaHH;
        private DataGridViewTextBoxColumn TenHH;
        private DataGridViewTextBoxColumn GiaBan;
        private DataGridViewTextBoxColumn SL;
        private DataGridViewTextBoxColumn ThanhTien;
        private TextBox txtThanhToan;
        private Label lbThanhToan;
    }
}