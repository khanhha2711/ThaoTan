﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Transactions;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace final
{
    public partial class BanHang : Form
    {
        string scon = "Data Source=PC;Initial Catalog=THAOTAN;Integrated Security=True;Encrypt=False;Trust Server Certificate=True";
        private SqlTransaction transaction;

        public BanHang()
        {
            InitializeComponent();
            data.ReadOnly = false;
            data.CellEndEdit += data_CellEndEdit;
        }

        private void TxtHangHoa_TextChanged(object sender, EventArgs e)
        {

        }

        private void HoaDon_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }




        private void menu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txt_MaDBH_TextChanged(object sender, EventArgs e)
        {

        }



        private void date_ValueChanged(object sender, EventArgs e)
        {

        }
        //menu
        private void btBH_Click(object sender, EventArgs e)
        {

        }

        private void btNH_Click(object sender, EventArgs e)
        {
            this.Hide();
            NhapHang nhapHang = new NhapHang();
            nhapHang.Show();
        }
        private void btHangHoa_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmHangHoa frmhanghoa = new frmHangHoa();
            frmhanghoa.Show();
        }

        private void btKH_Click(object sender, EventArgs e)
        {
            this.Hide();
            KhachHang KhacHang = new KhachHang();
            KhacHang.Show();
        }

        private void btNCC_Click(object sender, EventArgs e)
        {
            this.Hide();
            NCC nCC = new NCC();
            nCC.Show();
        }
        private void btHoaDon_MouseHover(object sender, EventArgs e)
        {
            btHDN.Visible = true;
            btHDB.Visible = true;
        }

        private void btHDB_Click(object sender, EventArgs e)
        {
            this.Hide();
            HDBH hDBH = new HDBH();
            hDBH.Show();
        }

        private void btHDN_Click(object sender, EventArgs e)
        {
            this.Hide();
            HDNH dnH = new HDNH();
            dnH.Show();
        }

        private void btNo_MouseHover(object sender, EventArgs e)
        {
            btCNKH.Visible = true;
            btCNNCC.Visible = true;
        }

        private void btCNKH_Click(object sender, EventArgs e)
        {
            this.Hide();
            NoKH noKH = new NoKH();
            noKH.Show();
        }

        private void btCNNCC_Click(object sender, EventArgs e)
        {
            this.Hide();
            NoNCC NoNCC = new NoNCC();
            NoNCC.Show();
        }


        //menu//
        //load// MaDBH
        private void BanHang_Load(object sender, EventArgs e)
        {
            string tenBang = "Ban"; // Thay đổi tên bảng theo nhu cầu

            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (SqlCommand command = new SqlCommand("SELECT dbo.TaoMaMoi(@TenBang) AS NewMaDBH", connection))
                {
                    command.Parameters.AddWithValue("@TenBang", tenBang);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        // Lấy mã hàng hóa mới và hiển thị trong TextBox
                        txt_MaDBH.Text = reader["NewMaDBH"].ToString();
                        txt_MaDBH.Enabled = false;
                    }
                }
            }
        }

        private void data_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            // Kiểm tra xem cột đang chỉnh sửa có phải là cột mã hàng hóa không
            if (e.ColumnIndex == data.Columns["MaHH"].Index) // Thay "MaHH" bằng tên cột thực tế
            {
                data.Rows[e.RowIndex].Cells["STT"].Value = e.RowIndex + 1;
                string maHH = data.Rows[e.RowIndex].Cells[e.ColumnIndex].Value?.ToString().Trim();

                if (!string.IsNullOrEmpty(maHH))
                {
                    bool isValid = CheckMaHH(maHH);

                    if (isValid)
                    {
                        LoadHangHoaInfo(maHH, e.RowIndex);
                    }
                    else
                    {
                        MessageBox.Show("Mã hàng hóa không hợp lệ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        data.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = null; // Xóa giá trị không hợp lệ
                    }
                }
            }
            // Kiểm tra xem cột đang chỉnh sửa có phải là cột Số lượng không
            if (e.ColumnIndex == data.Columns["SL"].Index) // Thay "SoLuong" bằng tên cột thực tế
            {
                string sl = data.Rows[e.RowIndex].Cells[e.ColumnIndex].Value?.ToString().Trim();
                if (!string.IsNullOrEmpty(sl))
                {
                    string maHH = data.Rows[e.RowIndex].Cells[data.Columns["MaHH"].Index].Value?.ToString().Trim();
                    decimal ton = LayTonKho(maHH);
                    bool du = CheckSL(sl,ton);

                    if (du)
                    {
                        decimal donGia = 0;
                        if (decimal.TryParse(data.Rows[e.RowIndex].Cells["GiaBan"].Value?.ToString(), out donGia))
                        {
                            // Lấy giá trị Số lượng
                            decimal soLuong = 0;
                            if (decimal.TryParse(data.Rows[e.RowIndex].Cells["SL"].Value?.ToString(), out soLuong))
                            {
                                // Tính Thành tiền
                                decimal thanhTien = donGia * soLuong;
                                // Cập nhật giá trị Thành tiền
                                data.Rows[e.RowIndex].Cells["ThanhTien"].Value = thanhTien;
                            }
                            else
                            {
                                // Nếu Số lượng không hợp lệ, có thể đặt Thành tiền về 0
                                data.Rows[e.RowIndex].Cells["ThanhTien"].Value = 0;
                            }
                        }
                    }
                    else
                    {

                        MessageBox.Show($"Hàng tồn không đủ. Số lượng trong kho: {ton}", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                        data.Rows[e.RowIndex].Cells[e.ColumnIndex].Value = null; // Xóa giá trị không hợp lệ
                    }
                }
                // Lấy giá trị Đơn giá
                
            }
        }

        private bool CheckSL(string sl,decimal ton)
        {
            if (decimal.TryParse(sl, out decimal soLuong))
            {
                // Kiểm tra số lượng phải lớn hơn 0 và không vượt quá tồn kho
                return soLuong > 0 && soLuong <= ton;
            }
            return false;
        }

        private decimal LayTonKho(string? maHH)
        {
         
            decimal tonKho = 0;
            string query = "SELECT SLHHDV FROM HHDV WHERE MaHHDV = @MaHH"; // Thay đổi tên bảng và cột cho phù hợp

            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (SqlCommand command = new SqlCommand(query, connection))
                {
                    command.Parameters.AddWithValue("@MaHH", maHH);
                    connection.Open();
                    object result = command.ExecuteScalar();
                    if (result != null)
                    {
                        tonKho = Convert.ToDecimal(result);
                    }
                }
            }

            return tonKho;
        
        }

        private void LoadHangHoaInfo(string maHH, int rowIndex)
        {
            using (SqlConnection conn = new SqlConnection(scon))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM HHDV WHERE MaHHDV = @MaHH", conn))
                {
                    cmd.Parameters.AddWithValue("@MaHH", maHH);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        // Giả sử bạn có các cột khác như TênHH, Gia, SoLuong trong DataGridView
                        data.Rows[rowIndex].Cells["TenHH"].Value = dt.Rows[0]["TenHHDV"]; // Thay "TenHH" bằng tên cột thực tế
                        data.Rows[rowIndex].Cells["GiaBan"].Value = dt.Rows[0]["GiaBan"]; // Thay "Gia" bằng tên cột thực tế

                    }
                    else
                    {
                        MessageBox.Show("Không tìm thấy thông tin hàng hóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }

        }

        private bool CheckMaHH(string maHH)
        {
            using (SqlConnection conn = new SqlConnection(scon))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT dbo.ktraHH(@MaHH)", conn))
                {
                    cmd.Parameters.AddWithValue("@MaHH", maHH); // Tham số đầu vào

                    conn.Open();
                    var result = cmd.ExecuteScalar(); // Thực thi hàm và lấy giá trị trả về
                    return result != null && (bool)result; // Kiểm tra giá trị trả về
                }
            }
        }

        private void lb_MaKH_Click(object sender, EventArgs e)
        {

        }



        private void txtSDT_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtsdt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string SDT = txtSDT.Text;
                if (CheckSDT(SDT) == false)
                {
                    DialogResult result = MessageBox.Show("Khách hàng mới. Bạn có muốn thêm thông tin khách hàng không?",
                                                "Thông báo",
                                                MessageBoxButtons.OKCancel,
                                                MessageBoxIcon.Question);

                    if (result == DialogResult.OK)
                    {
                        this.Hide();
                        EditKH editKH = new EditKH();
                        editKH.AddItem(); 
                        editKH.Show();
                    }
                }

            }
        }

        private bool CheckSDT(string sDT)
        {
            bool exists = false;

            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (var command = new SqlCommand("ktKH", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Thêm tham số vào thủ tục
                    command.Parameters.Add(new SqlParameter("@SDT", sDT));

                    // Tham số đầu ra
                    var existsParameter = new SqlParameter("@ret", SqlDbType.Bit)
                    {
                        Direction = ParameterDirection.Output
                    };
                    command.Parameters.Add(existsParameter);

                    // Mở kết nối và thực thi thủ tục
                    connection.Open();
                    command.ExecuteNonQuery();

                    // Lấy giá trị từ tham số đầu ra
                    exists = (bool)existsParameter.Value;
                }
            }
            return exists;

        }

        private void thue_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtThue_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter || e.KeyCode == Keys.Tab)
            {
                decimal thue = Convert.ToDecimal(txtThue.Text);
                decimal tongThanhTien = 0;

                // Duyệt qua từng hàng trong DataGridView
                foreach (DataGridViewRow row in data.Rows)
                {
                    // Kiểm tra xem hàng có phải là hàng mới không (hàng mới không có dữ liệu)
                    if (row.Cells["ThanhTien"].Value != null)
                    {
                        // Lấy giá trị thành tiền từ cột "ThanhTien"
                        if (decimal.TryParse(row.Cells["ThanhTien"].Value.ToString(), out decimal thanhTien))
                        {
                            // Cộng dồn vào tổng
                            tongThanhTien += thanhTien;
                        }
                    }
                }
                decimal tongtien = tongThanhTien + tongThanhTien * (thue/100);
                tongtien = Math.Round(tongtien, 2);
                txtTong.Text = tongtien.ToString("F2");
            }
        }

        private void btHT_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn cập nhật thông tin không?", "Xác nhận", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {

                InsertData(dateTimePicker: date);

            }
        }

        private void InsertData(DateTimePicker dateTimePicker)
        {
            using (SqlConnection connection = new SqlConnection(scon))
            {
                decimal tong = decimal.Parse(txtTong.Text);
                decimal thanhtoan = decimal.Parse(txtThanhToan.Text); // Giả sử bạn có một TextBox cho số tiền đã trả

                string paymentStatus;

                // Kiểm tra số tiền đã trả
                if (thanhtoan == tong)
                {
                    paymentStatus = "HT"; // Hoàn thành
                }
                else
                {
                    paymentStatus = "N"; // Nợ
                }
                using (SqlCommand command = new SqlCommand("pInsertHDB", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;

                    // Kiểm tra các tham số đầu vào
                    if (string.IsNullOrEmpty(txt_MaDBH.Text) || txt_MaDBH.Text.Length != 6)
                    {
                        MessageBox.Show("Mã đơn bán hàng phải có đúng 6 ký tự.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (string.IsNullOrEmpty(txtSDT.Text))
                    {
                        MessageBox.Show("Số điện thoại không được để trống.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (!decimal.TryParse(txtTong.Text, out decimal tongTien))
                    {
                        MessageBox.Show("Tổng tiền không hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Thêm các tham số
                    command.Parameters.AddWithValue("@MaDBH", txt_MaDBH.Text.PadRight(6, ' ')); // Đảm bảo độ dài 6 ký tự cho CHAR(6)

                    string maKH = MaKH(txtSDT.Text);
                    if (string.IsNullOrEmpty(maKH) || maKH.Length != 6)
                    {
                        MessageBox.Show("Không tìm thấy mã khách hàng cho số điện thoại đã nhập hoặc mã khách hàng không hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    command.Parameters.AddWithValue("@MaKH", maKH.PadRight(6, ' ')); // Đảm bảo độ dài 6 ký tự cho CHAR(6)

                    DateTime selectedDate = date.Value; // Lấy giá trị từ DateTimePicker
                    command.Parameters.AddWithValue("@NgayBan", selectedDate);

                    string httt = txtHTTT.Text; // Giả sử bạn có một TextBox để nhập hình thức thanh toán
                    if (httt.Equals("Tiền mặt", StringComparison.OrdinalIgnoreCase))
                    {
                        httt = "TM"; // Chuyển đổi thành "TM"
                    }
                    else
                    {
                        httt = "CK"; // Chuyển đổi thành "CK"
                    }

                    command.Parameters.AddWithValue("@HTTT", httt.Length > 10 ? httt.Substring(0, 10) : httt); // Đảm bảo không vượt quá 10 ký tự
                    command.Parameters.AddWithValue("@Tong", tongTien);

                    command.Parameters.AddWithValue("@TrangThai", paymentStatus); // Trạng thái mặc định


                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Thêm thành công!", "Thông báo");
                        }
                        else
                        {
                            MessageBox.Show("Không thành công, hãy thử lại.", "Thông báo");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi: " + ex.Message + "\n" + ex.StackTrace);
                    }
                }

                foreach (DataGridViewRow row in data.Rows)
                {
                    string maDBH = txt_MaDBH.Text;
                    if (row.IsNewRow) continue;

                    string maHHDV = row.Cells["MaHH"].Value?.ToString();
                    if (string.IsNullOrEmpty(maHHDV))
                    {
                        MessageBox.Show("Mã hàng hóa dịch vụ không được để trống.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        continue;
                    }

                    if (!decimal.TryParse(row.Cells["SL"].Value?.ToString(), out decimal slBan))
                    {
                        MessageBox.Show("Số lượng bán không hợp lệ cho hàng: " + maHHDV, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        continue;
                    }

                    using (SqlCommand command = new SqlCommand("INSERT INTO BanChiTiet (MaDBH,MaHHDV, SLBan) VALUES (@MaDBH,@MaHHDV, @SLBan)", connection, transaction))
                    {
                        command.Parameters.AddWithValue("@MaDBH", maDBH);
                        command.Parameters.AddWithValue("@MaHHDV", maHHDV);
                        command.Parameters.AddWithValue("@SLBan", slBan);

                        command.ExecuteNonQuery();
                    }
                }

                if (paymentStatus == "N")
                {
                    using (SqlCommand command = new SqlCommand("INSERT INTO HoaDonNopTKH (MaPTKH,MaDBH, NgayLap,SoTienTT,SoNoConLai,HTTT) VALUES (@MaPTKH,@MaDBH, @NgayLap,@SoTienTT,@SoNoConLai,@HTTT)", connection, transaction))
                    {
                        string newMaPTKH;
                        if (MaPTKH(out newMaPTKH))
                        {
                            // Gán giá trị cho tham số
                            command.Parameters.AddWithValue("@MaPTKH", newMaPTKH);
                        }
                        else
                        {
                            // Xử lý lỗi
                            Console.WriteLine("Không thể tạo mã mới.");
                        }
                        DateTime selectedDate = date.Value;
                   
                        command.Parameters.AddWithValue("@MaDBH", txt_MaDBH.Text);
                        command.Parameters.AddWithValue("@NgayLap", selectedDate);
                        command.Parameters.AddWithValue("@SoTienTT", txtThanhToan.Text);

                        decimal conlai = tong - thanhtoan;
                        command.Parameters.AddWithValue("SoNoConLai", conlai);


                        string httt = txtHTTT.Text; // Giả sử bạn có một TextBox để nhập hình thức thanh toán
                        if (httt.Equals("Tiền mặt", StringComparison.OrdinalIgnoreCase))
                        {
                            httt = "TM"; // Chuyển đổi thành "TM"
                        }
                        else
                        {
                            httt = "CK"; // Chuyển đổi thành "CK"
                        }
                        command.Parameters.AddWithValue("@HTTT", httt);



                        command.ExecuteNonQuery();
                    }
                }


            }
            ReloadSalesForm();

        }

        private bool MaPTKH(out string newMaPTKH)
        {
            newMaPTKH = null; // Khởi tạo giá trị mặc định
            string tenBang = "HoaDonNopTKH"; // Thay đổi tên bảng theo nhu cầu

            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (SqlCommand command = new SqlCommand("SELECT dbo.TaoMaMoi(@TenBang) AS NewMaDBH", connection))
                {
                    command.Parameters.AddWithValue("@TenBang", tenBang);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            newMaPTKH = reader["NewMaDBH"].ToString();
                            return true; // Trả về true nếu thành công
                        }
                        else
                        {
                            return false; // Trả về false nếu không có dữ liệu
                        }
                    }
                }
            }
        }

        private void ReloadSalesForm()
        {
            string tenBang = "Ban"; // Thay đổi tên bảng theo nhu cầu

            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (SqlCommand command = new SqlCommand("SELECT dbo.TaoMaMoi(@TenBang) AS NewMaDBH", connection))
                {
                    command.Parameters.AddWithValue("@TenBang", tenBang);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        // Lấy mã hàng hóa mới và hiển thị trong TextBox
                        txt_MaDBH.Text = reader["NewMaDBH"].ToString();
                        txt_MaDBH.Enabled = false;
                    }
                }
            }
            txtSDT.Text = string.Empty; // Đặt lại TextBox cho số điện thoại
            txtHTTT.Text = string.Empty; // Đặt lại TextBox cho hình thức thanh toán
            txtThue.Text = string.Empty;
            txtTong.Text = string.Empty;
            txtThanhToan.Text = string.Empty;
            data.Rows.Clear();
            date.Value = DateTime.Now;

        }

        private string MaKH(string sdt)
        {
            if (string.IsNullOrEmpty(sdt))
            {
                throw new ArgumentException("Số điện thoại không được để trống.");
            }

            string exists = null;
            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (var command = new SqlCommand("layMaKH", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Thêm tham số vào thủ tục
                    command.Parameters.Add(new SqlParameter("@SDT", sdt));

                    // Tham số đầu ra với kích thước
                    var makh = new SqlParameter("@MaKH", SqlDbType.Char, 6) // Thay 6 bằng kích thước thực tế của mã khách hàng
                    {
                        Direction = ParameterDirection.Output
                    };
                    command.Parameters.Add(makh);

                    try
                    {
                        // Mở kết nối và thực thi thủ tục
                        connection.Open();
                        command.ExecuteNonQuery();

                        // Lấy giá trị từ tham số đầu ra
                        exists = makh.Value?.ToString().Trim(); // Chuyển đổi thành chuỗi và loại bỏ khoảng trắng
                    }
                    catch (SqlException ex)
                    {
                        // Xử lý lỗi SQL
                        MessageBox.Show("Lỗi khi thực thi thủ tục: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        // Xử lý lỗi chung
                        MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            return exists;
        }

        private void btHuy_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn hủy bỏ thông tin không?", "Xác nhận", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {

                txtSDT.Text = string.Empty; // Đặt lại TextBox cho số điện thoại
                txtHTTT.Text = string.Empty; // Đặt lại TextBox cho hình thức thanh toán
                txtThue.Text = string.Empty;
                txtTong.Text = string.Empty;
                data.Rows.Clear();
                date.Value = DateTime.Now;

            }

        }



        private void txtTong_TextChanged(object sender, EventArgs e)
        {
            txtTong.Enabled = true;
        }

        private void txtThanhToan_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
