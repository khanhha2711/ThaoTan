﻿
namespace final
{
    partial class EditHH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditHH));
            sidebarTitle = new Panel();
            txtHangHoa = new TextBox();
            TTHH = new Panel();
            btHuy = new Button();
            txtSL = new TextBox();
            txtGiaBan = new TextBox();
            pictureBox1 = new PictureBox();
            btXoa = new Button();
            btChinhsua = new Button();
            txtTenHHDV = new TextBox();
            txtLoai = new TextBox();
            txtDonVi = new TextBox();
            txtMaHHDV = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            label1 = new Label();
            txtTTHH = new TextBox();
            sidebar = new Panel();
            btNH = new Button();
            btBH = new Button();
            btCNNCC = new Button();
            btCNKH = new Button();
            btHDN = new Button();
            btHDB = new Button();
            btNo = new Button();
            btHoaDon = new Button();
            btNCC = new Button();
            btKH = new Button();
            btHangHoa = new Button();
            logo = new PictureBox();
            sidebarTitle.SuspendLayout();
            TTHH.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            sidebar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)logo).BeginInit();
            SuspendLayout();
            // 
            // sidebarTitle
            // 
            sidebarTitle.BackColor = Color.FromArgb(255, 255, 255);
            sidebarTitle.Controls.Add(txtHangHoa);
            sidebarTitle.Location = new Point(336, 0);
            sidebarTitle.Margin = new Padding(4, 3, 4, 3);
            sidebarTitle.Name = "sidebarTitle";
            sidebarTitle.Size = new Size(1644, 110);
            sidebarTitle.TabIndex = 2;
            // 
            // txtHangHoa
            // 
            txtHangHoa.BorderStyle = BorderStyle.None;
            txtHangHoa.Font = new Font("Arial", 20F, FontStyle.Bold);
            txtHangHoa.ForeColor = Color.FromArgb(0, 43, 92);
            txtHangHoa.Location = new Point(45, 31);
            txtHangHoa.Margin = new Padding(4, 3, 4, 3);
            txtHangHoa.Name = "txtHangHoa";
            txtHangHoa.Size = new Size(326, 39);
            txtHangHoa.TabIndex = 0;
            txtHangHoa.TabStop = false;
            txtHangHoa.Text = "HÀNG HÓA";
            // 
            // TTHH
            // 
            TTHH.BackColor = Color.White;
            TTHH.Controls.Add(btHuy);
            TTHH.Controls.Add(txtSL);
            TTHH.Controls.Add(txtGiaBan);
            TTHH.Controls.Add(pictureBox1);
            TTHH.Controls.Add(btXoa);
            TTHH.Controls.Add(btChinhsua);
            TTHH.Controls.Add(txtTenHHDV);
            TTHH.Controls.Add(txtLoai);
            TTHH.Controls.Add(txtDonVi);
            TTHH.Controls.Add(txtMaHHDV);
            TTHH.Controls.Add(label6);
            TTHH.Controls.Add(label5);
            TTHH.Controls.Add(label4);
            TTHH.Controls.Add(label3);
            TTHH.Controls.Add(label2);
            TTHH.Controls.Add(label1);
            TTHH.Controls.Add(txtTTHH);
            TTHH.Location = new Point(497, 169);
            TTHH.Name = "TTHH";
            TTHH.Size = new Size(1257, 650);
            TTHH.TabIndex = 3;
            // 
            // btHuy
            // 
            btHuy.BackColor = Color.FromArgb(0, 43, 92);
            btHuy.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHuy.ForeColor = SystemColors.ButtonHighlight;
            btHuy.Location = new Point(569, 551);
            btHuy.Margin = new Padding(4, 3, 4, 3);
            btHuy.Name = "btHuy";
            btHuy.Size = new Size(146, 45);
            btHuy.TabIndex = 9;
            btHuy.Text = "Hủy bỏ";
            btHuy.UseVisualStyleBackColor = false;
            btHuy.Click += HuyBo_Click;
            // 
            // txtSL
            // 
            txtSL.BackColor = SystemColors.InactiveBorder;
            txtSL.Location = new Point(831, 437);
            txtSL.Name = "txtSL";
            txtSL.Size = new Size(239, 30);
            txtSL.TabIndex = 5;
            // 
            // txtGiaBan
            // 
            txtGiaBan.BackColor = SystemColors.InactiveBorder;
            txtGiaBan.Location = new Point(310, 437);
            txtGiaBan.Name = "txtGiaBan";
            txtGiaBan.Size = new Size(239, 30);
            txtGiaBan.TabIndex = 4;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(19, 30);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(32, 28);
            pictureBox1.SizeMode = PictureBoxSizeMode.StretchImage;
            pictureBox1.TabIndex = 8;
            pictureBox1.TabStop = false;
            pictureBox1.Click += back_Click;
            // 
            // btXoa
            // 
            btXoa.BackColor = Color.FromArgb(0, 43, 92);
            btXoa.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btXoa.ForeColor = SystemColors.ButtonHighlight;
            btXoa.Location = new Point(935, 551);
            btXoa.Margin = new Padding(4, 3, 4, 3);
            btXoa.Name = "btXoa";
            btXoa.Size = new Size(146, 45);
            btXoa.TabIndex = 7;
            btXoa.Text = "Xóa";
            btXoa.UseVisualStyleBackColor = false;
            btXoa.Click += btXoa_Click;
            // 
            // btChinhsua
            // 
            btChinhsua.BackColor = Color.FromArgb(0, 43, 92);
            btChinhsua.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btChinhsua.ForeColor = SystemColors.ButtonHighlight;
            btChinhsua.Location = new Point(756, 551);
            btChinhsua.Margin = new Padding(4, 3, 4, 3);
            btChinhsua.Name = "btChinhsua";
            btChinhsua.Size = new Size(146, 45);
            btChinhsua.TabIndex = 6;
            btChinhsua.Text = "Chỉnh sửa";
            btChinhsua.UseVisualStyleBackColor = false;
            btChinhsua.Click += btChinhsua_Click;
            // 
            // txtTenHHDV
            // 
            txtTenHHDV.BackColor = SystemColors.InactiveBorder;
            txtTenHHDV.Location = new Point(310, 241);
            txtTenHHDV.Name = "txtTenHHDV";
            txtTenHHDV.Size = new Size(512, 30);
            txtTenHHDV.TabIndex = 1;
            // 
            // txtLoai
            // 
            txtLoai.BackColor = SystemColors.InactiveBorder;
            txtLoai.Location = new Point(310, 343);
            txtLoai.Name = "txtLoai";
            txtLoai.Size = new Size(239, 30);
            txtLoai.TabIndex = 2;
            // 
            // txtDonVi
            // 
            txtDonVi.BackColor = SystemColors.InactiveBorder;
            txtDonVi.Location = new Point(831, 343);
            txtDonVi.Name = "txtDonVi";
            txtDonVi.Size = new Size(250, 30);
            txtDonVi.TabIndex = 3;
            // 
            // txtMaHHDV
            // 
            txtMaHHDV.BackColor = SystemColors.InactiveBorder;
            txtMaHHDV.Location = new Point(310, 135);
            txtMaHHDV.Name = "txtMaHHDV";
            txtMaHHDV.Size = new Size(239, 30);
            txtMaHHDV.TabIndex = 0;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = SystemColors.ActiveCaptionText;
            label6.Location = new Point(179, 350);
            label6.Name = "label6";
            label6.Size = new Size(47, 23);
            label6.TabIndex = 7;
            label6.Text = "Loại";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = SystemColors.ActiveCaptionText;
            label5.Location = new Point(679, 350);
            label5.Name = "label5";
            label5.Size = new Size(66, 23);
            label5.TabIndex = 6;
            label5.Text = "Đơn vị";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = SystemColors.ActiveCaptionText;
            label4.Location = new Point(179, 444);
            label4.Name = "label4";
            label4.Size = new Size(79, 23);
            label4.TabIndex = 5;
            label4.Text = "Giá bán";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = SystemColors.ActiveCaptionText;
            label3.Location = new Point(679, 444);
            label3.Name = "label3";
            label3.Size = new Size(91, 23);
            label3.TabIndex = 4;
            label3.Text = "Số lượng";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = SystemColors.ActiveCaptionText;
            label2.Location = new Point(179, 248);
            label2.Name = "label2";
            label2.Size = new Size(102, 23);
            label2.TabIndex = 3;
            label2.Text = "Tên HHDV";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = SystemColors.ActiveCaptionText;
            label1.Location = new Point(179, 142);
            label1.Name = "label1";
            label1.Size = new Size(97, 23);
            label1.TabIndex = 2;
            label1.Text = "Mã HHDV";
            // 
            // txtTTHH
            // 
            txtTTHH.BorderStyle = BorderStyle.None;
            txtTTHH.Font = new Font("Arial", 16F, FontStyle.Bold);
            txtTTHH.ForeColor = Color.FromArgb(0, 43, 92);
            txtTTHH.Location = new Point(66, 30);
            txtTTHH.Margin = new Padding(4, 3, 4, 3);
            txtTTHH.Name = "txtTTHH";
            txtTTHH.Size = new Size(326, 31);
            txtTTHH.TabIndex = 1;
            txtTTHH.TabStop = false;
            txtTTHH.Text = "THÔNG TIN HÀNG HÓA";
            // 
            // sidebar
            // 
            sidebar.BackColor = Color.FromArgb(0, 43, 92);
            sidebar.Controls.Add(btNH);
            sidebar.Controls.Add(btBH);
            sidebar.Controls.Add(btCNNCC);
            sidebar.Controls.Add(btCNKH);
            sidebar.Controls.Add(btHDN);
            sidebar.Controls.Add(btHDB);
            sidebar.Controls.Add(btNo);
            sidebar.Controls.Add(btHoaDon);
            sidebar.Controls.Add(btNCC);
            sidebar.Controls.Add(btKH);
            sidebar.Controls.Add(btHangHoa);
            sidebar.Controls.Add(logo);
            sidebar.Location = new Point(0, 0);
            sidebar.Margin = new Padding(4, 3, 4, 3);
            sidebar.Name = "sidebar";
            sidebar.Padding = new Padding(28, 23, 28, 23);
            sidebar.Size = new Size(336, 1178);
            sidebar.TabIndex = 8;
            // 
            // btNH
            // 
            btNH.FlatAppearance.BorderSize = 0;
            btNH.FlatAppearance.MouseDownBackColor = Color.White;
            btNH.FlatStyle = FlatStyle.Flat;
            btNH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btNH.ForeColor = Color.White;
            btNH.Location = new Point(39, 243);
            btNH.Margin = new Padding(4, 3, 4, 3);
            btNH.Name = "btNH";
            btNH.Size = new Size(210, 43);
            btNH.TabIndex = 11;
            btNH.TabStop = false;
            btNH.Text = "Nhập hàng";
            btNH.TextAlign = ContentAlignment.MiddleLeft;
            btNH.UseVisualStyleBackColor = true;
            btNH.Click += btNH_Click;
            // 
            // btBH
            // 
            btBH.FlatAppearance.BorderSize = 0;
            btBH.FlatAppearance.MouseDownBackColor = Color.White;
            btBH.FlatStyle = FlatStyle.Flat;
            btBH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btBH.ForeColor = Color.White;
            btBH.Location = new Point(44, 153);
            btBH.Margin = new Padding(4, 3, 4, 3);
            btBH.Name = "btBH";
            btBH.Size = new Size(210, 43);
            btBH.TabIndex = 10;
            btBH.TabStop = false;
            btBH.Text = "Bán hàng";
            btBH.TextAlign = ContentAlignment.MiddleLeft;
            btBH.UseVisualStyleBackColor = true;
            btBH.Click += btBH_Click;
            // 
            // btCNNCC
            // 
            btCNNCC.FlatAppearance.BorderSize = 0;
            btCNNCC.FlatAppearance.MouseDownBackColor = Color.White;
            btCNNCC.FlatStyle = FlatStyle.Flat;
            btCNNCC.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btCNNCC.ForeColor = Color.White;
            btCNNCC.Location = new Point(80, 856);
            btCNNCC.Margin = new Padding(4, 3, 4, 3);
            btCNNCC.Name = "btCNNCC";
            btCNNCC.Size = new Size(243, 43);
            btCNNCC.TabIndex = 9;
            btCNNCC.TabStop = false;
            btCNNCC.Text = "Nhà cung cấp";
            btCNNCC.TextAlign = ContentAlignment.MiddleLeft;
            btCNNCC.UseVisualStyleBackColor = true;
            btCNNCC.Visible = false;
            btCNNCC.Click += btCNNCC_Click;
            // 
            // btCNKH
            // 
            btCNKH.FlatAppearance.BorderSize = 0;
            btCNKH.FlatAppearance.MouseDownBackColor = Color.White;
            btCNKH.FlatStyle = FlatStyle.Flat;
            btCNKH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btCNKH.ForeColor = Color.White;
            btCNKH.Location = new Point(80, 807);
            btCNKH.Margin = new Padding(4, 3, 4, 3);
            btCNKH.Name = "btCNKH";
            btCNKH.Size = new Size(224, 43);
            btCNKH.TabIndex = 8;
            btCNKH.TabStop = false;
            btCNKH.Text = "Khách hàng";
            btCNKH.TextAlign = ContentAlignment.MiddleLeft;
            btCNKH.UseVisualStyleBackColor = true;
            btCNKH.Visible = false;
            btCNKH.Click += btCNKH_Click;
            // 
            // btHDN
            // 
            btHDN.FlatAppearance.BorderSize = 0;
            btHDN.FlatAppearance.MouseDownBackColor = Color.White;
            btHDN.FlatStyle = FlatStyle.Flat;
            btHDN.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHDN.ForeColor = Color.White;
            btHDN.Location = new Point(80, 709);
            btHDN.Margin = new Padding(4, 3, 4, 3);
            btHDN.Name = "btHDN";
            btHDN.Size = new Size(238, 43);
            btHDN.TabIndex = 7;
            btHDN.TabStop = false;
            btHDN.Text = "Nhập hàng";
            btHDN.TextAlign = ContentAlignment.MiddleLeft;
            btHDN.UseVisualStyleBackColor = true;
            btHDN.Visible = false;
            btHDN.Click += btHDN_Click;
            // 
            // btHDB
            // 
            btHDB.FlatAppearance.BorderSize = 0;
            btHDB.FlatAppearance.MouseDownBackColor = Color.White;
            btHDB.FlatStyle = FlatStyle.Flat;
            btHDB.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHDB.ForeColor = Color.White;
            btHDB.Location = new Point(80, 658);
            btHDB.Margin = new Padding(4, 3, 4, 3);
            btHDB.Name = "btHDB";
            btHDB.Size = new Size(238, 43);
            btHDB.TabIndex = 6;
            btHDB.TabStop = false;
            btHDB.Text = "Bán hàng";
            btHDB.TextAlign = ContentAlignment.MiddleLeft;
            btHDB.UseVisualStyleBackColor = true;
            btHDB.Visible = false;
            btHDB.Click += btHDB_Click;
            // 
            // btNo
            // 
            btNo.FlatAppearance.BorderSize = 0;
            btNo.FlatAppearance.MouseDownBackColor = Color.White;
            btNo.FlatStyle = FlatStyle.Flat;
            btNo.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btNo.ForeColor = Color.White;
            btNo.Location = new Point(44, 761);
            btNo.Margin = new Padding(4, 3, 4, 3);
            btNo.Name = "btNo";
            btNo.Size = new Size(205, 43);
            btNo.TabIndex = 5;
            btNo.TabStop = false;
            btNo.Text = "Công nợ";
            btNo.TextAlign = ContentAlignment.MiddleLeft;
            btNo.UseVisualStyleBackColor = true;
            btNo.MouseHover += btNo_MouseHover;
            // 
            // btHoaDon
            // 
            btHoaDon.FlatAppearance.BorderSize = 0;
            btHoaDon.FlatAppearance.MouseDownBackColor = Color.White;
            btHoaDon.FlatStyle = FlatStyle.Flat;
            btHoaDon.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHoaDon.ForeColor = Color.White;
            btHoaDon.Location = new Point(44, 613);
            btHoaDon.Margin = new Padding(4, 3, 4, 3);
            btHoaDon.Name = "btHoaDon";
            btHoaDon.Size = new Size(169, 43);
            btHoaDon.TabIndex = 4;
            btHoaDon.TabStop = false;
            btHoaDon.Text = "Hóa đơn";
            btHoaDon.TextAlign = ContentAlignment.MiddleLeft;
            btHoaDon.UseVisualStyleBackColor = true;
            btHoaDon.MouseHover += btHoaDon_MouseHover;
            // 
            // btNCC
            // 
            btNCC.FlatAppearance.BorderSize = 0;
            btNCC.FlatAppearance.MouseDownBackColor = Color.White;
            btNCC.FlatStyle = FlatStyle.Flat;
            btNCC.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btNCC.ForeColor = Color.White;
            btNCC.Location = new Point(39, 519);
            btNCC.Margin = new Padding(4, 3, 4, 3);
            btNCC.Name = "btNCC";
            btNCC.Size = new Size(279, 43);
            btNCC.TabIndex = 3;
            btNCC.TabStop = false;
            btNCC.Text = "Nhà cung cấp";
            btNCC.TextAlign = ContentAlignment.MiddleLeft;
            btNCC.UseVisualStyleBackColor = true;
            btNCC.Click += btNCC_Click;
            // 
            // btKH
            // 
            btKH.FlatAppearance.BorderSize = 0;
            btKH.FlatAppearance.MouseDownBackColor = Color.White;
            btKH.FlatStyle = FlatStyle.Flat;
            btKH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btKH.ForeColor = Color.White;
            btKH.Location = new Point(39, 430);
            btKH.Margin = new Padding(4, 3, 4, 3);
            btKH.Name = "btKH";
            btKH.Size = new Size(223, 43);
            btKH.TabIndex = 2;
            btKH.TabStop = false;
            btKH.Text = "Khách Hàng";
            btKH.TextAlign = ContentAlignment.MiddleLeft;
            btKH.UseVisualStyleBackColor = true;
            btKH.Click += btKH_Click;
            // 
            // btHangHoa
            // 
            btHangHoa.FlatAppearance.BorderSize = 0;
            btHangHoa.FlatAppearance.MouseDownBackColor = Color.White;
            btHangHoa.FlatStyle = FlatStyle.Flat;
            btHangHoa.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHangHoa.ForeColor = Color.White;
            btHangHoa.Location = new Point(39, 335);
            btHangHoa.Margin = new Padding(4, 3, 4, 3);
            btHangHoa.Name = "btHangHoa";
            btHangHoa.Size = new Size(210, 43);
            btHangHoa.TabIndex = 1;
            btHangHoa.TabStop = false;
            btHangHoa.Text = "Hàng hóa";
            btHangHoa.TextAlign = ContentAlignment.MiddleLeft;
            btHangHoa.UseVisualStyleBackColor = true;
            btHangHoa.Click += btHangHoa_Click;
            // 
            // logo
            // 
            logo.Image = (Image)resources.GetObject("logo.Image");
            logo.Location = new Point(32, 14);
            logo.Margin = new Padding(4, 3, 4, 3);
            logo.Name = "logo";
            logo.Size = new Size(94, 76);
            logo.SizeMode = PictureBoxSizeMode.StretchImage;
            logo.TabIndex = 0;
            logo.TabStop = false;
            // 
            // EditHH
            // 
            AutoScaleDimensions = new SizeF(11F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(1924, 984);
            Controls.Add(sidebar);
            Controls.Add(TTHH);
            Controls.Add(sidebarTitle);
            Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ForeColor = SystemColors.ControlDark;
            Margin = new Padding(4, 3, 4, 3);
            Name = "EditHH";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "HangHoa";
            WindowState = FormWindowState.Maximized;
            Load += EditHH_Load;
            sidebarTitle.ResumeLayout(false);
            sidebarTitle.PerformLayout();
            TTHH.ResumeLayout(false);
            TTHH.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            sidebar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)logo).EndInit();
            ResumeLayout(false);
        }

        #endregion
        private Panel sidebarTitle;
        private TextBox txtHangHoa;
        private Panel TTHH;
        private Label label2;
        private Label label1;
        private TextBox txtTTHH;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private TextBox txtTenHHDV;
        private TextBox txtLoai;
        private TextBox txtDonVi;
        private TextBox txtMaHHDV;
        private Button btXoa;
        private Button btChinhsua;
        private PictureBox pictureBox1;
        private TextBox txtSL;
        private TextBox txtGiaBan;
        private Button btHuy;
        private Panel sidebar;
        private Button btNH;
        private Button btBH;
        private Button btCNNCC;
        private Button btCNKH;
        private Button btHDN;
        private Button btHDB;
        private Button btNo;
        private Button btHoaDon;
        private Button btNCC;
        private Button btKH;
        private Button btHangHoa;
        private PictureBox logo;
    }
}