﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace final
{
    public partial class EditHH : Form
    {
        private string maHHDV;
        private string tenHHDV;
        private string loai;
        private string donVi;
        private decimal giaBan;
        private decimal slHHDV;
        string scon = "Data Source=PC;Initial Catalog=THAOTAN;Integrated Security=True;Encrypt=False;Trust Server Certificate=True";

        public object UpdatedTenHHDV { get; internal set; }
        public EditHH(string maHHDV, string tenHHDV, string loai, string donVi, decimal giaBan, decimal slHHDV)
        {
            InitializeComponent();
            this.maHHDV = maHHDV;
            this.tenHHDV = tenHHDV;
            this.loai = loai;
            this.donVi = donVi;
            this.giaBan = giaBan;
            this.slHHDV = slHHDV;

        }
        private void EditHH_Load(object sender, EventArgs e)
        {
            txtMaHHDV.Text = maHHDV;
            txtMaHHDV.Enabled = false;
            txtTenHHDV.Text = tenHHDV;
            txtLoai.Text = loai;
            txtDonVi.Text = donVi;
            txtGiaBan.Text = Convert.ToString(giaBan);
            txtSL.Text = Convert.ToString(slHHDV);
        }
        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
            frmHangHoa frmHangHoa = new frmHangHoa();
            frmHangHoa.Show();
        }

        private void btChinhsua_Click(object sender, EventArgs e)
        {
            // Kiểm tra dữ liệu trước khi cập nhật
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn cập nhật thông tin không?", "Xác nhận", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                if (KtraData())
                {
                    // Gọi thủ tục lưu trữ để cập nhật dữ liệu
                    UpdateData();
                    this.Close();
                    frmHangHoa frmHangHoa = new frmHangHoa();
                    frmHangHoa.Show();
                }
            }

        }

        private void UpdateData()
        {
            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (SqlCommand command = new SqlCommand("pUpdateHH", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;

                    // Thêm các tham số
                    command.Parameters.AddWithValue("@MaHH", txtMaHHDV.Text);
                    command.Parameters.AddWithValue("@TenHH", txtTenHHDV.Text);
                    command.Parameters.AddWithValue("@Loai", txtLoai.Text);
                    command.Parameters.AddWithValue("@DonVi", txtDonVi.Text);
                    command.Parameters.AddWithValue("@GiaBan", Convert.ToDecimal(txtGiaBan));
                    command.Parameters.AddWithValue("@SoLuong", Convert.ToDecimal(txtSL));

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Cập nhật thành công!");
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy bản ghi để cập nhật.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi: " + ex.Message);
                    }
                }
            }
        }

        private bool KtraData()
        {
            // Kiểm tra xem các trường không được để trống
            if (string.IsNullOrWhiteSpace(txtHangHoa.Text) ||
                string.IsNullOrWhiteSpace(txtLoai.Text) ||
                string.IsNullOrWhiteSpace(txtDonVi.Text) ||
                string.IsNullOrWhiteSpace(txtGiaBan.Text) ||
                string.IsNullOrWhiteSpace(txtSL.Text))
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin.");
                return false;
            }

            // Kiểm tra giá bán và số lượng
            if (Convert.ToDecimal(giaBan) <= 0)
            {
                MessageBox.Show("Giá bán phải lớn hơn 0.");
                return false;
            }

            if (Convert.ToDecimal(slHHDV) < 0)
            {
                MessageBox.Show("Số lượng không thể âm.");
                return false;
            }

            return true;
        }
        //menu //
        private void btBH_Click(object sender, EventArgs e)
        {
            this.Close();
            BanHang banHang = new BanHang();
            banHang.Show();
        }

        private void btNH_Click(object sender, EventArgs e)
        {
            this.Close();
            NhapHang nhapHang = new NhapHang();
            nhapHang.Show();
        }

        private void btHangHoa_Click(object sender, EventArgs e)
        {
            this.Close();
            frmHangHoa hangHoa = new frmHangHoa();
            hangHoa.Show();
        }

        private void btKH_Click(object sender, EventArgs e)
        {
            this.Close();
            KhachHang khachhang = new KhachHang();
            khachhang.Show();
        }

        private void btNCC_Click(object sender, EventArgs e)
        {
            this.Close();
            NCC nCC = new NCC();
            nCC.Show();
        }

        private void btHoaDon_MouseHover(object sender, EventArgs e)
        {
            btHDB.Visible = true;
            btHDN.Visible = true;
        }

        private void btHDN_Click(object sender, EventArgs e)
        {
            this.Close();
            HDNH hDNH = new HDNH();
            hDNH.Show();
        }
        private void btHDB_Click(object sender, EventArgs e)
        {
            this.Close();
            HDBH hDBH = new HDBH();
            hDBH.Show();
        }
        private void btNo_MouseHover(object sender, EventArgs e)
        {
            btCNKH.Visible = true;
            btCNNCC.Visible = true;
        }


        private void btCNKH_Click(object sender, EventArgs e)
        {
            this.Close();
            NoKH noKH = new NoKH();
            noKH.Show();
        }

        private void btCNNCC_Click(object sender, EventArgs e)
        {
            this.Close();
            NoNCC noNCC = new NoNCC();
            noNCC.Show();
        }

        private void HuyBo_Click(object sender, EventArgs e)
        {
            txtTenHHDV.Text = tenHHDV;
            txtLoai.Text = loai;
            txtDonVi.Text = donVi;
            txtGiaBan.Text = Convert.ToString(giaBan);
            txtSL.Text = Convert.ToString(slHHDV);
        }

        private void btXoa_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa bản ghi này không?", "Xác nhận", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {
                DeleteRecord();
                // Quay lại Form1 sau khi xóa thành công
                this.Close(); // Ẩn Form2
                frmHangHoa frmHangHoa = new frmHangHoa(); // Tạo một thể hiện mới của Form1
                frmHangHoa.Show(); // Hiển thị Form1
            }
        }
        private void DeleteRecord()
        {
            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (SqlCommand command = new SqlCommand("pDeleteHH", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;

                    // Thêm tham số cho mã hàng hóa
                    command.Parameters.AddWithValue("@MaHH", maHHDV);

                    connection.Open();
                    command.ExecuteNonQuery();
                }
            }

            MessageBox.Show("Bản ghi đã được xóa thành công.");
        }


     

        
    }
}
