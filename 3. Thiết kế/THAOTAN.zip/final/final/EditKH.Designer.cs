﻿
namespace final
{
    partial class EditKH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditKH));
            btXoa = new Button();
            btHT = new Button();
            txtTenKH = new TextBox();
            txtMST = new TextBox();
            txtSDT = new TextBox();
            txtDiaChi = new TextBox();
            txtSTK = new TextBox();
            txtMaKH = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            label3 = new Label();
            label2 = new Label();
            txtTTHH = new TextBox();
            TTHH = new Panel();
            txtNganHang = new TextBox();
            label7 = new Label();
            label1 = new Label();
            txtKH = new TextBox();
            sidebarTitle = new Panel();
            btNH = new Button();
            btBH = new Button();
            btCNNCC = new Button();
            btCNKH = new Button();
            btHDN = new Button();
            btHDB = new Button();
            btNo = new Button();
            btHoaDon = new Button();
            btNCC = new Button();
            btKH = new Button();
            btHangHoa = new Button();
            logo = new PictureBox();
            sidebar = new Panel();
            TTHH.SuspendLayout();
            sidebarTitle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)logo).BeginInit();
            sidebar.SuspendLayout();
            SuspendLayout();
            // 
            // btXoa
            // 
            btXoa.BackColor = Color.FromArgb(0, 43, 92);
            btXoa.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btXoa.ForeColor = SystemColors.ButtonHighlight;
            btXoa.Location = new Point(950, 565);
            btXoa.Margin = new Padding(4, 3, 4, 3);
            btXoa.Name = "btXoa";
            btXoa.Size = new Size(146, 45);
            btXoa.TabIndex = 8;
            btXoa.Text = "Xóa";
            btXoa.UseVisualStyleBackColor = false;
            btXoa.Click += btXoa_Click;
            // 
            // btHT
            // 
            btHT.BackColor = Color.FromArgb(0, 43, 92);
            btHT.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHT.ForeColor = SystemColors.ButtonHighlight;
            btHT.Location = new Point(717, 565);
            btHT.Margin = new Padding(4, 3, 4, 3);
            btHT.Name = "btHT";
            btHT.Size = new Size(146, 45);
            btHT.TabIndex = 7;
            btHT.Text = "Hoàn thành";
            btHT.UseVisualStyleBackColor = false;
            btHT.Click += btHT_Click;
            // 
            // txtTenKH
            // 
            txtTenKH.BackColor = SystemColors.InactiveBorder;
            txtTenKH.Location = new Point(339, 213);
            txtTenKH.Name = "txtTenKH";
            txtTenKH.Size = new Size(512, 30);
            txtTenKH.TabIndex = 0;
            txtTenKH.TextChanged += txtTenHHDV_TextChanged;
            // 
            // txtMST
            // 
            txtMST.BackColor = SystemColors.InactiveBorder;
            txtMST.Location = new Point(339, 380);
            txtMST.Name = "txtMST";
            txtMST.Size = new Size(239, 30);
            txtMST.TabIndex = 3;
            // 
            // txtSDT
            // 
            txtSDT.BackColor = SystemColors.InactiveBorder;
            txtSDT.Location = new Point(846, 384);
            txtSDT.Name = "txtSDT";
            txtSDT.Size = new Size(250, 30);
            txtSDT.TabIndex = 4;
            txtSDT.TextChanged += txtDonVi_TextChanged;
            // 
            // txtDiaChi
            // 
            txtDiaChi.BackColor = SystemColors.InactiveBorder;
            txtDiaChi.Location = new Point(339, 293);
            txtDiaChi.Name = "txtDiaChi";
            txtDiaChi.Size = new Size(512, 30);
            txtDiaChi.TabIndex = 1;
            // 
            // txtSTK
            // 
            txtSTK.BackColor = SystemColors.InactiveBorder;
            txtSTK.Location = new Point(846, 476);
            txtSTK.Name = "txtSTK";
            txtSTK.Size = new Size(250, 30);
            txtSTK.TabIndex = 6;
            // 
            // txtMaKH
            // 
            txtMaKH.BackColor = SystemColors.InactiveBorder;
            txtMaKH.Location = new Point(339, 135);
            txtMaKH.Name = "txtMaKH";
            txtMaKH.Size = new Size(239, 30);
            txtMaKH.TabIndex = 0;
            txtMaKH.TabStop = false;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = SystemColors.ActiveCaptionText;
            label6.Location = new Point(179, 387);
            label6.Name = "label6";
            label6.Size = new Size(108, 23);
            label6.TabIndex = 7;
            label6.Text = "Mã số thuế";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = SystemColors.ActiveCaptionText;
            label5.Location = new Point(689, 387);
            label5.Name = "label5";
            label5.Size = new Size(124, 23);
            label5.TabIndex = 6;
            label5.Text = "Số điện thoại";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.ForeColor = SystemColors.ActiveCaptionText;
            label4.Location = new Point(179, 300);
            label4.Name = "label4";
            label4.Size = new Size(69, 23);
            label4.TabIndex = 5;
            label4.Text = "Địa chỉ";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.ForeColor = SystemColors.ActiveCaptionText;
            label3.Location = new Point(689, 476);
            label3.Name = "label3";
            label3.Size = new Size(119, 23);
            label3.TabIndex = 4;
            label3.Text = "Số tài khoản";
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = SystemColors.ActiveCaptionText;
            label2.Location = new Point(179, 216);
            label2.Name = "label2";
            label2.Size = new Size(148, 23);
            label2.TabIndex = 3;
            label2.Text = "Tên khách hàng";
            // 
            // txtTTHH
            // 
            txtTTHH.BorderStyle = BorderStyle.None;
            txtTTHH.Font = new Font("Arial", 16F, FontStyle.Bold);
            txtTTHH.ForeColor = Color.FromArgb(0, 43, 92);
            txtTTHH.Location = new Point(66, 30);
            txtTTHH.Margin = new Padding(4, 3, 4, 3);
            txtTTHH.Name = "txtTTHH";
            txtTTHH.Size = new Size(354, 31);
            txtTTHH.TabIndex = 1;
            txtTTHH.TabStop = false;
            txtTTHH.Text = "THÔNG TIN KHÁCH HÀNG";
            // 
            // TTHH
            // 
            TTHH.BackColor = Color.White;
            TTHH.Controls.Add(txtNganHang);
            TTHH.Controls.Add(label7);
            TTHH.Controls.Add(btXoa);
            TTHH.Controls.Add(btHT);
            TTHH.Controls.Add(txtTenKH);
            TTHH.Controls.Add(txtMST);
            TTHH.Controls.Add(txtSDT);
            TTHH.Controls.Add(txtDiaChi);
            TTHH.Controls.Add(txtSTK);
            TTHH.Controls.Add(txtMaKH);
            TTHH.Controls.Add(label6);
            TTHH.Controls.Add(label5);
            TTHH.Controls.Add(label4);
            TTHH.Controls.Add(label3);
            TTHH.Controls.Add(label2);
            TTHH.Controls.Add(label1);
            TTHH.Controls.Add(txtTTHH);
            TTHH.Location = new Point(497, 169);
            TTHH.Name = "TTHH";
            TTHH.Size = new Size(1257, 650);
            TTHH.TabIndex = 6;
            // 
            // txtNganHang
            // 
            txtNganHang.BackColor = SystemColors.InactiveBorder;
            txtNganHang.Location = new Point(339, 473);
            txtNganHang.Name = "txtNganHang";
            txtNganHang.Size = new Size(250, 30);
            txtNganHang.TabIndex = 5;
            txtNganHang.TextChanged += textBox1_TextChanged;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.ForeColor = SystemColors.ActiveCaptionText;
            label7.Location = new Point(179, 476);
            label7.Name = "label7";
            label7.Size = new Size(103, 23);
            label7.TabIndex = 9;
            label7.Text = "Ngân hàng";
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = SystemColors.ActiveCaptionText;
            label1.Location = new Point(179, 142);
            label1.Name = "label1";
            label1.Size = new Size(70, 23);
            label1.TabIndex = 2;
            label1.Text = "Mã KH";
            // 
            // txtKH
            // 
            txtKH.BorderStyle = BorderStyle.None;
            txtKH.Font = new Font("Arial", 20F, FontStyle.Bold);
            txtKH.ForeColor = Color.FromArgb(0, 43, 92);
            txtKH.Location = new Point(45, 31);
            txtKH.Margin = new Padding(4, 3, 4, 3);
            txtKH.Name = "txtKH";
            txtKH.Size = new Size(326, 39);
            txtKH.TabIndex = 0;
            txtKH.TabStop = false;
            txtKH.Text = "KHÁCH HÀNG";
            // 
            // sidebarTitle
            // 
            sidebarTitle.BackColor = Color.FromArgb(255, 255, 255);
            sidebarTitle.Controls.Add(txtKH);
            sidebarTitle.Location = new Point(336, 0);
            sidebarTitle.Margin = new Padding(4, 3, 4, 3);
            sidebarTitle.Name = "sidebarTitle";
            sidebarTitle.Size = new Size(1644, 110);
            sidebarTitle.TabIndex = 5;
            // 
            // btNH
            // 
            btNH.FlatAppearance.BorderSize = 0;
            btNH.FlatAppearance.MouseDownBackColor = Color.White;
            btNH.FlatStyle = FlatStyle.Flat;
            btNH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btNH.ForeColor = Color.White;
            btNH.Location = new Point(39, 243);
            btNH.Margin = new Padding(4, 3, 4, 3);
            btNH.Name = "btNH";
            btNH.Size = new Size(210, 43);
            btNH.TabIndex = 10;
            btNH.TabStop = false;
            btNH.Text = "Nhập hàng";
            btNH.TextAlign = ContentAlignment.MiddleLeft;
            btNH.UseVisualStyleBackColor = true;
            btNH.Click += btNH_Click;
            // 
            // btBH
            // 
            btBH.FlatAppearance.BorderSize = 0;
            btBH.FlatAppearance.MouseDownBackColor = Color.White;
            btBH.FlatStyle = FlatStyle.Flat;
            btBH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btBH.ForeColor = Color.White;
            btBH.Location = new Point(44, 153);
            btBH.Margin = new Padding(4, 3, 4, 3);
            btBH.Name = "btBH";
            btBH.Size = new Size(210, 43);
            btBH.TabIndex = 9;
            btBH.TabStop = false;
            btBH.Text = "Bán hàng";
            btBH.TextAlign = ContentAlignment.MiddleLeft;
            btBH.UseVisualStyleBackColor = true;
            btBH.Click += btBH_Click;
            // 
            // btCNNCC
            // 
            btCNNCC.FlatAppearance.BorderSize = 0;
            btCNNCC.FlatAppearance.MouseDownBackColor = Color.White;
            btCNNCC.FlatStyle = FlatStyle.Flat;
            btCNNCC.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btCNNCC.ForeColor = Color.White;
            btCNNCC.Location = new Point(80, 856);
            btCNNCC.Margin = new Padding(4, 3, 4, 3);
            btCNNCC.Name = "btCNNCC";
            btCNNCC.Size = new Size(243, 43);
            btCNNCC.TabIndex = 9;
            btCNNCC.TabStop = false;
            btCNNCC.Text = "Nhà cung cấp";
            btCNNCC.TextAlign = ContentAlignment.MiddleLeft;
            btCNNCC.UseVisualStyleBackColor = true;
            btCNNCC.Visible = false;
            btCNNCC.Click += btCNNCC_Click;
            // 
            // btCNKH
            // 
            btCNKH.FlatAppearance.BorderSize = 0;
            btCNKH.FlatAppearance.MouseDownBackColor = Color.White;
            btCNKH.FlatStyle = FlatStyle.Flat;
            btCNKH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btCNKH.ForeColor = Color.White;
            btCNKH.Location = new Point(80, 807);
            btCNKH.Margin = new Padding(4, 3, 4, 3);
            btCNKH.Name = "btCNKH";
            btCNKH.Size = new Size(224, 43);
            btCNKH.TabIndex = 8;
            btCNKH.TabStop = false;
            btCNKH.Text = "Khách hàng";
            btCNKH.TextAlign = ContentAlignment.MiddleLeft;
            btCNKH.UseVisualStyleBackColor = true;
            btCNKH.Visible = false;
            btCNKH.Click += btCNKH_Click;
            // 
            // btHDN
            // 
            btHDN.FlatAppearance.BorderSize = 0;
            btHDN.FlatAppearance.MouseDownBackColor = Color.White;
            btHDN.FlatStyle = FlatStyle.Flat;
            btHDN.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHDN.ForeColor = Color.White;
            btHDN.Location = new Point(80, 709);
            btHDN.Margin = new Padding(4, 3, 4, 3);
            btHDN.Name = "btHDN";
            btHDN.Size = new Size(238, 43);
            btHDN.TabIndex = 7;
            btHDN.TabStop = false;
            btHDN.Text = "Nhập hàng";
            btHDN.TextAlign = ContentAlignment.MiddleLeft;
            btHDN.UseVisualStyleBackColor = true;
            btHDN.Visible = false;
            btHDN.Click += btHDN_Click;
            // 
            // btHDB
            // 
            btHDB.FlatAppearance.BorderSize = 0;
            btHDB.FlatAppearance.MouseDownBackColor = Color.White;
            btHDB.FlatStyle = FlatStyle.Flat;
            btHDB.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHDB.ForeColor = Color.White;
            btHDB.Location = new Point(80, 658);
            btHDB.Margin = new Padding(4, 3, 4, 3);
            btHDB.Name = "btHDB";
            btHDB.Size = new Size(238, 43);
            btHDB.TabIndex = 6;
            btHDB.TabStop = false;
            btHDB.Text = "Bán hàng";
            btHDB.TextAlign = ContentAlignment.MiddleLeft;
            btHDB.UseVisualStyleBackColor = true;
            btHDB.Visible = false;
            btHDB.Click += btHDB_Click;
            // 
            // btNo
            // 
            btNo.FlatAppearance.BorderSize = 0;
            btNo.FlatAppearance.MouseDownBackColor = Color.White;
            btNo.FlatStyle = FlatStyle.Flat;
            btNo.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btNo.ForeColor = Color.White;
            btNo.Location = new Point(44, 761);
            btNo.Margin = new Padding(4, 3, 4, 3);
            btNo.Name = "btNo";
            btNo.Size = new Size(205, 43);
            btNo.TabIndex = 15;
            btNo.TabStop = false;
            btNo.Text = "Công nợ";
            btNo.TextAlign = ContentAlignment.MiddleLeft;
            btNo.UseVisualStyleBackColor = true;
            btNo.MouseHover += btNo_MouseHover;
            // 
            // btHoaDon
            // 
            btHoaDon.FlatAppearance.BorderSize = 0;
            btHoaDon.FlatAppearance.MouseDownBackColor = Color.White;
            btHoaDon.FlatStyle = FlatStyle.Flat;
            btHoaDon.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHoaDon.ForeColor = Color.White;
            btHoaDon.Location = new Point(44, 613);
            btHoaDon.Margin = new Padding(4, 3, 4, 3);
            btHoaDon.Name = "btHoaDon";
            btHoaDon.Size = new Size(169, 43);
            btHoaDon.TabIndex = 14;
            btHoaDon.TabStop = false;
            btHoaDon.Text = "Hóa đơn";
            btHoaDon.TextAlign = ContentAlignment.MiddleLeft;
            btHoaDon.UseVisualStyleBackColor = true;
            btHoaDon.MouseHover += btHoaDon_MouseHover;
            // 
            // btNCC
            // 
            btNCC.FlatAppearance.BorderSize = 0;
            btNCC.FlatAppearance.MouseDownBackColor = Color.White;
            btNCC.FlatStyle = FlatStyle.Flat;
            btNCC.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btNCC.ForeColor = Color.White;
            btNCC.Location = new Point(39, 519);
            btNCC.Margin = new Padding(4, 3, 4, 3);
            btNCC.Name = "btNCC";
            btNCC.Size = new Size(279, 43);
            btNCC.TabIndex = 13;
            btNCC.TabStop = false;
            btNCC.Text = "Nhà cung cấp";
            btNCC.TextAlign = ContentAlignment.MiddleLeft;
            btNCC.UseVisualStyleBackColor = true;
            btNCC.Click += btNCC_Click;
            // 
            // btKH
            // 
            btKH.FlatAppearance.BorderSize = 0;
            btKH.FlatAppearance.MouseDownBackColor = Color.White;
            btKH.FlatStyle = FlatStyle.Flat;
            btKH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btKH.ForeColor = Color.White;
            btKH.Location = new Point(39, 430);
            btKH.Margin = new Padding(4, 3, 4, 3);
            btKH.Name = "btKH";
            btKH.Size = new Size(223, 43);
            btKH.TabIndex = 12;
            btKH.TabStop = false;
            btKH.Text = "Khách Hàng";
            btKH.TextAlign = ContentAlignment.MiddleLeft;
            btKH.UseVisualStyleBackColor = true;
            btKH.Click += btKH_Click;
            // 
            // btHangHoa
            // 
            btHangHoa.FlatAppearance.BorderSize = 0;
            btHangHoa.FlatAppearance.MouseDownBackColor = Color.White;
            btHangHoa.FlatStyle = FlatStyle.Flat;
            btHangHoa.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHangHoa.ForeColor = Color.White;
            btHangHoa.Location = new Point(39, 335);
            btHangHoa.Margin = new Padding(4, 3, 4, 3);
            btHangHoa.Name = "btHangHoa";
            btHangHoa.Size = new Size(210, 43);
            btHangHoa.TabIndex = 11;
            btHangHoa.TabStop = false;
            btHangHoa.Text = "Hàng hóa";
            btHangHoa.TextAlign = ContentAlignment.MiddleLeft;
            btHangHoa.UseVisualStyleBackColor = true;
            btHangHoa.Click += btHangHoa_Click;
            // 
            // logo
            // 
            logo.Image = (Image)resources.GetObject("logo.Image");
            logo.Location = new Point(32, 14);
            logo.Margin = new Padding(4, 3, 4, 3);
            logo.Name = "logo";
            logo.Size = new Size(94, 76);
            logo.SizeMode = PictureBoxSizeMode.StretchImage;
            logo.TabIndex = 0;
            logo.TabStop = false;
            // 
            // sidebar
            // 
            sidebar.BackColor = Color.FromArgb(0, 43, 92);
            sidebar.Controls.Add(btNH);
            sidebar.Controls.Add(btBH);
            sidebar.Controls.Add(btCNNCC);
            sidebar.Controls.Add(btCNKH);
            sidebar.Controls.Add(btHDN);
            sidebar.Controls.Add(btHDB);
            sidebar.Controls.Add(btNo);
            sidebar.Controls.Add(btHoaDon);
            sidebar.Controls.Add(btNCC);
            sidebar.Controls.Add(btKH);
            sidebar.Controls.Add(btHangHoa);
            sidebar.Controls.Add(logo);
            sidebar.Location = new Point(0, 0);
            sidebar.Margin = new Padding(4, 3, 4, 3);
            sidebar.Name = "sidebar";
            sidebar.Padding = new Padding(28, 23, 28, 23);
            sidebar.Size = new Size(336, 1178);
            sidebar.TabIndex = 4;
            // 
            // EditKH
            // 
            AutoScaleDimensions = new SizeF(11F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(1924, 984);
            Controls.Add(TTHH);
            Controls.Add(sidebarTitle);
            Controls.Add(sidebar);
            Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ForeColor = SystemColors.ControlDark;
            Margin = new Padding(4, 3, 4, 3);
            Name = "EditKH";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "EditKH";
            WindowState = FormWindowState.Maximized;
            TTHH.ResumeLayout(false);
            TTHH.PerformLayout();
            sidebarTitle.ResumeLayout(false);
            sidebarTitle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)logo).EndInit();
            sidebar.ResumeLayout(false);
            ResumeLayout(false);
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
          
        }

        private void btChinhsua_Click(object sender, EventArgs e)
        {
           
        }

#endregion
        private Button btXoa;
        private Button btHT;
        private TextBox txtTenKH;
        private TextBox txtMST;
        private TextBox txtSDT;
        private TextBox txtDiaChi;
        private TextBox txtSTK;
        private TextBox txtMaKH;
        private Label label6;
        private Label label5;
        private Label label4;
        private Label label3;
        private Label label2;
        private TextBox txtTTHH;
        private Panel TTHH;
        private Label label1;
        private TextBox txtKH;
        private Panel sidebarTitle;
        private Button btNH;
        private Button btBH;
        private Button btCNNCC;
        private Button btCNKH;
        private Button btHDN;
        private Button btHDB;
        private Button btNo;
        private Button btHoaDon;
        private Button btNCC;
        private Button btKH;
        private Button btHangHoa;
        private PictureBox logo;
        private Panel sidebar;
        private TextBox txtNganHang;
        private Label label7;
    }
}