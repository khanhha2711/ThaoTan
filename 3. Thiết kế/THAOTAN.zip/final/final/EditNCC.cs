﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace final
{
    public partial class EditNCC : Form
    {
        string scon = "Data Source=PC;Initial Catalog=THAOTAN;Integrated Security=True;Encrypt=False;Trust Server Certificate=True";

        public EditNCC()
        {
            InitializeComponent();
        }

        public void AddItem()
        {
            string tenBang = "NhaCungCap"; // Thay đổi tên bảng theo nhu cầu

            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (SqlCommand command = new SqlCommand("SELECT dbo.TaoMaMoi(@TenBang) AS NewMaNCC", connection))
                {
                    command.Parameters.AddWithValue("@TenBang", tenBang);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        txtMaNCC.Text = reader["NewMaNCC"].ToString();
                        txtMaNCC.Enabled = false;
                    }
                }
            }
            btHT.Text = "Hoàn thành";
            btXoa.Text = "Hủy";

        }

        public void SuaNCC(string? maNCC, string? tenNCC,string thue, string? diachi, string? nganhang, string? mst, string? sdt, string? stk)
        {
            txtMaNCC.Text = maNCC;
            txtTenNCC.Text = tenNCC;
            txtThue.Text = thue;
            txtDiaChi.Text = diachi;
            txtNganHang.Text = nganhang;
            txtMST.Text = mst;
            txtSDT.Text = sdt;
            txtSTK.Text = stk;
            txtMaNCC.Enabled = false;
            btHT.Text = "Cập nhật";

            txtMaNCC.Tag = maNCC;
        }

        private void btHT_Click(object sender, EventArgs e)
        {
            // Xử lý hoàn thành thêm hoặc chỉnh sửa hàng hóa
            if (btHT.Text == "Hoàn thành")
            {
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn thêm thông tin không?", "Xác nhận", MessageBoxButtons.YesNo);

                if (result == DialogResult.Yes)
                {

                    if (KtraData())
                    {
                        // Gọi thủ tục lưu trữ để cập nhật dữ liệu

                        InsertData();

                    }

                }
            }
            else if (btHT.Text == "Cập nhật")
            {
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn cập nhật thông tin không?", "Xác nhận", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {

                    UpdateData();
                    this.Hide();
                    NCC nCC = new NCC();
                    nCC.Show();

                }
            }
        }

        private void UpdateData()
        {
            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (SqlCommand command = new SqlCommand("pCapNhatNCC", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;

                    // Thêm các tham số
                    command.Parameters.AddWithValue("@MaNCC", txtMaNCC.Text);
                    command.Parameters.AddWithValue("@TenNCC", txtTenNCC.Text);
                    command.Parameters.AddWithValue("@Thue", Convert.ToDecimal(txtThue.Text));
                    command.Parameters.AddWithValue("@DiaChi", txtDiaChi.Text);
                    command.Parameters.AddWithValue("@NganHang", txtNganHang.Text);
                    command.Parameters.AddWithValue("@MST", txtMST.Text);
                    command.Parameters.AddWithValue("@SDT", txtSDT.Text);
                    command.Parameters.AddWithValue("@STK", txtSTK.Text);


                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Cập nhật thành công!");
                        }
                        else
                        {
                            MessageBox.Show("Không tìm thấy bản ghi để cập nhật.");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi: " + ex.Message);
                    }
                }
            }
        }

        private void InsertData()
        {

            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (SqlCommand command = new SqlCommand("pThemNCC", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;

                    // Thêm các tham số
                    command.Parameters.AddWithValue("@MaNCC", txtMaNCC.Text);
                    command.Parameters.AddWithValue("@TenNCC", txtTenNCC.Text);
                    command.Parameters.AddWithValue("@Thue", Convert.ToDecimal(txtThue.Text));
                    command.Parameters.AddWithValue("@DiaChi", txtDiaChi.Text);
                    command.Parameters.AddWithValue("@NganHang", txtNganHang.Text);
                    command.Parameters.AddWithValue("@MST", txtMST.Text);
                    command.Parameters.AddWithValue("@SDT", txtSDT.Text);
                    command.Parameters.AddWithValue("@STK", txtSTK.Text);

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Thêm thành công!", "Thông báo");
                            clear();

                        }
                        else
                        {
                            MessageBox.Show("Không thành công hãy thử lại", "Thông báo");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi: " + ex.Message);
                    }
                }
            }
        }

        private bool KtraData()
        {
            string maNCC = txtMaNCC.Text;
            string tenNCC = txtTenNCC.Text;
            string thue=txtThue.Text;
            string diachi = txtDiaChi.Text;
            string nganhang = txtNganHang.Text;
            string mst = txtMST.Text;
            string sdt = txtSDT.Text;
            string stk = txtSTK.Text;

            // Kiểm tra sự tồn tại của mã hàng hóa
            if (CheckSDT(sdt))
            {
                MessageBox.Show("Nhà cung cấp đã tồn tại trong cơ sở dữ liệu.", "Thông báo");
                return false;
            }


            // Kiểm tra xem các trường không được để trống
            if (string.IsNullOrWhiteSpace(txtTenNCC.Text) ||
                string.IsNullOrWhiteSpace(txtDiaChi.Text) ||
                string.IsNullOrWhiteSpace(txtThue.Text) ||
                string.IsNullOrWhiteSpace(txtNganHang.Text) ||
                string.IsNullOrWhiteSpace(txtMST.Text) ||
                string.IsNullOrWhiteSpace(txtSDT.Text) ||
                string.IsNullOrWhiteSpace(txtSTK.Text))
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin.", "Thông báo");
                return false;
            }
            if (!KiemTraSDT(sdt) || !KiemTraSTK(mst))
            {
                MessageBox.Show("Số điện thoại hoặc mã số thuế không hợp lệ.", "Thông báo");
                return false;
            }

            // Kiểm tra giá trị nhập vào có thể chuyển đổi thành decimal hay không
            if (!decimal.TryParse(thue, out decimal thueValue))
            {
                MessageBox.Show("Giá trị thuế không hợp lệ.", "Thông báo");
                return false;
            }

            
            return true;
        }

        private bool KiemTraSTK(string mst)
        {
            return Regex.IsMatch(mst, @"^\d{10}$");
        }

        private bool KiemTraSDT(string sdt)
        {
            return Regex.IsMatch(sdt, @"^\d{10}$");
        }

        private bool CheckSDT(string sdt)
        {
            bool exists = false;

            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (var command = new SqlCommand("ktNCC", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Thêm tham số vào thủ tục
                    command.Parameters.Add(new SqlParameter("@SDT", txtSDT.Text));

                    // Tham số đầu ra
                    var existsParameter = new SqlParameter("@ret", SqlDbType.Bit)
                    {
                        Direction = ParameterDirection.Output
                    };
                    command.Parameters.Add(existsParameter);

                    // Mở kết nối và thực thi thủ tục
                    connection.Open();
                    command.ExecuteNonQuery();

                    // Lấy giá trị từ tham số đầu ra
                    exists = (bool)existsParameter.Value;
                }
            }
            return exists;
        }

        private void btXoa_Click(object sender, EventArgs e)
        {
            if (btXoa.Text == "Xóa")
            {
                DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn xóa không?", "Xác nhận", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    delete(txtMaNCC.Text);
                }
            }
            else if (btXoa.Text == "Hủy")
            {
                DialogResult result = MessageBox.Show("Bạn có chắc chắn hủy không?", "Xác nhận", MessageBoxButtons.YesNo);
                if (result == DialogResult.Yes)
                {
                    clear();
                }
            }
        }

        private void clear()
        {
            string tenBang = "NhaCungCap"; // Thay đổi tên bảng theo nhu cầu

            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (SqlCommand command = new SqlCommand("SELECT dbo.TaoMaMoi(@TenBang) AS NewMaNCC", connection))
                {
                    command.Parameters.AddWithValue("@TenBang", tenBang);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        txtMaNCC.Text = reader["NewMaNCC"].ToString();
                        txtMaNCC.Enabled = false;
                    }
                }
            }
            txtTenNCC.Clear();
            txtDiaChi.Clear();
            txtNganHang.Clear();
            txtThue.Clear();
            txtMST.Clear();
            txtSDT.Clear();
            txtSTK.Clear();
        }

        private void delete(string MaNCC)
        {
            try
            {
                using (SqlConnection connection = new SqlConnection(scon))
                {
                    connection.Open();
                    string query = "DELETE FROM NhaCungCap WHERE MaNCC = @MaNCC"; // Thay YourTableName bằng tên bảng của bạn

                    using (SqlCommand command = new SqlCommand(query, connection))
                    {
                        command.Parameters.AddWithValue("@MaNCC", MaNCC);


                        command.ExecuteNonQuery();
                        MessageBox.Show("Xóa thành công!");
                        this.Close();
                        NCC ncc = new NCC();
                        ncc.Show();

                    }
                }
            }
            catch (SqlException ex)
            {
                // Bắt lỗi từ trigger
                MessageBox.Show("Còn nợ nhà cung cấp không thể xóa", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (Exception ex)
            {
                // Bắt lỗi chung
                MessageBox.Show("Đã xảy ra lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtTenHHDV_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDonVi_TextChanged(object sender, EventArgs e)
        {

        }


        private void btBH_Click(object sender, EventArgs e)
        {
            this.Hide();
            BanHang banHang = new BanHang();
            banHang.Show();
        }

        private void btNH_Click(object sender, EventArgs e)
        {
            this.Hide();
            NhapHang nhapHang = new NhapHang();
            nhapHang.Show();

        }

        private void btHangHoa_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmHangHoa frmHangHoa = new frmHangHoa();
            frmHangHoa.Show();
        }

        private void btKH_Click(object sender, EventArgs e)
        {
            this.Hide();
            KhachHang khach = new KhachHang();
            khach.Show();
        }

        private void btNCC_Click(object sender, EventArgs e)
        {
            this.Hide();
            NCC nCC = new NCC();
            nCC.Show();
        }
        private void btHoaDon_MouseHover(object sender, EventArgs e)
        {
            btHDN.Visible = true;
            btHDB.Visible = true;
        }

        private void btHDB_Click(object sender, EventArgs e)
        {
            this.Hide();
            HDBH hDBH = new HDBH();
            hDBH.Show();
        }

        private void btHDN_Click(object sender, EventArgs e)
        {
            this.Hide();
            HDNH dnH = new HDNH();
            dnH.Show();
        }

        private void btNo_MouseHover(object sender, EventArgs e)
        {
            btCNKH.Visible = true;
            btCNNCC.Visible = true;
        }

        private void btCNKH_Click(object sender, EventArgs e)
        {
            this.Hide();
            NoKH noKH = new NoKH();
            noKH.Show();
        }

        private void btCNNCC_Click(object sender, EventArgs e)
        {
            this.Hide();
            NoNCC NoNCC = new NoNCC();
            NoNCC.Show();
        }


    }
}
