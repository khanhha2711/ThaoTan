﻿
namespace final
{
    partial class EditNoKH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(EditNoKH));
            btHuy = new Button();
            btHT = new Button();
            txtConLai = new TextBox();
            txtDBH = new TextBox();
            txtThanhToan = new TextBox();
            txtMaPTKH = new TextBox();
            lbConLai = new Label();
            lbMaDBH = new Label();
            lbThanhToan = new Label();
            lbNgay = new Label();
            txtTTNCC = new TextBox();
            TTHH = new Panel();
            txtNo = new TextBox();
            lbNo = new Label();
            txtTongTien = new TextBox();
            label1 = new Label();
            txtHTTT = new ComboBox();
            date = new DateTimePicker();
            lbHTTT = new Label();
            lbMaNCC = new Label();
            txtKH = new TextBox();
            sidebarTitle = new Panel();
            btNH = new Button();
            btBH = new Button();
            btCNNCC = new Button();
            btCNKH = new Button();
            btHDN = new Button();
            btHDB = new Button();
            btNo = new Button();
            btHoaDon = new Button();
            btNCC = new Button();
            btKH = new Button();
            btHangHoa = new Button();
            logo = new PictureBox();
            sidebar = new Panel();
            TTHH.SuspendLayout();
            sidebarTitle.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)logo).BeginInit();
            sidebar.SuspendLayout();
            SuspendLayout();
            // 
            // btHuy
            // 
            btHuy.BackColor = Color.FromArgb(0, 43, 92);
            btHuy.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHuy.ForeColor = SystemColors.ButtonHighlight;
            btHuy.Location = new Point(950, 565);
            btHuy.Margin = new Padding(4, 3, 4, 3);
            btHuy.Name = "btHuy";
            btHuy.Size = new Size(146, 45);
            btHuy.TabIndex = 8;
            btHuy.Text = "Hủy";
            btHuy.UseVisualStyleBackColor = false;
            btHuy.Click += btHuy_Click;
            // 
            // btHT
            // 
            btHT.BackColor = Color.FromArgb(0, 43, 92);
            btHT.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHT.ForeColor = SystemColors.ButtonHighlight;
            btHT.Location = new Point(717, 565);
            btHT.Margin = new Padding(4, 3, 4, 3);
            btHT.Name = "btHT";
            btHT.Size = new Size(146, 45);
            btHT.TabIndex = 7;
            btHT.Text = "Hoàn thành";
            btHT.UseVisualStyleBackColor = false;
            btHT.Click += btHT_Click;
            // 
            // txtConLai
            // 
            txtConLai.BackColor = SystemColors.InactiveBorder;
            txtConLai.Location = new Point(857, 457);
            txtConLai.Name = "txtConLai";
            txtConLai.Size = new Size(239, 30);
            txtConLai.TabIndex = 4;
            txtConLai.TextChanged += txtMST_TextChanged;
            // 
            // txtDBH
            // 
            txtDBH.BackColor = SystemColors.InactiveBorder;
            txtDBH.Location = new Point(857, 136);
            txtDBH.Name = "txtDBH";
            txtDBH.Size = new Size(239, 30);
            txtDBH.TabIndex = 0;
            txtDBH.TextChanged += txtDonVi_TextChanged;
            txtDBH.KeyDown += txtDBH_KeyDown;
            // 
            // txtThanhToan
            // 
            txtThanhToan.BackColor = SystemColors.InactiveBorder;
            txtThanhToan.Location = new Point(857, 340);
            txtThanhToan.Name = "txtThanhToan";
            txtThanhToan.Size = new Size(239, 30);
            txtThanhToan.TabIndex = 2;
            txtThanhToan.KeyDown += txtThanhToan_KeyDown;
            // 
            // txtMaPTKH
            // 
            txtMaPTKH.BackColor = SystemColors.InactiveBorder;
            txtMaPTKH.Location = new Point(389, 135);
            txtMaPTKH.Name = "txtMaPTKH";
            txtMaPTKH.Size = new Size(239, 30);
            txtMaPTKH.TabIndex = 0;
            txtMaPTKH.TabStop = false;
            // 
            // lbConLai
            // 
            lbConLai.AutoSize = true;
            lbConLai.ForeColor = SystemColors.ActiveCaptionText;
            lbConLai.Location = new Point(725, 460);
            lbConLai.Name = "lbConLai";
            lbConLai.Size = new Size(70, 23);
            lbConLai.TabIndex = 7;
            lbConLai.Text = "Còn lại";
            lbConLai.Click += lbConLai_Click;
            // 
            // lbMaDBH
            // 
            lbMaDBH.AutoSize = true;
            lbMaDBH.ForeColor = SystemColors.ActiveCaptionText;
            lbMaDBH.Location = new Point(724, 143);
            lbMaDBH.Name = "lbMaDBH";
            lbMaDBH.Size = new Size(84, 23);
            lbMaDBH.TabIndex = 6;
            lbMaDBH.Text = "Mã DBH";
            // 
            // lbThanhToan
            // 
            lbThanhToan.AutoSize = true;
            lbThanhToan.ForeColor = SystemColors.ActiveCaptionText;
            lbThanhToan.Location = new Point(720, 347);
            lbThanhToan.Name = "lbThanhToan";
            lbThanhToan.Size = new Size(107, 23);
            lbThanhToan.TabIndex = 5;
            lbThanhToan.Text = "Thanh toán";
            // 
            // lbNgay
            // 
            lbNgay.AutoSize = true;
            lbNgay.ForeColor = SystemColors.ActiveCaptionText;
            lbNgay.Location = new Point(179, 229);
            lbNgay.Name = "lbNgay";
            lbNgay.Size = new Size(87, 23);
            lbNgay.TabIndex = 3;
            lbNgay.Text = "Ngày lập";
            lbNgay.Click += lbNgay_Click;
            // 
            // txtTTNCC
            // 
            txtTTNCC.BorderStyle = BorderStyle.None;
            txtTTNCC.Font = new Font("Arial", 16F, FontStyle.Bold);
            txtTTNCC.ForeColor = Color.FromArgb(0, 43, 92);
            txtTTNCC.Location = new Point(66, 39);
            txtTTNCC.Margin = new Padding(4, 3, 4, 3);
            txtTTNCC.Name = "txtTTNCC";
            txtTTNCC.Size = new Size(390, 31);
            txtTTNCC.TabIndex = 1;
            txtTTNCC.TabStop = false;
            txtTTNCC.Text = "THÔNG TIN";
            // 
            // TTHH
            // 
            TTHH.BackColor = Color.White;
            TTHH.Controls.Add(txtNo);
            TTHH.Controls.Add(lbNo);
            TTHH.Controls.Add(txtTongTien);
            TTHH.Controls.Add(label1);
            TTHH.Controls.Add(txtHTTT);
            TTHH.Controls.Add(date);
            TTHH.Controls.Add(lbHTTT);
            TTHH.Controls.Add(btHuy);
            TTHH.Controls.Add(btHT);
            TTHH.Controls.Add(txtConLai);
            TTHH.Controls.Add(txtDBH);
            TTHH.Controls.Add(txtThanhToan);
            TTHH.Controls.Add(txtMaPTKH);
            TTHH.Controls.Add(lbConLai);
            TTHH.Controls.Add(lbMaDBH);
            TTHH.Controls.Add(lbThanhToan);
            TTHH.Controls.Add(lbNgay);
            TTHH.Controls.Add(lbMaNCC);
            TTHH.Controls.Add(txtTTNCC);
            TTHH.Location = new Point(498, 169);
            TTHH.Name = "TTHH";
            TTHH.Size = new Size(1257, 650);
            TTHH.TabIndex = 6;
            // 
            // txtNo
            // 
            txtNo.BackColor = SystemColors.InactiveBorder;
            txtNo.Location = new Point(389, 339);
            txtNo.Name = "txtNo";
            txtNo.Size = new Size(239, 30);
            txtNo.TabIndex = 3;
            txtNo.TabStop = false;
            // 
            // lbNo
            // 
            lbNo.AutoSize = true;
            lbNo.ForeColor = SystemColors.ActiveCaptionText;
            lbNo.Location = new Point(178, 346);
            lbNo.Name = "lbNo";
            lbNo.Size = new Size(63, 23);
            lbNo.TabIndex = 17;
            lbNo.Text = "Số nợ";
            // 
            // txtTongTien
            // 
            txtTongTien.BackColor = SystemColors.InactiveBorder;
            txtTongTien.Location = new Point(857, 223);
            txtTongTien.Name = "txtTongTien";
            txtTongTien.Size = new Size(239, 30);
            txtTongTien.TabIndex = 2;
            txtTongTien.TabStop = false;
            txtTongTien.TextChanged += textBox1_TextChanged_1;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = SystemColors.ActiveCaptionText;
            label1.Location = new Point(725, 230);
            label1.Name = "label1";
            label1.Size = new Size(91, 23);
            label1.TabIndex = 15;
            label1.Text = "Tổng tiền";
            label1.Click += label1_Click;
            // 
            // txtHTTT
            // 
            txtHTTT.BackColor = SystemColors.InactiveBorder;
            txtHTTT.FormattingEnabled = true;
            txtHTTT.Items.AddRange(new object[] { "Chuyển khoản", "Tiền mặt" });
            txtHTTT.Location = new Point(389, 452);
            txtHTTT.Name = "txtHTTT";
            txtHTTT.Size = new Size(239, 31);
            txtHTTT.TabIndex = 3;
            txtHTTT.SelectedIndexChanged += txtHTTT_SelectedIndexChanged;
            // 
            // date
            // 
            date.Format = DateTimePickerFormat.Short;
            date.Location = new Point(389, 222);
            date.Name = "date";
            date.Size = new Size(239, 30);
            date.TabIndex = 1;
            date.Value = new DateTime(2024, 12, 13, 21, 9, 46, 0);
            // 
            // lbHTTT
            // 
            lbHTTT.AutoSize = true;
            lbHTTT.ForeColor = SystemColors.ActiveCaptionText;
            lbHTTT.Location = new Point(175, 459);
            lbHTTT.Name = "lbHTTT";
            lbHTTT.Size = new Size(191, 23);
            lbHTTT.TabIndex = 11;
            lbHTTT.Text = "Hình thức thanh toán";
            lbHTTT.Click += lbHTTT_Click;
            // 
            // lbMaNCC
            // 
            lbMaNCC.AutoSize = true;
            lbMaNCC.ForeColor = SystemColors.ActiveCaptionText;
            lbMaNCC.Location = new Point(179, 142);
            lbMaNCC.Name = "lbMaNCC";
            lbMaNCC.Size = new Size(95, 23);
            lbMaNCC.TabIndex = 2;
            lbMaNCC.Text = "Mã PTKH";
            // 
            // txtKH
            // 
            txtKH.BorderStyle = BorderStyle.None;
            txtKH.Font = new Font("Arial", 20F, FontStyle.Bold);
            txtKH.ForeColor = Color.FromArgb(0, 43, 92);
            txtKH.Location = new Point(45, 31);
            txtKH.Margin = new Padding(4, 3, 4, 3);
            txtKH.Name = "txtKH";
            txtKH.Size = new Size(460, 39);
            txtKH.TabIndex = 0;
            txtKH.TabStop = false;
            txtKH.Text = "CÔNG NỢ KHÁCH HÀNG";
            // 
            // sidebarTitle
            // 
            sidebarTitle.BackColor = Color.FromArgb(255, 255, 255);
            sidebarTitle.Controls.Add(txtKH);
            sidebarTitle.Location = new Point(336, 0);
            sidebarTitle.Margin = new Padding(4, 3, 4, 3);
            sidebarTitle.Name = "sidebarTitle";
            sidebarTitle.Size = new Size(1644, 110);
            sidebarTitle.TabIndex = 5;
            // 
            // btNH
            // 
            btNH.FlatAppearance.BorderSize = 0;
            btNH.FlatAppearance.MouseDownBackColor = Color.White;
            btNH.FlatStyle = FlatStyle.Flat;
            btNH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btNH.ForeColor = Color.White;
            btNH.Location = new Point(39, 243);
            btNH.Margin = new Padding(4, 3, 4, 3);
            btNH.Name = "btNH";
            btNH.Size = new Size(210, 43);
            btNH.TabIndex = 10;
            btNH.TabStop = false;
            btNH.Text = "Nhập hàng";
            btNH.TextAlign = ContentAlignment.MiddleLeft;
            btNH.UseVisualStyleBackColor = true;
            btNH.Click += btNH_Click;
            // 
            // btBH
            // 
            btBH.FlatAppearance.BorderSize = 0;
            btBH.FlatAppearance.MouseDownBackColor = Color.White;
            btBH.FlatStyle = FlatStyle.Flat;
            btBH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btBH.ForeColor = Color.White;
            btBH.Location = new Point(44, 153);
            btBH.Margin = new Padding(4, 3, 4, 3);
            btBH.Name = "btBH";
            btBH.Size = new Size(210, 43);
            btBH.TabIndex = 9;
            btBH.TabStop = false;
            btBH.Text = "Bán hàng";
            btBH.TextAlign = ContentAlignment.MiddleLeft;
            btBH.UseVisualStyleBackColor = true;
            btBH.Click += btBH_Click;
            // 
            // btCNNCC
            // 
            btCNNCC.FlatAppearance.BorderSize = 0;
            btCNNCC.FlatAppearance.MouseDownBackColor = Color.White;
            btCNNCC.FlatStyle = FlatStyle.Flat;
            btCNNCC.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btCNNCC.ForeColor = Color.White;
            btCNNCC.Location = new Point(80, 856);
            btCNNCC.Margin = new Padding(4, 3, 4, 3);
            btCNNCC.Name = "btCNNCC";
            btCNNCC.Size = new Size(243, 43);
            btCNNCC.TabIndex = 9;
            btCNNCC.TabStop = false;
            btCNNCC.Text = "Nhà cung cấp";
            btCNNCC.TextAlign = ContentAlignment.MiddleLeft;
            btCNNCC.UseVisualStyleBackColor = true;
            btCNNCC.Visible = false;
            btCNNCC.Click += btCNNCC_Click;
            // 
            // btCNKH
            // 
            btCNKH.FlatAppearance.BorderSize = 0;
            btCNKH.FlatAppearance.MouseDownBackColor = Color.White;
            btCNKH.FlatStyle = FlatStyle.Flat;
            btCNKH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btCNKH.ForeColor = Color.White;
            btCNKH.Location = new Point(80, 807);
            btCNKH.Margin = new Padding(4, 3, 4, 3);
            btCNKH.Name = "btCNKH";
            btCNKH.Size = new Size(224, 43);
            btCNKH.TabIndex = 8;
            btCNKH.TabStop = false;
            btCNKH.Text = "Khách hàng";
            btCNKH.TextAlign = ContentAlignment.MiddleLeft;
            btCNKH.UseVisualStyleBackColor = true;
            btCNKH.Visible = false;
            btCNKH.Click += btCNKH_Click;
            // 
            // btHDN
            // 
            btHDN.FlatAppearance.BorderSize = 0;
            btHDN.FlatAppearance.MouseDownBackColor = Color.White;
            btHDN.FlatStyle = FlatStyle.Flat;
            btHDN.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHDN.ForeColor = Color.White;
            btHDN.Location = new Point(80, 709);
            btHDN.Margin = new Padding(4, 3, 4, 3);
            btHDN.Name = "btHDN";
            btHDN.Size = new Size(238, 43);
            btHDN.TabIndex = 7;
            btHDN.TabStop = false;
            btHDN.Text = "Nhập hàng";
            btHDN.TextAlign = ContentAlignment.MiddleLeft;
            btHDN.UseVisualStyleBackColor = true;
            btHDN.Visible = false;
            btHDN.Click += btHDN_Click;
            // 
            // btHDB
            // 
            btHDB.FlatAppearance.BorderSize = 0;
            btHDB.FlatAppearance.MouseDownBackColor = Color.White;
            btHDB.FlatStyle = FlatStyle.Flat;
            btHDB.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHDB.ForeColor = Color.White;
            btHDB.Location = new Point(80, 658);
            btHDB.Margin = new Padding(4, 3, 4, 3);
            btHDB.Name = "btHDB";
            btHDB.Size = new Size(238, 43);
            btHDB.TabIndex = 6;
            btHDB.TabStop = false;
            btHDB.Text = "Bán hàng";
            btHDB.TextAlign = ContentAlignment.MiddleLeft;
            btHDB.UseVisualStyleBackColor = true;
            btHDB.Visible = false;
            btHDB.Click += btHDB_Click;
            // 
            // btNo
            // 
            btNo.FlatAppearance.BorderSize = 0;
            btNo.FlatAppearance.MouseDownBackColor = Color.White;
            btNo.FlatStyle = FlatStyle.Flat;
            btNo.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btNo.ForeColor = Color.White;
            btNo.Location = new Point(44, 761);
            btNo.Margin = new Padding(4, 3, 4, 3);
            btNo.Name = "btNo";
            btNo.Size = new Size(205, 43);
            btNo.TabIndex = 15;
            btNo.TabStop = false;
            btNo.Text = "Công nợ";
            btNo.TextAlign = ContentAlignment.MiddleLeft;
            btNo.UseVisualStyleBackColor = true;
            btNo.MouseHover += btNo_MouseHover;
            // 
            // btHoaDon
            // 
            btHoaDon.FlatAppearance.BorderSize = 0;
            btHoaDon.FlatAppearance.MouseDownBackColor = Color.White;
            btHoaDon.FlatStyle = FlatStyle.Flat;
            btHoaDon.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHoaDon.ForeColor = Color.White;
            btHoaDon.Location = new Point(44, 613);
            btHoaDon.Margin = new Padding(4, 3, 4, 3);
            btHoaDon.Name = "btHoaDon";
            btHoaDon.Size = new Size(169, 43);
            btHoaDon.TabIndex = 14;
            btHoaDon.TabStop = false;
            btHoaDon.Text = "Hóa đơn";
            btHoaDon.TextAlign = ContentAlignment.MiddleLeft;
            btHoaDon.UseVisualStyleBackColor = true;
            btHoaDon.MouseHover += btHoaDon_MouseHover;
            // 
            // btNCC
            // 
            btNCC.FlatAppearance.BorderSize = 0;
            btNCC.FlatAppearance.MouseDownBackColor = Color.White;
            btNCC.FlatStyle = FlatStyle.Flat;
            btNCC.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btNCC.ForeColor = Color.White;
            btNCC.Location = new Point(39, 519);
            btNCC.Margin = new Padding(4, 3, 4, 3);
            btNCC.Name = "btNCC";
            btNCC.Size = new Size(279, 43);
            btNCC.TabIndex = 13;
            btNCC.TabStop = false;
            btNCC.Text = "Nhà cung cấp";
            btNCC.TextAlign = ContentAlignment.MiddleLeft;
            btNCC.UseVisualStyleBackColor = true;
            btNCC.Click += btNCC_Click;
            // 
            // btKH
            // 
            btKH.FlatAppearance.BorderSize = 0;
            btKH.FlatAppearance.MouseDownBackColor = Color.White;
            btKH.FlatStyle = FlatStyle.Flat;
            btKH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btKH.ForeColor = Color.White;
            btKH.Location = new Point(39, 430);
            btKH.Margin = new Padding(4, 3, 4, 3);
            btKH.Name = "btKH";
            btKH.Size = new Size(223, 43);
            btKH.TabIndex = 12;
            btKH.TabStop = false;
            btKH.Text = "Khách Hàng";
            btKH.TextAlign = ContentAlignment.MiddleLeft;
            btKH.UseVisualStyleBackColor = true;
            btKH.Click += btKH_Click;
            // 
            // btHangHoa
            // 
            btHangHoa.FlatAppearance.BorderSize = 0;
            btHangHoa.FlatAppearance.MouseDownBackColor = Color.White;
            btHangHoa.FlatStyle = FlatStyle.Flat;
            btHangHoa.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHangHoa.ForeColor = Color.White;
            btHangHoa.Location = new Point(39, 335);
            btHangHoa.Margin = new Padding(4, 3, 4, 3);
            btHangHoa.Name = "btHangHoa";
            btHangHoa.Size = new Size(210, 43);
            btHangHoa.TabIndex = 11;
            btHangHoa.TabStop = false;
            btHangHoa.Text = "Hàng hóa";
            btHangHoa.TextAlign = ContentAlignment.MiddleLeft;
            btHangHoa.UseVisualStyleBackColor = true;
            btHangHoa.Click += btHangHoa_Click;
            // 
            // logo
            // 
            logo.ErrorImage = null;
            logo.Image = (Image)resources.GetObject("logo.Image");
            logo.Location = new Point(32, 14);
            logo.Margin = new Padding(4, 3, 4, 3);
            logo.Name = "logo";
            logo.Size = new Size(94, 76);
            logo.SizeMode = PictureBoxSizeMode.StretchImage;
            logo.TabIndex = 0;
            logo.TabStop = false;
            // 
            // sidebar
            // 
            sidebar.BackColor = Color.FromArgb(0, 43, 92);
            sidebar.Controls.Add(btNH);
            sidebar.Controls.Add(btBH);
            sidebar.Controls.Add(btCNNCC);
            sidebar.Controls.Add(btCNKH);
            sidebar.Controls.Add(btHDN);
            sidebar.Controls.Add(btHDB);
            sidebar.Controls.Add(btNo);
            sidebar.Controls.Add(btHoaDon);
            sidebar.Controls.Add(btNCC);
            sidebar.Controls.Add(btKH);
            sidebar.Controls.Add(btHangHoa);
            sidebar.Controls.Add(logo);
            sidebar.Location = new Point(0, 0);
            sidebar.Margin = new Padding(4, 3, 4, 3);
            sidebar.Name = "sidebar";
            sidebar.Padding = new Padding(28, 23, 28, 23);
            sidebar.Size = new Size(336, 1178);
            sidebar.TabIndex = 4;
            // 
            // EditNoKH
            // 
            AutoScaleDimensions = new SizeF(11F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(1924, 984);
            Controls.Add(TTHH);
            Controls.Add(sidebarTitle);
            Controls.Add(sidebar);
            Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ForeColor = SystemColors.ControlDark;
            Margin = new Padding(4, 3, 4, 3);
            Name = "EditNoKH";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "EditKH";
            WindowState = FormWindowState.Maximized;
            Load += EditNoKH_Load;
            TTHH.ResumeLayout(false);
            TTHH.PerformLayout();
            sidebarTitle.ResumeLayout(false);
            sidebarTitle.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)logo).EndInit();
            sidebar.ResumeLayout(false);
            ResumeLayout(false);
        }

        private void btHuy_Click(object sender, EventArgs e)
        {
            txtDBH.Clear();
            txtThanhToan.Clear();
            txtNo.Clear();
            txtTongTien.Clear();
            txtConLai.Clear();
        }

        private void lbConLai_Click(object sender, EventArgs e)
        {
            throw new NotImplementedException();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void btChinhsua_Click(object sender, EventArgs e)
        {

        }

        #endregion
        private Button btHuy;
        private Button btHT;
        private TextBox txtTenNCC;
        private TextBox txtConLai;
        private TextBox txtDBH;
        private TextBox txtThanhToan;
        private TextBox txtDiaChi;
        private TextBox txtMaPTKH;
        private Label lbConLai;
        private Label label6;
        private Label lbMaDBH;
        private Label lbThanhToan;
        private Label label4;
        private Label lbNgay;
        private TextBox txtTTNCC;
        private Panel TTHH;
        private Label lbMaNCC;
        private TextBox txtKH;
        private Panel sidebarTitle;
        private Button btNH;
        private Button btBH;
        private Button btCNNCC;
        private Button btCNKH;
        private Button btHDN;
        private Button btHDB;
        private Button btNo;
        private Button btHoaDon;
        private Button btNCC;
        private Button btKH;
        private Button btHangHoa;
        private PictureBox logo;
        private Panel sidebar;
        private TextBox txtThue;
        private Label lbHTTT;
        private DateTimePicker date;
        private TextBox txtTongTien;
        private Label label1;
        private ComboBox txtHTTT;
        private TextBox txtNo;
        private Label lbNo;
    }
}