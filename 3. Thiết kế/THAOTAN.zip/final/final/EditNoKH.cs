﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace final
{
    public partial class EditNoKH : Form
    {
        string scon = "Data Source=PC;Initial Catalog=THAOTAN;Integrated Security=True;Encrypt=False;Trust Server Certificate=True";

        public EditNoKH()
        {
            InitializeComponent();
        }
        private void EditNoKH_Load(object sender, EventArgs e)
        {
            string tenBang = "HoaDonNopTKH"; // Thay đổi tên bảng theo nhu cầu

            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (SqlCommand command = new SqlCommand("SELECT dbo.TaoMaMoi(@TenBang) AS NewMaPTKH", connection))
                {
                    command.Parameters.AddWithValue("@TenBang", tenBang);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        txtMaPTKH.Text = reader["NewMaPTKH"].ToString();
                        txtMaPTKH.Enabled = false;
                    }
                }
            }
        }

        private void btHT_Click(object sender, EventArgs e)
        {

            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn thêm thông tin không?", "Xác nhận", MessageBoxButtons.YesNo);

            if (result == DialogResult.Yes)
            {


                InsertData();
            }
        }

        private void InsertData()
        {
            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (SqlCommand command = new SqlCommand("pInsertNoPTKH", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;

                    // Kiểm tra và thêm các tham số
                    command.Parameters.AddWithValue("@MaPTKH", txtMaPTKH.Text);
                    command.Parameters.AddWithValue("@MaDBH", txtDBH.Text);
                    command.Parameters.AddWithValue("@NgayLap", date.Value);

                    // Kiểm tra giá trị thanh toán
                    if (!decimal.TryParse(txtThanhToan.Text, out decimal soTienTT))
                    {
                        MessageBox.Show("Giá trị thanh toán không hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    command.Parameters.AddWithValue("@SoTienTT", soTienTT);

                    // Kiểm tra số nợ còn lại
                    if (!decimal.TryParse(txtConLai.Text, out decimal soNoConLai))
                    {
                        MessageBox.Show("Giá trị số nợ không hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    command.Parameters.AddWithValue("@ConLai", soNoConLai);

                    command.Parameters.AddWithValue("@HTTT", txtHTTT.Text);

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Thêm thành công!", "Thông báo");
                            clear();
                        }
                        else
                        {
                            MessageBox.Show("Không thành công, hãy thử lại", "Thông báo");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi: " + ex.Message);
                    }
                }
            }
        }


        private void clear()
        {
            string tenBang = "HoaDonNopTKH"; // Thay đổi tên bảng theo nhu cầu

            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (SqlCommand command = new SqlCommand("SELECT dbo.TaoMaMoi(@TenBang) AS NewMaPTKH", connection))
                {
                    command.Parameters.AddWithValue("@TenBang", tenBang);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        txtMaPTKH.Text = reader["NewMaPTKH"].ToString();
                        txtMaPTKH.Enabled = false;
                    }
                }
            }
            txtDBH.Clear();
            txtThanhToan.Clear();
            txtNo.Clear();
            txtTongTien.Clear();
            txtConLai.Clear();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void txtTenHHDV_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDonVi_TextChanged(object sender, EventArgs e)
        {

        }


        private void btBH_Click(object sender, EventArgs e)
        {
            this.Hide();
            BanHang banHang = new BanHang();
            banHang.Show();
        }

        private void btNH_Click(object sender, EventArgs e)
        {
            this.Hide();
            NhapHang nhapHang = new NhapHang();
            nhapHang.Show();

        }

        private void btHangHoa_Click(object sender, EventArgs e)
        {
            this.Hide();
            frmHangHoa frmHangHoa = new frmHangHoa();
            frmHangHoa.Show();
        }

        private void btKH_Click(object sender, EventArgs e)
        {
            this.Hide();
            KhachHang khach = new KhachHang();
            khach.Show();
        }

        private void btNCC_Click(object sender, EventArgs e)
        {
            this.Hide();
            NCC nCC = new NCC();
            nCC.Show();
        }
        private void btHoaDon_MouseHover(object sender, EventArgs e)
        {
            btHDN.Visible = true;
            btHDB.Visible = true;
        }

        private void btHDB_Click(object sender, EventArgs e)
        {
            this.Hide();
            HDBH hDBH = new HDBH();
            hDBH.Show();
        }

        private void btHDN_Click(object sender, EventArgs e)
        {
            this.Hide();
            HDNH dnH = new HDNH();
            dnH.Show();
        }

        private void btNo_MouseHover(object sender, EventArgs e)
        {
            btCNKH.Visible = true;
            btCNNCC.Visible = true;
        }

        private void btCNKH_Click(object sender, EventArgs e)
        {
            this.Hide();
            NoKH noKH = new NoKH();
            noKH.Show();
        }

        private void btCNNCC_Click(object sender, EventArgs e)
        {
            this.Hide();
            NoNCC NoNCC = new NoNCC();
            NoNCC.Show();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void txtMST_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtHTTT_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lbNgay_Click(object sender, EventArgs e)
        {

        }

        private void lbHTTT_Click(object sender, EventArgs e)
        {

        }

        private void txtDBH_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string MaDBH = txtDBH.Text.Trim(); // Lấy giá trị từ TextBox và loại bỏ khoảng trắng

                if (CheckDBH(MaDBH) == false)
                {
                    MessageBox.Show("Đơn bán hàng không tồn tại. Hãy nhập lại!", "Thông báo");
                }
                else
                {
                    TongTien(MaDBH);
                    SoNo(MaDBH);

                    
                }
            }
        }



        private bool CheckDBH(string maDBH)
        {
            // Kiểm tra xem maDBH có rỗng hay không
            if (string.IsNullOrEmpty(maDBH))
            {
                MessageBox.Show("Mã DBH không được để trống");
                return false;

                // Trả về false nếu mã đơn bán hàng không hợp lệ
            }

            // Kết nối đến cơ sở dữ liệu
            using (SqlConnection con = new SqlConnection(scon))
            {
                // Truy vấn để kiểm tra sự tồn tại của mã đơn bán hàng
                string query = "SELECT COUNT(*) FROM Ban WHERE MaDBH = @MaDBH";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@MaDBH", maDBH);

                    try
                    {
                        con.Open(); // Mở kết nối
                        int count = (int)cmd.ExecuteScalar(); // Thực hiện truy vấn và lấy số lượng

                        // Nếu count > 0, mã đơn bán hàng tồn tại
                        return count > 0;
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi khi kiểm tra mã đơn bán hàng: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return false; // Trả về false nếu có lỗi
                    }
                }
            }
        }

        private void SoNo(string maDBH)
        {
            decimal tong;
            if (!decimal.TryParse(txtTongTien.Text, out tong))
            {
                MessageBox.Show("Giá trị tổng tiền không hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }

            using (SqlConnection con = new SqlConnection(scon))
            {
                string query = "SELECT SUM(SoTienTT) FROM HoaDonNopTKH WHERE MaDBH = @MaDBH";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@MaDBH", maDBH);

                    try
                    {
                        con.Open();
                        object result = cmd.ExecuteScalar();

                        if (result != DBNull.Value)
                        {
                            decimal thanhtoan = Convert.ToDecimal(result);
                            decimal no = tong - thanhtoan;
                            txtNo.Text = no.ToString("F2");
                        }
                        else
                        {
                            txtNo.Text = "0";
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi khi tính số nợ: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        private void TongTien(string maDBH)
        {
            using (SqlConnection con = new SqlConnection(scon))
            {
                // Truy vấn để tính tổng tiền theo mã đơn bán hàng
                string query = "SELECT TongTien FROM Ban WHERE MaDBH = @MaDBH";

                using (SqlCommand cmd = new SqlCommand(query, con))
                {
                    cmd.Parameters.AddWithValue("@MaDBH", maDBH);

                    try
                    {
                        con.Open(); // Mở kết nối
                        object result = cmd.ExecuteScalar(); // Thực hiện truy vấn và lấy kết quả

                        // Kiểm tra kết quả
                        if (result != DBNull.Value)
                        {
                            decimal tongTien = Convert.ToDecimal(result); // Chuyển đổi kết quả sang decimal
                            txtTongTien.Text = tongTien.ToString("F2"); // Hiển thị tổng tiền trong TextBox, định dạng số
                        }
                        else
                        {
                            txtTongTien.Text = "0"; // Nếu không có kết quả, hiển thị 0
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi khi tính tổng tiền: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void txtThanhToan_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                if (decimal.TryParse(txtThanhToan.Text, out decimal thanhtoan) &&
                decimal.TryParse(txtNo.Text, out decimal sono))
                {
                    decimal conlai = sono - thanhtoan;
                    txtConLai.Text = conlai.ToString("N0"); // Định dạng số
                }
                else
                {
                    MessageBox.Show("Giá trị thanh toán hoặc số nợ không hợp lệ.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }
    }
}
