﻿using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using Microsoft.VisualBasic;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static final.BanHang;

namespace final
{
    public partial class HDBH : Form
    {
        string scon = "Data Source=PC;Initial Catalog=THAOTAN;Integrated Security=True;Encrypt=False;Trust Server Certificate=True";


        public HDBH()
        {
            InitializeComponent();
        }
        private DataTable originalDataTable;

        private void HDB_Load(object sender, EventArgs e)
        {
            using (SqlConnection con = new SqlConnection(scon))
            {
                try
                {
                    con.Open();
                    string squery = "SELECT * FROM Ban";
                    SqlDataAdapter adapter = new SqlDataAdapter(squery, con);
                    DataSet ds = new DataSet();
                    adapter.Fill(ds, "Ban");

                    // Gán DataTable vào DataGridView
                    originalDataTable = ds.Tables["Ban"]; // Store the original data
                    data.DataSource = originalDataTable;

                    // Đặt tiêu đề cột
                    data.Columns["MaDBH"].HeaderText = "Mã DBH";
                    data.Columns["MaKH"].HeaderText = "Mã KH";
                    data.Columns["NgayBan"].HeaderText = "Ngày bán";
                    data.Columns["HTTT"].HeaderText = "Hình thức thanh toán";
                    data.Columns["TongTien"].HeaderText = "Tổng tiền";
                    data.Columns["TrangThaiTT"].HeaderText = "Trạng thái";

                    // Chuyển đổi giá trị trong DataTable
                    foreach (DataRow row in originalDataTable.Rows)
                    {
                        if (row["TrangThaiTT"].ToString().Trim().ToUpper() == "HT")
                        {
                            row["TrangThaiTT"] = "Hoàn thành";
                        }
                        else if (row["TrangThaiTT"].ToString().Trim().ToUpper() == "N")
                        {
                            row["TrangThaiTT"] = "Nợ";
                        }
                        if (row["HTTT"].ToString().Trim().ToUpper() == "CK")
                        {
                            row["HTTT"] = "Chuyển khoản";
                        }
                        else if (row["HTTT"].ToString().Trim().ToUpper() == "TM")
                        {
                            row["HTTT"] = "Tiền mặt";
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show("Lỗi khi tải dữ liệu: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }


        //menu
        private void BH_click(object sender, EventArgs e)
        {
            this.Close();
            BanHang banHang = new BanHang();
            banHang.Show();
        }

        private void NH_click(object sender, EventArgs e)
        {
            this.Close();
            NhapHang nhapHang = new NhapHang();
            nhapHang.Show();

        }

        private void btHangHoa_Click(object sender, EventArgs e)
        {
            this.Close();
            frmHangHoa frmHangHoa = new frmHangHoa();
            frmHangHoa.Show();
        }

        private void btKH_Click(object sender, EventArgs e)
        {
            this.Close();
            KhachHang khachHang = new KhachHang();
            khachHang.Show();
        }

        private void btNCC_Click(object sender, EventArgs e)
        {
            this.Close();
            NCC nCC = new NCC();
            nCC.Show();
        }
        private void btHoaDon_MouseHover(object sender, EventArgs e)
        {
            btHDN.Visible = true;
            btBan.Visible = true;
        }

        private void btHDB_Click_2(object sender, EventArgs e)
        {
            this.Close();
            HDBH hDBH = new HDBH();
            hDBH.Show();
        }

        private void btHDN_Click(object sender, EventArgs e)
        {
            this.Close();
            HDNH dnH = new HDNH();
            dnH.Show();
        }

        private void btNo_MouseHover(object sender, EventArgs e)
        {
            btCNKH.Visible = true;
            btCNNCC.Visible = true;
        }

        private void btCNKH_Click(object sender, EventArgs e)
        {
            this.Close();
            NoKH noKH = new NoKH();
            noKH.Show();
        }

        private void btCNNCC_Click(object sender, EventArgs e)
        {
            this.Close();
            NoNCC NoNCC = new NoNCC();
            NoNCC.Show();
        }
        //menu//

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void Data_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void data_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        


        private void txtMaKH_TextChanged(object sender, EventArgs e)
        {


        }

        private void txtMaKH_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string searchValue = txtMaKH.Text.Trim();

                // Check if DataGridView has data
                if (data.Rows.Count > 0)
                {
                    // Create a new DataTable to store found rows
                    DataTable filteredTable = new DataTable();

                    // Copy the structure of the DataGridView into the DataTable
                    foreach (DataGridViewColumn column in data.Columns)
                    {
                        filteredTable.Columns.Add(column.Name, column.ValueType);
                    }

                    // Search through each row
                    foreach (DataGridViewRow row in data.Rows)
                    {
                        // Check if the row is not a header row
                        if (row.Cells["MaKH"].Value != null && row.Cells["MaKH"].Value.ToString().ToLower().Contains(searchValue.ToLower()))
                        {
                            // Add found row to DataTable
                            DataRow newRow = filteredTable.NewRow();
                            for (int i = 0; i < row.Cells.Count; i++)
                            {
                                newRow[i] = row.Cells[i].Value;
                            }
                            filteredTable.Rows.Add(newRow);
                        }
                    }

                    // Check if any rows were found
                    if (filteredTable.Rows.Count > 0)
                    {
                        // Set the DataTable to the DataGridView
                        data.DataSource = filteredTable;
                    }
                    else
                    {
                        // If no rows found
                        MessageBox.Show("Không tìm thấy thông tin hóa đơn", "Kết quả tìm kiếm", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Không có dữ liệu để tìm kiếm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                // If the TextBox is empty, reset to original data
                if (string.IsNullOrEmpty(txtMaKH.Text))
                {
                    data.DataSource = originalDataTable; // Reset to original data
                }

                // Clear the TextBox after searching
                txtMaKH.Text = string.Empty;
            }
        }

        private void txtSDT_TextChanged(object sender, EventArgs e)
        {
        }




        private void txtMaHDB_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string searchValue = txtMaHDB.Text.Trim();

                // Kiểm tra nếu DataGridView có dữ liệu
                if (data.Rows.Count > 0)
                {
                    bool found = false; // Biến để theo dõi xem có tìm thấy hay không

                    // Tìm kiếm trong từng hàng
                    foreach (DataGridViewRow row in data.Rows)
                    {
                        // Kiểm tra nếu hàng không phải là hàng tiêu đề
                        if (row.Cells["MaDBH"].Value != null && row.Cells["MaDBH"].Value.ToString().ToLower().Contains(searchValue.ToLower()))
                        {
                            // Chọn hàng tìm thấy
                            row.Selected = true;
                            data.CurrentCell = row.Cells[0]; // Chọn ô đầu tiên của hàng
                            found = true; // Đánh dấu là đã tìm thấy
                            break; // Dừng vòng lặp khi tìm thấy
                        }
                    }

                    if (!found)
                    {
                        // Nếu không tìm thấy
                        MessageBox.Show("Không tìm thấy thông tin hóa đơn", "Kết quả tìm kiếm", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Không có dữ liệu để tìm kiếm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                // Xóa nội dung trong TextBox sau khi tìm kiếm
                txtMaHDB.Text = string.Empty;
            }
        }

        private void txtMaHDB_TextChanged(object sender, EventArgs e)
        {

        }

        private void data_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Lấy dữ liệu từ hàng đã chọn
                var selectedRow = data.Rows[e.RowIndex];
                string maDBH = selectedRow.Cells["MaDBH"].Value.ToString();
                
                // Tạo và hiển thị Form2 để chỉnh sửa thông tin
                BHChiTiet chitiet = new BHChiTiet();
                chitiet.HienThi(maDBH);
                chitiet.Show();
                this.Close();
            }
        }
    }
}
