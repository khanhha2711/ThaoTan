﻿using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using Microsoft.VisualBasic;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static final.BanHang;

namespace final
{
    public partial class NCC : Form
    {
        string scon = "Data Source=PC;Initial Catalog=THAOTAN;Integrated Security=True;Encrypt=False;Trust Server Certificate=True";
        public NCC()
        {
            InitializeComponent();

        }
        private void NCC_Load(object sender, EventArgs e)
        {
            using (SqlConnection connection = new SqlConnection(scon)) // Đảm bảo rằng 'scon' là chuỗi kết nối hợp lệ
            {
                using (SqlCommand command = new SqlCommand("gmNCC", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    try
                    {
                        connection.Open();
                        SqlDataAdapter adapter = new SqlDataAdapter(command);
                        DataTable dataTable = new DataTable();
                        adapter.Fill(dataTable);

                        // Gán DataTable vào DataGridView
                        DataRow[] filteredRows = dataTable.Select("TenNCC <> 'X'");
                        DataTable filteredTable = filteredRows.CopyToDataTable();

                        data.DataSource = filteredTable;
                        data.Columns["MaNCC"].HeaderText = "Mã khách hàng";
                        data.Columns["TenNCC"].HeaderText = "Tên khách hàng";
                        data.Columns["Thue"].HeaderText = "Thuế";
                        data.Columns["DiaChi"].HeaderText = "Địa chỉ";
                        data.Columns["NganHang"].HeaderText = "Ngân hàng";
                        data.Columns["MST"].HeaderText = "Mã số thuế";
                        data.Columns["SDT"].HeaderText = "Số điện thoại";
                        data.Columns["STK"].HeaderText = "Số tài khoản";
                    }
                    catch (SqlException ex)
                    {
                        MessageBox.Show("Lỗi khi lấy danh sách nhà cung cấp: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Đã xảy ra lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
        //menu
        private void BH_click(object sender, EventArgs e)
        {
            this.Close();
            BanHang banHang = new BanHang();
            banHang.Show();
        }

        private void NH_click(object sender, EventArgs e)
        {
            this.Close();
            NhapHang nhapHang = new NhapHang();
            nhapHang.Show();

        }

        private void btHangHoa_Click(object sender, EventArgs e)
        {
            this.Close();
            frmHangHoa frmHangHoa = new frmHangHoa();
            frmHangHoa.Show();
        }

        private void btKH_Click(object sender, EventArgs e)
        {
            this.Close();
            KhachHang khachHang = new KhachHang();
            khachHang.Show();
        }

        private void btNCC_Click(object sender, EventArgs e)
        {
            this.Close();
            NCC nCC = new NCC();
            nCC.Show();
        }
        private void btHoaDon_MouseHover(object sender, EventArgs e)
        {
            btHDN.Visible = true;
            btHDB.Visible = true;
        }

        private void btHDB_Click(object sender, EventArgs e)
        {
            this.Close();
            HDBH hDBH = new HDBH();
            hDBH.Show();
        }

        private void btHDN_Click(object sender, EventArgs e)
        {
            this.Close();
            HDNH dnH = new HDNH();
            dnH.Show();
        }

        private void btNo_MouseHover(object sender, EventArgs e)
        {
            btCNKH.Visible = true;
            btCNNCC.Visible = true;
        }

        private void btCNKH_Click(object sender, EventArgs e)
        {
            this.Close();
            NoKH noKH = new NoKH();
            noKH.Show();
        }

        private void btCNNCC_Click(object sender, EventArgs e)
        {
            this.Close();
            NoNCC NoNCC = new NoNCC();
            NoNCC.Show();
        }
        //menu//

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void data_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void data_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void data_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Lấy dữ liệu từ hàng đã chọn
                var selectedRow = data.Rows[e.RowIndex];
                string maNCC = selectedRow.Cells["MaNCC"].Value.ToString();
                string tenNCC = selectedRow.Cells["TenNCC"].Value.ToString();
                string thue = selectedRow.Cells["Thue"].Value.ToString();
                string diachi = selectedRow.Cells["DiaChi"].Value.ToString();
                string nganhang = selectedRow.Cells["NganHang"].Value.ToString();
                string mst = selectedRow.Cells["MST"].Value.ToString();
                string sdt = selectedRow.Cells["SDT"].Value.ToString();
                string stk = selectedRow.Cells["STK"].Value.ToString();

                // Tạo và hiển thị Form2 để chỉnh sửa thông tin
                EditNCC editNCC = new EditNCC();
                editNCC.SuaNCC(maNCC, tenNCC,thue, diachi, nganhang, mst, sdt, stk);
                editNCC.Show();
                this.Close();
            }

        }


        private void txtMaNCC_TextChanged(object sender, EventArgs e)
        {


        }

        private void txtMaNCC_KeyDown(object sender, KeyEventArgs e)
        {


            if (e.KeyCode == Keys.Enter)
            {
                string searchValue = txtMaNCC.Text.Trim();

                // Kiểm tra nếu DataGridView có dữ liệu
                if (data.Rows.Count > 0)
                {
                    bool found = false; // Biến để theo dõi xem có tìm thấy hay không

                    // Tìm kiếm trong từng hàng
                    foreach (DataGridViewRow row in data.Rows)
                    {
                        // Kiểm tra nếu hàng không phải là hàng tiêu đề
                        if (row.Cells["MaNCC"].Value != null && row.Cells["MaNCC"].Value.ToString().ToLower().Contains(searchValue.ToLower()))
                        {
                            // Chọn hàng tìm thấy
                            row.Selected = true;
                            data.CurrentCell = row.Cells[0]; // Chọn ô đầu tiên của hàng
                            found = true; // Đánh dấu là đã tìm thấy
                            break; // Dừng vòng lặp khi tìm thấy
                        }
                    }

                    if (!found)
                    {
                        // Nếu không tìm thấy
                        MessageBox.Show("Không tìm thấy nhà cung cấp", "Kết quả tìm kiếm", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Không có dữ liệu để tìm kiếm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                // Xóa nội dung trong TextBox sau khi tìm kiếm
                txtMaNCC.Text = string.Empty;
            }
        }

        private void txtSDT_TextChanged(object sender, EventArgs e)
        {
        }

        private void txtSDT_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string searchValue = txtSDT.Text.Trim();

                // Kiểm tra nếu DataGridView có dữ liệu
                if (data.Rows.Count > 0)
                {
                    bool found = false; // Biến để theo dõi xem có tìm thấy hay không

                    // Tìm kiếm trong từng hàng
                    foreach (DataGridViewRow row in data.Rows)
                    {
                        // Kiểm tra nếu hàng không phải là hàng tiêu đề
                        if (row.Cells["SDT"].Value != null && row.Cells["SDT"].Value.ToString().ToLower().Contains(searchValue.ToLower()))
                        {
                            // Chọn hàng tìm thấy
                            row.Selected = true;
                            data.CurrentCell = row.Cells[0]; // Chọn ô đầu tiên của hàng
                            found = true; // Đánh dấu là đã tìm thấy
                            break; // Dừng vòng lặp khi tìm thấy
                        }
                    }

                    if (!found)
                    {
                        // Nếu không tìm thấy
                        MessageBox.Show("Không tìm thấy nhà cung cấp", "Kết quả tìm kiếm", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Không có dữ liệu để tìm kiếm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                // Xóa nội dung trong TextBox sau khi tìm kiếm
                txtSDT.Text = string.Empty;
            }
        }

        private void btInsert_Click(object sender, EventArgs e)
        {
            EditNCC editNCC = new EditNCC();
            editNCC.AddItem(); // Gửi thông tin mã hàng hóa mới
            editNCC.Show(); // Mở Form2
            this.Close();
        }

        
    }
}
