﻿using Microsoft.VisualBasic.Logging;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace final
{
    partial class NHChiTiet
    {
        /// <summary>
        ///  Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        ///  Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        ///  Required method for Designer support - do not modify
        ///  the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(NHChiTiet));
            sidebar = new Panel();
            btNH = new Button();
            btBH = new Button();
            btCNNCC = new Button();
            btCNKH = new Button();
            btHDN = new Button();
            btBan = new Button();
            btNo = new Button();
            btHoaDon = new Button();
            btNCC = new Button();
            btKH = new Button();
            btHangHoa = new Button();
            logo = new PictureBox();
            sidebarTitle = new Panel();
            txtHDB = new TextBox();
            sbSearch = new Panel();
            txtMaHDN = new TextBox();
            data = new DataGridView();
            Ban = new DataGridViewTextBoxColumn();
            Select = new DataGridViewCheckBoxColumn();
            sidebar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)logo).BeginInit();
            sidebarTitle.SuspendLayout();
            sbSearch.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)data).BeginInit();
            SuspendLayout();
            // 
            // sidebar
            // 
            sidebar.BackColor = Color.FromArgb(0, 43, 92);
            sidebar.Controls.Add(btNH);
            sidebar.Controls.Add(btBH);
            sidebar.Controls.Add(btCNNCC);
            sidebar.Controls.Add(btCNKH);
            sidebar.Controls.Add(btHDN);
            sidebar.Controls.Add(btBan);
            sidebar.Controls.Add(btNo);
            sidebar.Controls.Add(btHoaDon);
            sidebar.Controls.Add(btNCC);
            sidebar.Controls.Add(btKH);
            sidebar.Controls.Add(btHangHoa);
            sidebar.Controls.Add(logo);
            sidebar.Location = new Point(0, 0);
            sidebar.Margin = new Padding(4, 3, 4, 3);
            sidebar.Name = "sidebar";
            sidebar.Padding = new Padding(28, 23, 28, 23);
            sidebar.Size = new Size(336, 1178);
            sidebar.TabIndex = 0;
            // 
            // btNH
            // 
            btNH.FlatAppearance.BorderSize = 0;
            btNH.FlatAppearance.MouseDownBackColor = Color.White;
            btNH.FlatStyle = FlatStyle.Flat;
            btNH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btNH.ForeColor = Color.White;
            btNH.Location = new Point(39, 243);
            btNH.Margin = new Padding(4, 3, 4, 3);
            btNH.Name = "btNH";
            btNH.Size = new Size(210, 43);
            btNH.TabIndex = 11;
            btNH.TabStop = false;
            btNH.Text = "Nhập hàng";
            btNH.TextAlign = ContentAlignment.MiddleLeft;
            btNH.UseVisualStyleBackColor = true;
            btNH.Click += NH_click;
            // 
            // btBH
            // 
            btBH.FlatAppearance.BorderSize = 0;
            btBH.FlatAppearance.MouseDownBackColor = Color.White;
            btBH.FlatStyle = FlatStyle.Flat;
            btBH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btBH.ForeColor = Color.White;
            btBH.Location = new Point(44, 153);
            btBH.Margin = new Padding(4, 3, 4, 3);
            btBH.Name = "btBH";
            btBH.Size = new Size(210, 43);
            btBH.TabIndex = 10;
            btBH.TabStop = false;
            btBH.Text = "Bán hàng";
            btBH.TextAlign = ContentAlignment.MiddleLeft;
            btBH.UseVisualStyleBackColor = true;
            btBH.Click += BH_click;
            // 
            // btCNNCC
            // 
            btCNNCC.FlatAppearance.BorderSize = 0;
            btCNNCC.FlatAppearance.MouseDownBackColor = Color.White;
            btCNNCC.FlatStyle = FlatStyle.Flat;
            btCNNCC.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btCNNCC.ForeColor = Color.White;
            btCNNCC.Location = new Point(80, 856);
            btCNNCC.Margin = new Padding(4, 3, 4, 3);
            btCNNCC.Name = "btCNNCC";
            btCNNCC.Size = new Size(243, 43);
            btCNNCC.TabIndex = 9;
            btCNNCC.TabStop = false;
            btCNNCC.Text = "Nhà cung cấp";
            btCNNCC.TextAlign = ContentAlignment.MiddleLeft;
            btCNNCC.UseVisualStyleBackColor = true;
            btCNNCC.Visible = false;
            btCNNCC.Click += btCNNCC_Click;
            // 
            // btCNKH
            // 
            btCNKH.FlatAppearance.BorderSize = 0;
            btCNKH.FlatAppearance.MouseDownBackColor = Color.White;
            btCNKH.FlatStyle = FlatStyle.Flat;
            btCNKH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btCNKH.ForeColor = Color.White;
            btCNKH.Location = new Point(80, 807);
            btCNKH.Margin = new Padding(4, 3, 4, 3);
            btCNKH.Name = "btCNKH";
            btCNKH.Size = new Size(224, 43);
            btCNKH.TabIndex = 8;
            btCNKH.TabStop = false;
            btCNKH.Text = "Khách hàng";
            btCNKH.TextAlign = ContentAlignment.MiddleLeft;
            btCNKH.UseVisualStyleBackColor = true;
            btCNKH.Visible = false;
            btCNKH.Click += btCNKH_Click;
            // 
            // btHDN
            // 
            btHDN.FlatAppearance.BorderSize = 0;
            btHDN.FlatAppearance.MouseDownBackColor = Color.White;
            btHDN.FlatStyle = FlatStyle.Flat;
            btHDN.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHDN.ForeColor = Color.White;
            btHDN.Location = new Point(80, 709);
            btHDN.Margin = new Padding(4, 3, 4, 3);
            btHDN.Name = "btHDN";
            btHDN.Size = new Size(238, 43);
            btHDN.TabIndex = 7;
            btHDN.TabStop = false;
            btHDN.Text = "Nhập hàng";
            btHDN.TextAlign = ContentAlignment.MiddleLeft;
            btHDN.UseVisualStyleBackColor = true;
            btHDN.Visible = false;
            btHDN.Click += btHDN_Click;
            // 
            // btBan
            // 
            btBan.FlatAppearance.BorderSize = 0;
            btBan.FlatAppearance.MouseDownBackColor = Color.White;
            btBan.FlatStyle = FlatStyle.Flat;
            btBan.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btBan.ForeColor = Color.White;
            btBan.Location = new Point(80, 658);
            btBan.Margin = new Padding(4, 3, 4, 3);
            btBan.Name = "btBan";
            btBan.Size = new Size(238, 43);
            btBan.TabIndex = 6;
            btBan.TabStop = false;
            btBan.Text = "Bán hàng";
            btBan.TextAlign = ContentAlignment.MiddleLeft;
            btBan.UseVisualStyleBackColor = true;
            btBan.Visible = false;
            btBan.Click += btHDB_Click_2;
            // 
            // btNo
            // 
            btNo.FlatAppearance.BorderSize = 0;
            btNo.FlatAppearance.MouseDownBackColor = Color.White;
            btNo.FlatStyle = FlatStyle.Flat;
            btNo.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btNo.ForeColor = Color.White;
            btNo.Location = new Point(44, 761);
            btNo.Margin = new Padding(4, 3, 4, 3);
            btNo.Name = "btNo";
            btNo.Size = new Size(205, 43);
            btNo.TabIndex = 5;
            btNo.TabStop = false;
            btNo.Text = "Công nợ";
            btNo.TextAlign = ContentAlignment.MiddleLeft;
            btNo.UseVisualStyleBackColor = true;
            btNo.MouseHover += btNo_MouseHover;
            // 
            // btHoaDon
            // 
            btHoaDon.FlatAppearance.BorderSize = 0;
            btHoaDon.FlatAppearance.MouseDownBackColor = Color.White;
            btHoaDon.FlatStyle = FlatStyle.Flat;
            btHoaDon.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHoaDon.ForeColor = Color.White;
            btHoaDon.Location = new Point(44, 613);
            btHoaDon.Margin = new Padding(4, 3, 4, 3);
            btHoaDon.Name = "btHoaDon";
            btHoaDon.Size = new Size(169, 43);
            btHoaDon.TabIndex = 4;
            btHoaDon.TabStop = false;
            btHoaDon.Text = "Hóa đơn";
            btHoaDon.TextAlign = ContentAlignment.MiddleLeft;
            btHoaDon.UseVisualStyleBackColor = true;
            btHoaDon.MouseHover += btHoaDon_MouseHover;
            // 
            // btNCC
            // 
            btNCC.FlatAppearance.BorderSize = 0;
            btNCC.FlatAppearance.MouseDownBackColor = Color.White;
            btNCC.FlatStyle = FlatStyle.Flat;
            btNCC.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btNCC.ForeColor = Color.White;
            btNCC.Location = new Point(39, 519);
            btNCC.Margin = new Padding(4, 3, 4, 3);
            btNCC.Name = "btNCC";
            btNCC.Size = new Size(279, 43);
            btNCC.TabIndex = 3;
            btNCC.TabStop = false;
            btNCC.Text = "Nhà cung cấp";
            btNCC.TextAlign = ContentAlignment.MiddleLeft;
            btNCC.UseVisualStyleBackColor = true;
            btNCC.Click += btNCC_Click;
            // 
            // btKH
            // 
            btKH.FlatAppearance.BorderSize = 0;
            btKH.FlatAppearance.MouseDownBackColor = Color.White;
            btKH.FlatStyle = FlatStyle.Flat;
            btKH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btKH.ForeColor = Color.White;
            btKH.Location = new Point(39, 430);
            btKH.Margin = new Padding(4, 3, 4, 3);
            btKH.Name = "btKH";
            btKH.Size = new Size(223, 43);
            btKH.TabIndex = 2;
            btKH.TabStop = false;
            btKH.Text = "Khách Hàng";
            btKH.TextAlign = ContentAlignment.MiddleLeft;
            btKH.UseVisualStyleBackColor = true;
            btKH.Click += btKH_Click;
            // 
            // btHangHoa
            // 
            btHangHoa.FlatAppearance.BorderSize = 0;
            btHangHoa.FlatAppearance.MouseDownBackColor = Color.White;
            btHangHoa.FlatStyle = FlatStyle.Flat;
            btHangHoa.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHangHoa.ForeColor = Color.White;
            btHangHoa.Location = new Point(39, 335);
            btHangHoa.Margin = new Padding(4, 3, 4, 3);
            btHangHoa.Name = "btHangHoa";
            btHangHoa.Size = new Size(210, 43);
            btHangHoa.TabIndex = 1;
            btHangHoa.TabStop = false;
            btHangHoa.Text = "Hàng hóa";
            btHangHoa.TextAlign = ContentAlignment.MiddleLeft;
            btHangHoa.UseVisualStyleBackColor = true;
            btHangHoa.Click += btHangHoa_Click;
            // 
            // logo
            // 
            logo.Image = (Image)resources.GetObject("logo.Image");
            logo.Location = new Point(32, 14);
            logo.Margin = new Padding(4, 3, 4, 3);
            logo.Name = "logo";
            logo.Size = new Size(94, 76);
            logo.SizeMode = PictureBoxSizeMode.StretchImage;
            logo.TabIndex = 0;
            logo.TabStop = false;
            // 
            // sidebarTitle
            // 
            sidebarTitle.BackColor = Color.FromArgb(255, 255, 255);
            sidebarTitle.Controls.Add(txtHDB);
            sidebarTitle.Location = new Point(336, 0);
            sidebarTitle.Margin = new Padding(4, 3, 4, 3);
            sidebarTitle.Name = "sidebarTitle";
            sidebarTitle.Size = new Size(1644, 110);
            sidebarTitle.TabIndex = 1;
            // 
            // txtHDB
            // 
            txtHDB.BorderStyle = BorderStyle.None;
            txtHDB.Font = new Font("Arial", 20F, FontStyle.Bold);
            txtHDB.ForeColor = Color.FromArgb(0, 43, 92);
            txtHDB.Location = new Point(45, 31);
            txtHDB.Margin = new Padding(4, 3, 4, 3);
            txtHDB.Name = "txtHDB";
            txtHDB.Size = new Size(401, 39);
            txtHDB.TabIndex = 0;
            txtHDB.TabStop = false;
            txtHDB.Text = "HÓA ĐƠN NHẬP HÀNG";
            txtHDB.TextChanged += textBox1_TextChanged;
            // 
            // sbSearch
            // 
            sbSearch.BackColor = Color.FromArgb(255, 255, 255);
            sbSearch.Controls.Add(txtMaHDN);
            sbSearch.Location = new Point(352, 128);
            sbSearch.Margin = new Padding(4, 3, 4, 3);
            sbSearch.Name = "sbSearch";
            sbSearch.Size = new Size(1587, 94);
            sbSearch.TabIndex = 2;
            // 
            // txtMaHDN
            // 
            txtMaHDN.BackColor = SystemColors.InactiveBorder;
            txtMaHDN.Font = new Font("Arial", 12F);
            txtMaHDN.Location = new Point(65, 28);
            txtMaHDN.Margin = new Padding(4, 3, 4, 3);
            txtMaHDN.Name = "txtMaHDN";
            txtMaHDN.PlaceholderText = "Mã hóa đơn";
            txtMaHDN.Size = new Size(274, 30);
            txtMaHDN.TabIndex = 0;
            txtMaHDN.TextChanged += txtMaHDN_TextChanged;
            // 
            // data
            // 
            data.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            data.BackgroundColor = Color.White;
            data.BorderStyle = BorderStyle.Fixed3D;
            data.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            data.Location = new Point(354, 247);
            data.Margin = new Padding(4, 3, 4, 3);
            data.Name = "data";
            data.ReadOnly = true;
            data.RowHeadersWidth = 51;
            data.Size = new Size(1557, 725);
            data.TabIndex = 3;
            // 
            // Ban
            // 
            Ban.MinimumWidth = 6;
            Ban.Name = "Ban";
            Ban.Width = 125;
            // 
            // Select
            // 
            Select.MinimumWidth = 6;
            Select.Name = "Select";
            Select.Width = 125;
            // 
            // NHChiTiet
            // 
            AutoScaleDimensions = new SizeF(11F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(1924, 984);
            Controls.Add(data);
            Controls.Add(sbSearch);
            Controls.Add(sidebarTitle);
            Controls.Add(sidebar);
            Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ForeColor = SystemColors.ControlDark;
            Margin = new Padding(4, 3, 4, 3);
            Name = "NHChiTiet";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "KhachHang";
            WindowState = FormWindowState.Maximized;
            Load += NHChiTiet_Load;
            sidebar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)logo).EndInit();
            sidebarTitle.ResumeLayout(false);
            sidebarTitle.PerformLayout();
            sbSearch.ResumeLayout(false);
            sbSearch.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)data).EndInit();
            ResumeLayout(false);
        }






        #endregion
        private PictureBox logo;
        private Panel sidebarTitle;
        private TextBox txtHDB;
        private Panel sbSearch;
        private TextBox txtMaHDN;
        private Button btHangHoa;
        private Button btKH;
        private Button btNo;
        private Button btHoaDon;
        private Button btNCC;
        private Button btBan;
        private Button btHDN;
        private Button btCNKH;
        private Button btCNNCC;
        private DataGridView data;
        private Button btBH;
        private Panel sidebar;
        private Button btNH;
        private DataGridViewTextBoxColumn Ban;
        private DataGridViewCheckBoxColumn Select;
    }
}
