﻿using System;
using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using Microsoft.VisualBasic;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static final.BanHang;

namespace final
{
    public partial class NHChiTiet : Form
    {
        string scon = "Data Source=PC;Initial Catalog=THAOTAN;Integrated Security=True;Encrypt=False;Trust Server Certificate=True";


        public NHChiTiet()
        {
            InitializeComponent();
        }
        public void HienThi(string? maDBH)
        {
            txtMaHDN.Text = maDBH;
        }




        //menu
        private void BH_click(object sender, EventArgs e)
        {
            this.Close();
            BanHang banHang = new BanHang();
            banHang.Show();
        }

        private void NH_click(object sender, EventArgs e)
        {
            this.Close();
            NhapHang nhapHang = new NhapHang();
            nhapHang.Show();

        }

        private void btHangHoa_Click(object sender, EventArgs e)
        {
            this.Close();
            frmHangHoa frmHangHoa = new frmHangHoa();
            frmHangHoa.Show();
        }

        private void btKH_Click(object sender, EventArgs e)
        {
            this.Close();
            KhachHang khachHang = new KhachHang();
            khachHang.Show();
        }

        private void btNCC_Click(object sender, EventArgs e)
        {
            this.Close();
            NCC nCC = new NCC();
            nCC.Show();
        }
        private void btHoaDon_MouseHover(object sender, EventArgs e)
        {
            btHDN.Visible = true;
            btBan.Visible = true;
        }

        private void btHDB_Click_2(object sender, EventArgs e)
        {
            this.Close();
            HDBH hDBH = new HDBH();
            hDBH.Show();
        }

        private void btHDN_Click(object sender, EventArgs e)
        {
            this.Close();
            HDNH dnH = new HDNH();
            dnH.Show();
        }

        private void btNo_MouseHover(object sender, EventArgs e)
        {
            btCNKH.Visible = true;
            btCNNCC.Visible = true;
        }

        private void btCNKH_Click(object sender, EventArgs e)
        {
            this.Close();
            NoKH noKH = new NoKH();
            noKH.Show();
        }

        private void btCNNCC_Click(object sender, EventArgs e)
        {
            this.Close();
            NoNCC NoNCC = new NoNCC();
            NoNCC.Show();
        }
        //menu//

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void data_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void data_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }


        private void txtMaKH_TextChanged(object sender, EventArgs e)
        {


        }


        private void txtSDT_TextChanged(object sender, EventArgs e)
        {
        }




        private void txtMaHDB_KeyDown(object sender, KeyEventArgs e)
        {

        }

        private void NHChiTiet_Load(object sender, EventArgs e)
        {
            // Kiểm tra xem mã HDB có rỗng không
            if (string.IsNullOrEmpty(txtMaHDN.Text))
            {
                MessageBox.Show("Mã HDN không được để trống.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return; // Thoát khỏi phương thức nếu không có mã HDB
            }

            using (SqlConnection conn = new SqlConnection(scon))
            {
                // Truy vấn để lấy thông tin từ cả BanChiTiet và HHDV
                string query = @"
            SELECT bc.MaHHDV, bc.SLNhap, h.TenHHDV, bc.GiaNhap 
            FROM NhapChiTiet bc
            JOIN HHDV h ON bc.MaHHDV = h.MaHHDV
            WHERE bc.MaDNH = @MaDNH";

                using (SqlCommand cmd = new SqlCommand(query, conn))
                {
                    cmd.Parameters.AddWithValue("@MaDNH", txtMaHDN.Text);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();

                    try
                    {
                        conn.Open(); // Mở kết nối
                        adapter.Fill(dt); // Điền dữ liệu vào DataTable

                        // Kiểm tra xem DataTable có dữ liệu không
                        if (dt.Rows.Count == 0)
                        {
                            MessageBox.Show("Không có dữ liệu nào được tìm thấy.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            return; // Thoát khỏi phương thức nếu không có dữ liệu
                        }

                        // Thêm cột ThanhTien vào DataTable
                        dt.Columns.Add("ThanhTien", typeof(decimal));

                        // Gán DataTable cho DataGridView
                        data.DataSource = dt;

                        // Thiết lập tiêu đề cột
                        data.Columns["MaHHDV"].HeaderText = "Mã HH";
                        data.Columns["SLNhap"].HeaderText = "Số lượng";
                        data.Columns["TenHHDV"].HeaderText = "Tên HH"; // Cột tên hàng hóa
                        data.Columns["GiaNhap"].HeaderText = "Giá nhập"; // Cột giá bán
                        data.Columns["ThanhTien"].HeaderText = "Thành tiền"; // Cột thành tiền

                        // Tính thành tiền cho mỗi hàng
                        foreach (DataRow row in dt.Rows)
                        {
                            // Lấy số lượng và giá bán
                            decimal soLuong = Convert.ToDecimal(row["SLNhap"]);
                            decimal giaNhap = Convert.ToDecimal(row["GiaNhap"]);
                            decimal thanhTien = soLuong * giaNhap;

                            // Gán thành tiền vào cột
                            row["ThanhTien"] = thanhTien;
                        }

                        // Thiết lập thứ tự hiển thị cột
                        data.Columns["MaHHDV"].DisplayIndex = 0;
                        data.Columns["SLNhap"].DisplayIndex = 1;
                        data.Columns["TenHHDV"].DisplayIndex = 2;
                        data.Columns["GiaNhap"].DisplayIndex = 3;
                        data.Columns["ThanhTien"].DisplayIndex = 4;
                    }
                    catch (SqlException sqlEx)
                    {
                        MessageBox.Show("Lỗi SQL: " + sqlEx.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi khi tải dữ liệu: " + ex.Message, "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private void txtMaHDN_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
