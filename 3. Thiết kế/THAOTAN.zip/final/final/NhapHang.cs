﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Transactions;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace final
{
    public partial class NhapHang : Form
    {
        string scon = "Data Source=PC;Initial Catalog=THAOTAN;Integrated Security=True;Encrypt=False;Trust Server Certificate=True";
        private SqlTransaction transaction;

        public NhapHang()
        {
            InitializeComponent();
            data.ReadOnly = false;
            data.CellEndEdit += data_CellEndEdit;
        }

        private void TxtHangHoa_TextChanged(object sender, EventArgs e)
        {

        }

        private void HoaDon_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }




        private void menu_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txt_MaDBH_TextChanged(object sender, EventArgs e)
        {

        }



        private void date_ValueChanged(object sender, EventArgs e)
        {

        }
        //menu
        private void btBH_Click(object sender, EventArgs e)
        {
            this.Close();
            BanHang banHang = new BanHang();
            banHang.Show();
        }

        private void btNH_Click(object sender, EventArgs e)
        {
        }
        private void btHangHoa_Click(object sender, EventArgs e)
        {
            this.Close();
            frmHangHoa frmhanghoa = new frmHangHoa();
            frmhanghoa.Show();
        }

        private void btKH_Click(object sender, EventArgs e)
        {
            this.Close();
            KhachHang KhacHang = new KhachHang();
            KhacHang.Show();
        }

        private void btNCC_Click(object sender, EventArgs e)
        {
            this.Close();
            NCC nCC = new NCC();
            nCC.Show();
        }
        private void btHoaDon_MouseHover(object sender, EventArgs e)
        {
            btHDN.Visible = true;
            btHDB.Visible = true;
        }

        private void btHDB_Click(object sender, EventArgs e)
        {
            this.Close();
            HDBH hDBH = new HDBH();
            hDBH.Show();
        }

        private void btHDN_Click(object sender, EventArgs e)
        {
            this.Close();
            HDNH dnH = new HDNH();
            dnH.Show();
        }

        private void btNo_MouseHover(object sender, EventArgs e)
        {
            btCNKH.Visible = true;
            btCNNCC.Visible = true;
        }

        private void btCNKH_Click(object sender, EventArgs e)
        {
            this.Close();
            NoKH noKH = new NoKH();
            noKH.Show();
        }

        private void btCNNCC_Click(object sender, EventArgs e)
        {
            this.Close();
            NoNCC NoNCC = new NoNCC();
            NoNCC.Show();
        }


        //menu//
        //load// MaDBH
        private void NhapHang_Load(object sender, EventArgs e)
        {
            string tenBang = "Nhap"; // Thay đổi tên bảng theo nhu cầu

            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (SqlCommand command = new SqlCommand("SELECT dbo.TaoMaMoi(@TenBang) AS NewMaDNH", connection))
                {
                    command.Parameters.AddWithValue("@TenBang", tenBang);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        // Lấy mã hàng hóa mới và hiển thị trong TextBox
                        txt_MaDNH.Text = reader["NewMaDNH"].ToString();
                        txt_MaDNH.Enabled = false;
                    }
                }
            }
        }

        private void data_CellEndEdit(object sender, DataGridViewCellEventArgs e)
        {
            // Kiểm tra xem cột đang chỉnh sửa có phải là cột mã hàng hóa không
            if (e.ColumnIndex == data.Columns["MaHH"].Index) // Thay "MaHH" bằng tên cột thực tế
            {
                // Kiểm tra chỉ số hàng hợp lệ
                if (e.RowIndex >= 0 && e.RowIndex < data.Rows.Count)
                {
                    // Cập nhật số thứ tự
                    data.Rows[e.RowIndex].Cells["STT"].Value = e.RowIndex + 1;

                    // Lấy giá trị mã hàng hóa
                    var maHHCell = data.Rows[e.RowIndex].Cells[e.ColumnIndex].Value;
                    string maHH = maHHCell != null ? maHHCell.ToString().Trim() : string.Empty;

                    if (!string.IsNullOrEmpty(maHH))
                    {
                        try
                        {
                            bool isValid = CheckMaHH(maHH);

                            if (isValid)
                            {
                                LoadHangHoaInfo(maHH, e.RowIndex);
                            }
                            else
                            {
                                // Kiểm tra xem thông báo đã được hiển thị chưa
                                if (data.Rows[e.RowIndex].Cells["TenHH"].Value == null) // Hoặc một điều kiện khác để xác định
                                {
                                    DialogResult result = MessageBox.Show("Mã hàng hóa không tồn tại! Thêm thông tin hàng hóa mới", "Thông báo", MessageBoxButtons.YesNo);
                                    if (result == DialogResult.Yes)
                                    {

                                        this.Hide();
                                        // Mở form thêm hàng hóa mới
                                        ThemHH themHH = new ThemHH();
                                        themHH.Show();
                                    }
                                }
                            }
                        }
                        catch (Exception ex)
                        {
                            MessageBox.Show("Đã xảy ra lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                    }
                }
                else
                {
                    MessageBox.Show("Chỉ số hàng không hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }

            // Kiểm tra xem cột đang chỉnh sửa có phải là cột Số lượng không
            if (e.ColumnIndex == data.Columns["SL"].Index) // Thay "SoLuong" bằng tên cột thực tế
            {
                string sl = data.Rows[e.RowIndex].Cells[e.ColumnIndex].Value?.ToString().Trim();
                if (!string.IsNullOrEmpty(sl))
                {
                    decimal donGia = 0;
                    if (decimal.TryParse(data.Rows[e.RowIndex].Cells["GiaNhap"].Value?.ToString(), out donGia))
                    {
                        // Lấy giá trị Số lượng
                        decimal soLuong = 0;
                        if (decimal.TryParse(data.Rows[e.RowIndex].Cells["SL"].Value?.ToString(), out soLuong))
                        {
                            // Tính Thành tiền
                            decimal thanhTien = donGia * soLuong;
                            // Cập nhật giá trị Thành tiền
                            data.Rows[e.RowIndex].Cells["ThanhTien"].Value = thanhTien;
                        }
                        else
                        {
                            // Nếu Số lượng không hợp lệ, có thể đặt Thành tiền về 0
                            data.Rows[e.RowIndex].Cells["ThanhTien"].Value = 0;
                        }
                    }
                }


            }
        }


        private void LoadHangHoaInfo(string maHH, int rowIndex)
        {
            using (SqlConnection conn = new SqlConnection(scon))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM HHDV WHERE MaHHDV = @MaHH", conn))
                {
                    cmd.Parameters.AddWithValue("@MaHH", maHH);
                    SqlDataAdapter adapter = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    adapter.Fill(dt);

                    if (dt.Rows.Count > 0)
                    {
                        // Giả sử bạn có các cột khác như TênHH, Gia, SoLuong trong DataGridView
                        data.Rows[rowIndex].Cells["TenHH"].Value = dt.Rows[0]["TenHHDV"]; // Thay "TenHH" bằng tên cột thực tế

                    }
                    else
                    {
                        MessageBox.Show("Không tìm thấy thông tin hàng hóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
            }

        }

        private bool CheckMaHH(string maHH)
        {
            using (SqlConnection conn = new SqlConnection(scon))
            {
                using (SqlCommand cmd = new SqlCommand("SELECT dbo.ktraHH(@MaHH)", conn))
                {
                    cmd.Parameters.AddWithValue("@MaHH", maHH); // Tham số đầu vào

                    conn.Open();
                    var result = cmd.ExecuteScalar(); // Thực thi hàm và lấy giá trị trả về
                    return result != null && (bool)result; // Kiểm tra giá trị trả về
                }
            }
        }

        private void lb_MaKH_Click(object sender, EventArgs e)
        {

        }



        private void txtSDT_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtsdt_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string SDT = txtSDT.Text;
                if (!CheckSDT(SDT)) // Kiểm tra số điện thoại
                {
                    DialogResult result = MessageBox.Show("Nhà cung cấp mới. Bạn có muốn thêm thông tin nhà cung cấp không?",
                                                "Thông báo",
                                                MessageBoxButtons.OKCancel,
                                                MessageBoxIcon.Question);

                    if (result == DialogResult.OK)
                    {
                        this.Close();
                        EditNCC editNCC = new EditNCC();
                        editNCC.AddItem();
                        editNCC.Show();
                    }
                }
                else
                {
                    try
                    {
                        decimal thue = LayThue(SDT);
                        txtThue.Text = thue.ToString();
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show($"Đã xảy ra lỗi: {ex.Message}", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }

        private decimal LayThue(string sdt)
        {
            if (string.IsNullOrEmpty(sdt))
            {
                throw new ArgumentException("Số điện thoại không được để trống.");
            }

            decimal thue = 0; // Khởi tạo giá trị thuế
            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (var command = new SqlCommand("layThue", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Thêm tham số vào thủ tục
                    command.Parameters.Add(new SqlParameter("@SDT", sdt));

                    // Tham số đầu ra với kích thước
                    var thueParam = new SqlParameter("@Thue", SqlDbType.Float)
                    {
                        Direction = ParameterDirection.Output
                    };
                    command.Parameters.Add(thueParam);

                    try
                    {
                        // Mở kết nối và thực thi thủ tục
                        connection.Open();
                        command.ExecuteNonQuery();

                        // Lấy giá trị từ tham số đầu ra
                        if (thueParam.Value != DBNull.Value)
                        {
                            thue = Convert.ToDecimal(thueParam.Value);
                        }
                        else
                        {
                            throw new Exception("Giá trị thuế không hợp lệ.");
                        }
                    }
                    catch (SqlException ex)
                    {
                        // Xử lý lỗi SQL
                        MessageBox.Show("Lỗi khi thực thi thủ tục: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        // Xử lý lỗi chung
                        MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            return thue; // Trả về giá trị thuế
        }
        private bool CheckSDT(string sDT)
        {
            bool exists = false;

            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (var command = new SqlCommand("ktNCC", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Thêm tham số vào thủ tục
                    command.Parameters.Add(new SqlParameter("@SDT", sDT));

                    // Tham số đầu ra
                    var existsParameter = new SqlParameter("@ret", SqlDbType.Bit)
                    {
                        Direction = ParameterDirection.Output
                    };
                    command.Parameters.Add(existsParameter);

                    // Mở kết nối và thực thi thủ tục
                    connection.Open();
                    command.ExecuteNonQuery();

                    // Lấy giá trị từ tham số đầu ra
                    exists = (bool)existsParameter.Value;
                }
            }
            return exists;

        }

        private void thue_TextChanged(object sender, EventArgs e)
        {

        }



        private void btHT_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn cập nhật thông tin không?", "Xác nhận", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {

                InsertData(dateTimePicker: date);

            }
        }

        private void InsertData(DateTimePicker dateTimePicker)
        {
            using (SqlConnection connection = new SqlConnection(scon))
            {
                decimal tong = decimal.Parse(txtTong.Text);
                decimal thanhtoan = decimal.Parse(txtThanhToan.Text); // Giả sử bạn có một TextBox cho số tiền đã trả

                string paymentStatus;

                // Kiểm tra số tiền đã trả
                if (thanhtoan == tong)
                {
                    paymentStatus = "HT"; // Hoàn thành
                }
                else
                {
                    paymentStatus = "N"; // Nợ
                }
                using (SqlCommand command = new SqlCommand("pInsertHDN", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;

                    // Kiểm tra các tham số đầu vào
                    if (string.IsNullOrEmpty(txt_MaDNH.Text) || txt_MaDNH.Text.Length != 6)
                    {
                        MessageBox.Show("Mã đơn nhập hàng phải có đúng 6 ký tự.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (string.IsNullOrEmpty(txtSDT.Text))
                    {
                        MessageBox.Show("Số điện thoại không được để trống.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    if (!decimal.TryParse(txtTong.Text, out decimal tongTien))
                    {
                        MessageBox.Show("Tổng tiền không hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }

                    // Thêm các tham số
                    command.Parameters.AddWithValue("@MaDNH", txt_MaDNH.Text.PadRight(6, ' ')); // Đảm bảo độ dài 6 ký tự cho CHAR(6)

                    string maNCC = MaNCC(txtSDT.Text);
                    if (string.IsNullOrEmpty(maNCC) || maNCC.Length != 6)
                    {
                        MessageBox.Show("Không tìm thấy mã nhà cung cấp cho số điện thoại đã nhập hoặc mã khách hàng không hợp lệ.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        return;
                    }
                    command.Parameters.AddWithValue("@MaNCC", maNCC.PadRight(6, ' ')); // Đảm bảo độ dài 6 ký tự cho CHAR(6)

                    DateTime selectedDate = date.Value; // Lấy giá trị từ DateTimePicker
                    command.Parameters.AddWithValue("@NgayNhap", selectedDate);

                    string httt = txtHTTT.Text; // Giả sử bạn có một TextBox để nhập hình thức thanh toán
                    if (httt.Equals("Tiền mặt", StringComparison.OrdinalIgnoreCase))
                    {
                        httt = "TM"; // Chuyển đổi thành "TM"
                    }
                    else
                    {
                        httt = "CK"; // Chuyển đổi thành "CK"
                    }

                    command.Parameters.AddWithValue("@HTTT", httt.Length > 10 ? httt.Substring(0, 10) : httt); // Đảm bảo không vượt quá 10 ký tự
                    command.Parameters.AddWithValue("@Tong", tongTien);

                    command.Parameters.AddWithValue("@TrangThai", paymentStatus); // Trạng thái mặc định


                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Thêm thành công!", "Thông báo");
                        }
                        else
                        {
                            MessageBox.Show("Không thành công, hãy thử lại.", "Thông báo");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi: " + ex.Message + "\n" + ex.StackTrace);
                    }
                }

                foreach (DataGridViewRow row in data.Rows)
                {
                    string maDNH = txt_MaDNH.Text;
                    if (row.IsNewRow) continue;

                    string maHHDV = row.Cells["MaHH"].Value?.ToString();
                    if (string.IsNullOrEmpty(maHHDV))
                    {
                        MessageBox.Show("Mã hàng hóa dịch vụ không được để trống.", "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        continue;
                    }

                    if (!decimal.TryParse(row.Cells["SL"].Value?.ToString(), out decimal slnhap))
                    {
                        MessageBox.Show("Số lượng nhập không hợp lệ cho hàng: " + maHHDV, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        continue;
                    }
                    decimal GiaNhap = Convert.ToDecimal(row.Cells["GiaNhap"].Value?.ToString());

                    using (SqlCommand command = new SqlCommand("INSERT INTO NhapChiTiet (MaDNH,MaHHDV, SLNhap,GiaNhap) VALUES (@MaDNH,@MaHHDV, @SLNhap,@GiaNhap)", connection, transaction))
                    {
                        command.Parameters.AddWithValue("@MaDNH", maDNH);
                        command.Parameters.AddWithValue("@MaHHDV", maHHDV);
                        command.Parameters.AddWithValue("@SLNhap", slnhap);
                        command.Parameters.AddWithValue("@GiaNhap", GiaNhap);

                        command.ExecuteNonQuery();
                    }
                }

                if (paymentStatus == "N")
                {
                    using (SqlCommand command = new SqlCommand("INSERT INTO HoaDonNoNCC (MaNoNCC,MaDNH, NgayLap,SoTienTT,SoNoConLai,HTTT) VALUES (@MaPTNCC,@MaDNH, @NgayLap,@SoTienTT,@SoNoConLai,@HTTT)", connection, transaction))
                    {
                        string newMa;
                        if (MaPTNCC(out newMa))
                        {
                            // Gán giá trị cho tham số
                            command.Parameters.AddWithValue("@MaPTNCC", newMa);
                        }
                        else
                        {
                            // Xử lý lỗi
                            Console.WriteLine("Không thể tạo mã mới.");
                        }
                        DateTime selectedDate = date.Value;

                        command.Parameters.AddWithValue("@MaDNH", txt_MaDNH.Text);
                        command.Parameters.AddWithValue("@NgayLap", selectedDate);
                        command.Parameters.AddWithValue("@SoTienTT", txtThanhToan.Text);

                        decimal conlai = tong - thanhtoan;
                        command.Parameters.AddWithValue("SoNoConLai", conlai);


                        string httt = txtHTTT.Text; // Giả sử bạn có một TextBox để nhập hình thức thanh toán
                        if (httt.Equals("Tiền mặt", StringComparison.OrdinalIgnoreCase))
                        {
                            httt = "TM"; // Chuyển đổi thành "TM"
                        }
                        else
                        {
                            httt = "CK"; // Chuyển đổi thành "CK"
                        }
                        command.Parameters.AddWithValue("@HTTT", httt);
                        command.ExecuteNonQuery();
                    }
                }
            }
            ReloadSalesForm();
        }

        private bool MaPTNCC(out string newMaPTNCC)
        {
            newMaPTNCC = null; // Khởi tạo giá trị mặc định
            string tenBang = "HoaDonNoNCC"; // Thay đổi tên bảng theo nhu cầu

            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (SqlCommand command = new SqlCommand("SELECT dbo.TaoMaMoi(@TenBang) AS NewMaDNH", connection))
                {
                    command.Parameters.AddWithValue("@TenBang", tenBang);
                    connection.Open();

                    using (SqlDataReader reader = command.ExecuteReader())
                    {
                        if (reader.Read())
                        {
                            newMaPTNCC = reader["NewMaDNH"].ToString();
                            return true; // Trả về true nếu thành công
                        }
                        else
                        {
                            return false; // Trả về false nếu không có dữ liệu
                        }
                    }
                }
            }
        }

        private void ReloadSalesForm()
        {
            string tenBang = "Nhap"; // Thay đổi tên bảng theo nhu cầu

            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (SqlCommand command = new SqlCommand("SELECT dbo.TaoMaMoi(@TenBang) AS NewMaDNH", connection))
                {
                    command.Parameters.AddWithValue("@TenBang", tenBang);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        // Lấy mã hàng hóa mới và hiển thị trong TextBox
                        txt_MaDNH.Text = reader["NewMaDNH"].ToString();
                        txt_MaDNH.Enabled = false;
                    }
                }
            }
            txtSDT.Text = string.Empty; // Đặt lại TextBox cho số điện thoại
            txtHTTT.Text = string.Empty; // Đặt lại TextBox cho hình thức thanh toán
            txtThue.Text = string.Empty;
            txtTong.Text = string.Empty;
            txtThanhToan.Text = string.Empty;
            data.Rows.Clear();
            date.Value = DateTime.Now;

        }

        private string MaNCC(string sdt)
        {
            if (string.IsNullOrEmpty(sdt))
            {
                throw new ArgumentException("Số điện thoại không được để trống.");
            }

            string exists = null;
            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (var command = new SqlCommand("layMaNCC", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Thêm tham số vào thủ tục
                    command.Parameters.Add(new SqlParameter("@SDT", sdt));

                    // Tham số đầu ra với kích thước
                    var maNCC = new SqlParameter("@MaNCC", SqlDbType.Char, 6) // Thay 6 bằng kích thước thực tế của mã khách hàng
                    {
                        Direction = ParameterDirection.Output
                    };
                    command.Parameters.Add(maNCC);

                    try
                    {
                        // Mở kết nối và thực thi thủ tục
                        connection.Open();
                        command.ExecuteNonQuery();

                        // Lấy giá trị từ tham số đầu ra
                        exists = maNCC.Value?.ToString().Trim(); // Chuyển đổi thành chuỗi và loại bỏ khoảng trắng
                    }
                    catch (SqlException ex)
                    {
                        // Xử lý lỗi SQL
                        MessageBox.Show("Lỗi khi thực thi thủ tục: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        // Xử lý lỗi chung
                        MessageBox.Show("Lỗi: " + ex.Message, "Lỗi", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            return exists;
        }

        private void btHuy_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn hủy bỏ thông tin không?", "Xác nhận", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {

                txtSDT.Text = string.Empty; // Đặt lại TextBox cho số điện thoại
                txtHTTT.Text = string.Empty; // Đặt lại TextBox cho hình thức thanh toán
                txtThue.Text = string.Empty;
                txtTong.Text = string.Empty;
                data.Rows.Clear();
                date.Value = DateTime.Now;

            }

        }


        private void txtTong_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void txtThanhToan_TextChanged(object sender, EventArgs e)
        {

        }

        private void logo_Click(object sender, EventArgs e)
        {

        }

        private void txtTong_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                decimal thue = Convert.ToDecimal(txtThue.Text);
                decimal tongThanhTien = 0;
                foreach (DataGridViewRow row in data.Rows)
                {
                    // Kiểm tra xem hàng có phải là hàng mới không (hàng mới không có dữ liệu)
                    if (row.Cells["ThanhTien"].Value != null)
                    {
                        // Lấy giá trị thành tiền từ cột "ThanhTien"
                        if (decimal.TryParse(row.Cells["ThanhTien"].Value.ToString(), out decimal thanhTien))
                        {
                            // Cộng dồn vào tổng
                            tongThanhTien += thanhTien;
                        }
                    }
                }
                decimal tongtien = tongThanhTien + tongThanhTien * thue;
                txtTong.Text = tongtien.ToString();
            }
            
        }
    }
}
