﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace final
{
    public partial class NoNCC : Form
    {
        string scon = "Data Source=PC;Initial Catalog=THAOTAN;Integrated Security=True;Encrypt=False;Trust Server Certificate=True";

        public NoNCC()
        {
            InitializeComponent();
        }
        private DataTable originalDataTable;

        private void NoNCC_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(scon);
            try
            {
                con.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show("Xảy ra lỗi kết nối đến cơ sở dữ liệu: " + ex.Message);
                return; // Thoát khỏi phương thức nếu không thể kết nối
            }

            string squery = "SELECT * FROM HoaDonNoNCC"; // Thêm khoảng trắng giữa SELECT và *
            SqlDataAdapter adapter = new SqlDataAdapter(squery, con);
            DataSet ds = new DataSet();

            try
            {
                adapter.Fill(ds, "HoaDonNoNCC");
                originalDataTable = ds.Tables["HoaDonNoNCC"]; // Gán DataSource từ DataSet
                data.DataSource = originalDataTable;

                // Kiểm tra và chuyển đổi giá trị cột
                foreach (DataGridViewRow row in data.Rows)
                {
                    if (row.Cells["HTTT"].Value != null) // Thay đổi "HTTT" thành tên cột thực tế
                    {
                        string value = row.Cells["HTTT"].Value.ToString();
                        if (value == "CK")
                        {
                            row.Cells["HTTT"].Value = "Chuyển khoản"; // Thay đổi giá trị thành "Chuyển khoản"
                        }
                        else
                        {
                            row.Cells["HTTT"].Value = "Tiền mặt"; // Thay đổi giá trị thành "Tiền mặt"
                        }
                    }
                }

                // Thiết lập tiêu đề cột
                data.Columns["MaNoNCC"].HeaderText = "Mã NCC"; // Thay "MaNoNCC" bằng tên cột thực tế
                data.Columns["MaDNH"].HeaderText = "Mã DNH"; // Thay "MaDNH" bằng tên cột thực tế
                data.Columns["NgayLap"].HeaderText = "Ngày lập";
                data.Columns["SoTienTT"].HeaderText = "Thanh toán";
                data.Columns["SoNoConLai"].HeaderText = "Còn lại";
                data.Columns["HTTT"].HeaderText = "Hình thức thanh toán";
            }
            catch (Exception ex)
            {
                MessageBox.Show("Lỗi khi tải dữ liệu: " + ex.Message);
            }
            finally
            {
                con.Close(); // Đảm bảo kết nối được đóng
            }
        }

        private void data_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void sbSearch_Paint(object sender, PaintEventArgs e)
        {

        }
        //menu
        private void BH_click(object sender, EventArgs e)
        {
            this.Close();
            BanHang banHang = new BanHang();
            banHang.Show();
        }

        private void NH_click(object sender, EventArgs e)
        {
            this.Close();
            NhapHang nhapHang = new NhapHang();
            nhapHang.Show();

        }

        private void btHangHoa_Click(object sender, EventArgs e)
        {
            this.Close();
            frmHangHoa frmHangHoa = new frmHangHoa();
            frmHangHoa.Show();
        }

        private void btKH_Click(object sender, EventArgs e)
        {
            this.Close();
            KhachHang khachHang = new KhachHang();
            khachHang.Show();
        }

        private void btNCC_Click(object sender, EventArgs e)
        {
            this.Close();
            NCC nCC = new NCC();
            nCC.Show();
        }
        private void btHoaDon_MouseHover(object sender, EventArgs e)
        {
            btHDN.Visible = true;
            btHDB.Visible = true;
        }

        private void btHDB_Click(object sender, EventArgs e)
        {
            this.Close();
            HDBH hDBH = new HDBH();
            hDBH.Show();
        }

        private void btHDN_Click(object sender, EventArgs e)
        {
            this.Close();
            HDNH dnH = new HDNH();
            dnH.Show();
        }

        private void btNo_MouseHover(object sender, EventArgs e)
        {
            btCNKH.Visible = true;
            btCNNCC.Visible = true;
        }

        private void btCNKH_Click(object sender, EventArgs e)
        {
            this.Close();
            NoKH noKH = new NoKH();
            noKH.Show();
        }

        private void btCNNCC_Click(object sender, EventArgs e)
        {
            this.Close();
            NoNCC NoNCC = new NoNCC();
            NoNCC.Show();
        }

        private void txtMaNoNCC_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string searchValue = txtMaPTNCC.Text.Trim();

                // Kiểm tra nếu DataGridView có dữ liệu
                if (data.Rows.Count > 0)
                {
                    bool found = false; // Biến để theo dõi xem có tìm thấy hay không

                    // Tìm kiếm trong từng hàng
                    foreach (DataGridViewRow row in data.Rows)
                    {
                        // Kiểm tra nếu hàng không phải là hàng tiêu đề
                        if (row.Cells["MaNoNCC"].Value != null && row.Cells["MaNoNCC"].Value.ToString().ToLower().Contains(searchValue.ToLower()))
                        {
                            // Chọn hàng tìm thấy
                            row.Selected = true;
                            data.CurrentCell = row.Cells[0]; // Chọn ô đầu tiên của hàng
                            found = true; // Đánh dấu là đã tìm thấy
                            break; // Dừng vòng lặp khi tìm thấy
                        }
                    }

                    if (!found)
                    {
                        // Nếu không tìm thấy
                        MessageBox.Show("Không tìm thấy thông tin hóa đơn", "Kết quả tìm kiếm", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Không có dữ liệu để tìm kiếm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                // Xóa nội dung trong TextBox sau khi tìm kiếm
                txtMaPTNCC.Text = string.Empty;
            }
        }

        private void txtMaDNH_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string searchValue = txtMaDNH.Text.Trim();

                // Check if DataGridView has data
                if (data.Rows.Count > 0)
                {
                    // Create a new DataTable to store found rows
                    DataTable filteredTable = new DataTable();

                    // Copy the structure of the DataGridView into the DataTable
                    foreach (DataGridViewColumn column in data.Columns)
                    {
                        filteredTable.Columns.Add(column.Name, column.ValueType);
                    }

                    // Search through each row
                    foreach (DataGridViewRow row in data.Rows)
                    {
                        // Check if the row is not a header row
                        if (row.Cells["MaDNH"].Value != null && row.Cells["MaDNH"].Value.ToString().ToLower().Contains(searchValue.ToLower()))
                        {
                            // Add found row to DataTable
                            DataRow newRow = filteredTable.NewRow();
                            for (int i = 0; i < row.Cells.Count; i++)
                            {
                                newRow[i] = row.Cells[i].Value;
                            }
                            filteredTable.Rows.Add(newRow);
                        }
                    }

                    // Check if any rows were found
                    if (filteredTable.Rows.Count > 0)
                    {
                        // Set the DataTable to the DataGridView
                        data.DataSource = filteredTable;
                    }
                    else
                    {
                        // If no rows found
                        MessageBox.Show("Không tìm thấy thông tin hóa đơn", "Kết quả tìm kiếm", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Không có dữ liệu để tìm kiếm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                // If the TextBox is empty, reset to original data
                if (string.IsNullOrEmpty(txtMaDNH.Text))
                {
                    data.DataSource = originalDataTable; // Reset to original data
                }

                // Clear the TextBox after searching
                txtMaDNH.Text = string.Empty;
            }
        }

        private void btThem_Click(object sender, EventArgs e)
        {
            EditNoNCC editNoNCC = new EditNoNCC();
            this.Close();
            editNoNCC.Show();

        }
    }
}
