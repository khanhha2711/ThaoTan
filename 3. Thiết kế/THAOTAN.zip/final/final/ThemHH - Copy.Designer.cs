﻿
namespace final
{
    partial class ThemHH
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ThemHH));
            sqlCommand1 = new Microsoft.Data.SqlClient.SqlCommand();
            btHuy = new Button();
            HoaDon = new Panel();
            textBox7 = new TextBox();
            txtLoai = new TextBox();
            label9 = new Label();
            txtDonVi = new TextBox();
            label8 = new Label();
            txtGia = new TextBox();
            label6 = new Label();
            txtSL = new TextBox();
            label5 = new Label();
            btHT = new Button();
            txtTenHH = new TextBox();
            label2 = new Label();
            txtMaHH = new TextBox();
            label1 = new Label();
            txtHangHoa = new TextBox();
            title = new Panel();
            sidebar = new Panel();
            btNH = new Button();
            btBH = new Button();
            btCNNCC = new Button();
            btCNKH = new Button();
            btHDN = new Button();
            btHDB = new Button();
            btNo = new Button();
            btHoaDon = new Button();
            btNCC = new Button();
            btKH = new Button();
            btHangHoa = new Button();
            logo = new PictureBox();
            HoaDon.SuspendLayout();
            title.SuspendLayout();
            sidebar.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)logo).BeginInit();
            SuspendLayout();
            // 
            // sqlCommand1
            // 
            sqlCommand1.CommandTimeout = 30;
            sqlCommand1.EnableOptimizedParameterBinding = false;
            // 
            // btHuy
            // 
            btHuy.BackColor = Color.FromArgb(0, 43, 92);
            btHuy.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHuy.ForeColor = SystemColors.ButtonHighlight;
            btHuy.Location = new Point(923, 670);
            btHuy.Name = "btHuy";
            btHuy.Size = new Size(146, 45);
            btHuy.TabIndex = 7;
            btHuy.Text = "Hủy bỏ";
            btHuy.UseVisualStyleBackColor = false;
            btHuy.Click += btHuy_Click;
            // 
            // HoaDon
            // 
            HoaDon.BackColor = Color.FromArgb(255, 255, 255);
            HoaDon.Controls.Add(textBox7);
            HoaDon.Controls.Add(txtLoai);
            HoaDon.Controls.Add(label9);
            HoaDon.Controls.Add(txtDonVi);
            HoaDon.Controls.Add(label8);
            HoaDon.Controls.Add(txtGia);
            HoaDon.Controls.Add(label6);
            HoaDon.Controls.Add(txtSL);
            HoaDon.Controls.Add(label5);
            HoaDon.Controls.Add(btHuy);
            HoaDon.Controls.Add(btHT);
            HoaDon.Controls.Add(txtTenHH);
            HoaDon.Controls.Add(label2);
            HoaDon.Controls.Add(txtMaHH);
            HoaDon.Controls.Add(label1);
            HoaDon.Location = new Point(455, 138);
            HoaDon.Margin = new Padding(4, 3, 4, 3);
            HoaDon.Name = "HoaDon";
            HoaDon.Size = new Size(1352, 789);
            HoaDon.TabIndex = 6;
            // 
            // textBox7
            // 
            textBox7.BorderStyle = BorderStyle.None;
            textBox7.Font = new Font("Arial", 16F, FontStyle.Bold);
            textBox7.ForeColor = Color.FromArgb(0, 43, 92);
            textBox7.Location = new Point(66, 41);
            textBox7.Margin = new Padding(4, 3, 4, 3);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(403, 31);
            textBox7.TabIndex = 33;
            textBox7.TabStop = false;
            textBox7.Text = "THÊM HÀNG HÓA";
            // 
            // txtLoai
            // 
            txtLoai.BackColor = SystemColors.InactiveBorder;
            txtLoai.Location = new Point(381, 398);
            txtLoai.Name = "txtLoai";
            txtLoai.Size = new Size(219, 30);
            txtLoai.TabIndex = 2;
            txtLoai.TextChanged += txtLoai_TextChanged;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.ForeColor = SystemColors.ActiveCaptionText;
            label9.Location = new Point(268, 401);
            label9.Name = "label9";
            label9.Size = new Size(47, 23);
            label9.TabIndex = 32;
            label9.Text = "Loại";
            // 
            // txtDonVi
            // 
            txtDonVi.BackColor = SystemColors.InactiveBorder;
            txtDonVi.Location = new Point(856, 394);
            txtDonVi.Name = "txtDonVi";
            txtDonVi.Size = new Size(213, 30);
            txtDonVi.TabIndex = 3;
            txtDonVi.TextChanged += textBox5_TextChanged;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.ForeColor = SystemColors.ActiveCaptionText;
            label8.Location = new Point(741, 401);
            label8.Name = "label8";
            label8.Size = new Size(66, 23);
            label8.TabIndex = 30;
            label8.Text = "Đơn vị";
            // 
            // txtGia
            // 
            txtGia.BackColor = SystemColors.InactiveBorder;
            txtGia.Location = new Point(381, 506);
            txtGia.Name = "txtGia";
            txtGia.Size = new Size(219, 30);
            txtGia.TabIndex = 4;
            txtGia.TextChanged += txtGia_TextChanged;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.ForeColor = SystemColors.ActiveCaptionText;
            label6.Location = new Point(268, 509);
            label6.Name = "label6";
            label6.Size = new Size(79, 23);
            label6.TabIndex = 28;
            label6.Text = "Giá bán";
            // 
            // txtSL
            // 
            txtSL.BackColor = SystemColors.InactiveBorder;
            txtSL.Location = new Point(856, 506);
            txtSL.Name = "txtSL";
            txtSL.Size = new Size(213, 30);
            txtSL.TabIndex = 5;
            txtSL.TextChanged += textBox3_TextChanged;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.ForeColor = SystemColors.ActiveCaptionText;
            label5.Location = new Point(741, 513);
            label5.Name = "label5";
            label5.Size = new Size(91, 23);
            label5.TabIndex = 26;
            label5.Text = "Số lượng";
            // 
            // btHT
            // 
            btHT.BackColor = Color.FromArgb(0, 43, 92);
            btHT.Font = new Font("Arial", 12F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHT.ForeColor = SystemColors.ButtonHighlight;
            btHT.Location = new Point(733, 670);
            btHT.Name = "btHT";
            btHT.Size = new Size(146, 45);
            btHT.TabIndex = 6;
            btHT.Text = "Hoàn thành";
            btHT.UseVisualStyleBackColor = false;
            btHT.Click += btHT_Click;
            // 
            // txtTenHH
            // 
            txtTenHH.BackColor = SystemColors.InactiveBorder;
            txtTenHH.Location = new Point(381, 289);
            txtTenHH.Name = "txtTenHH";
            txtTenHH.Size = new Size(688, 30);
            txtTenHH.TabIndex = 0;
            txtTenHH.TextChanged += txtTenHH_TextChanged;
            txtTenHH.KeyDown += txtTenHH_KeyDown;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.ForeColor = SystemColors.ActiveCaptionText;
            label2.Location = new Point(268, 292);
            label2.Name = "label2";
            label2.Size = new Size(102, 23);
            label2.TabIndex = 0;
            label2.Text = "Tên HHDV";
            // 
            // txtMaHH
            // 
            txtMaHH.BackColor = SystemColors.InactiveBorder;
            txtMaHH.Location = new Point(381, 185);
            txtMaHH.Name = "txtMaHH";
            txtMaHH.Size = new Size(219, 30);
            txtMaHH.TabIndex = 1;
            txtMaHH.TabStop = false;
            txtMaHH.TextChanged += txtMaHH_TextChanged;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.ForeColor = SystemColors.ActiveCaptionText;
            label1.Location = new Point(268, 188);
            label1.Name = "label1";
            label1.Size = new Size(97, 23);
            label1.TabIndex = 0;
            label1.Text = "Mã HHDV";
            // 
            // txtHangHoa
            // 
            txtHangHoa.BorderStyle = BorderStyle.None;
            txtHangHoa.Font = new Font("Arial", 20F, FontStyle.Bold);
            txtHangHoa.ForeColor = Color.FromArgb(0, 43, 92);
            txtHangHoa.Location = new Point(45, 31);
            txtHangHoa.Margin = new Padding(4, 3, 4, 3);
            txtHangHoa.Name = "txtHangHoa";
            txtHangHoa.Size = new Size(403, 39);
            txtHangHoa.TabIndex = 0;
            txtHangHoa.TabStop = false;
            txtHangHoa.Text = "HÀNG HÓA";
            // 
            // title
            // 
            title.BackColor = Color.FromArgb(255, 255, 255);
            title.Controls.Add(txtHangHoa);
            title.Location = new Point(336, 0);
            title.Margin = new Padding(4, 3, 4, 3);
            title.Name = "title";
            title.Size = new Size(1644, 110);
            title.TabIndex = 5;
            // 
            // sidebar
            // 
            sidebar.BackColor = Color.FromArgb(0, 43, 92);
            sidebar.Controls.Add(btNH);
            sidebar.Controls.Add(btBH);
            sidebar.Controls.Add(btCNNCC);
            sidebar.Controls.Add(btCNKH);
            sidebar.Controls.Add(btHDN);
            sidebar.Controls.Add(btHDB);
            sidebar.Controls.Add(btNo);
            sidebar.Controls.Add(btHoaDon);
            sidebar.Controls.Add(btNCC);
            sidebar.Controls.Add(btKH);
            sidebar.Controls.Add(btHangHoa);
            sidebar.Controls.Add(logo);
            sidebar.Location = new Point(0, 0);
            sidebar.Margin = new Padding(4, 3, 4, 3);
            sidebar.Name = "sidebar";
            sidebar.Padding = new Padding(28, 23, 28, 23);
            sidebar.Size = new Size(336, 1178);
            sidebar.TabIndex = 7;
            // 
            // btNH
            // 
            btNH.FlatAppearance.BorderSize = 0;
            btNH.FlatAppearance.MouseDownBackColor = Color.White;
            btNH.FlatStyle = FlatStyle.Flat;
            btNH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btNH.ForeColor = Color.White;
            btNH.Location = new Point(39, 243);
            btNH.Margin = new Padding(4, 3, 4, 3);
            btNH.Name = "btNH";
            btNH.Size = new Size(210, 43);
            btNH.TabIndex = 11;
            btNH.TabStop = false;
            btNH.Text = "Nhập hàng";
            btNH.TextAlign = ContentAlignment.MiddleLeft;
            btNH.UseVisualStyleBackColor = true;
            btNH.Click += btNH_Click;
            // 
            // btBH
            // 
            btBH.FlatAppearance.BorderSize = 0;
            btBH.FlatAppearance.MouseDownBackColor = Color.White;
            btBH.FlatStyle = FlatStyle.Flat;
            btBH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btBH.ForeColor = Color.White;
            btBH.Location = new Point(44, 153);
            btBH.Margin = new Padding(4, 3, 4, 3);
            btBH.Name = "btBH";
            btBH.Size = new Size(210, 43);
            btBH.TabIndex = 10;
            btBH.TabStop = false;
            btBH.Text = "Bán hàng";
            btBH.TextAlign = ContentAlignment.MiddleLeft;
            btBH.UseVisualStyleBackColor = true;
            btBH.Click += btBH_Click;
            // 
            // btCNNCC
            // 
            btCNNCC.FlatAppearance.BorderSize = 0;
            btCNNCC.FlatAppearance.MouseDownBackColor = Color.White;
            btCNNCC.FlatStyle = FlatStyle.Flat;
            btCNNCC.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btCNNCC.ForeColor = Color.White;
            btCNNCC.Location = new Point(80, 856);
            btCNNCC.Margin = new Padding(4, 3, 4, 3);
            btCNNCC.Name = "btCNNCC";
            btCNNCC.Size = new Size(243, 43);
            btCNNCC.TabIndex = 9;
            btCNNCC.TabStop = false;
            btCNNCC.Text = "Nhà cung cấp";
            btCNNCC.TextAlign = ContentAlignment.MiddleLeft;
            btCNNCC.UseVisualStyleBackColor = true;
            btCNNCC.Visible = false;
            btCNNCC.Click += btCNNCC_Click;
            // 
            // btCNKH
            // 
            btCNKH.FlatAppearance.BorderSize = 0;
            btCNKH.FlatAppearance.MouseDownBackColor = Color.White;
            btCNKH.FlatStyle = FlatStyle.Flat;
            btCNKH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btCNKH.ForeColor = Color.White;
            btCNKH.Location = new Point(80, 807);
            btCNKH.Margin = new Padding(4, 3, 4, 3);
            btCNKH.Name = "btCNKH";
            btCNKH.Size = new Size(224, 43);
            btCNKH.TabIndex = 8;
            btCNKH.TabStop = false;
            btCNKH.Text = "Khách hàng";
            btCNKH.TextAlign = ContentAlignment.MiddleLeft;
            btCNKH.UseVisualStyleBackColor = true;
            btCNKH.Visible = false;
            btCNKH.Click += btCNKH_Click;
            // 
            // btHDN
            // 
            btHDN.FlatAppearance.BorderSize = 0;
            btHDN.FlatAppearance.MouseDownBackColor = Color.White;
            btHDN.FlatStyle = FlatStyle.Flat;
            btHDN.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHDN.ForeColor = Color.White;
            btHDN.Location = new Point(80, 709);
            btHDN.Margin = new Padding(4, 3, 4, 3);
            btHDN.Name = "btHDN";
            btHDN.Size = new Size(238, 43);
            btHDN.TabIndex = 7;
            btHDN.TabStop = false;
            btHDN.Text = "Nhập hàng";
            btHDN.TextAlign = ContentAlignment.MiddleLeft;
            btHDN.UseVisualStyleBackColor = true;
            btHDN.Visible = false;
            btHDN.Click += btHDN_Click;
            // 
            // btHDB
            // 
            btHDB.FlatAppearance.BorderSize = 0;
            btHDB.FlatAppearance.MouseDownBackColor = Color.White;
            btHDB.FlatStyle = FlatStyle.Flat;
            btHDB.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHDB.ForeColor = Color.White;
            btHDB.Location = new Point(80, 658);
            btHDB.Margin = new Padding(4, 3, 4, 3);
            btHDB.Name = "btHDB";
            btHDB.Size = new Size(238, 43);
            btHDB.TabIndex = 6;
            btHDB.TabStop = false;
            btHDB.Text = "Bán hàng";
            btHDB.TextAlign = ContentAlignment.MiddleLeft;
            btHDB.UseVisualStyleBackColor = true;
            btHDB.Visible = false;
            btHDB.Click += btHDB_Click;
            // 
            // btNo
            // 
            btNo.FlatAppearance.BorderSize = 0;
            btNo.FlatAppearance.MouseDownBackColor = Color.White;
            btNo.FlatStyle = FlatStyle.Flat;
            btNo.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btNo.ForeColor = Color.White;
            btNo.Location = new Point(44, 761);
            btNo.Margin = new Padding(4, 3, 4, 3);
            btNo.Name = "btNo";
            btNo.Size = new Size(205, 43);
            btNo.TabIndex = 5;
            btNo.TabStop = false;
            btNo.Text = "Công nợ";
            btNo.TextAlign = ContentAlignment.MiddleLeft;
            btNo.UseVisualStyleBackColor = true;
            btNo.MouseHover += btNo_MouseHover;
            // 
            // btHoaDon
            // 
            btHoaDon.FlatAppearance.BorderSize = 0;
            btHoaDon.FlatAppearance.MouseDownBackColor = Color.White;
            btHoaDon.FlatStyle = FlatStyle.Flat;
            btHoaDon.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHoaDon.ForeColor = Color.White;
            btHoaDon.Location = new Point(44, 613);
            btHoaDon.Margin = new Padding(4, 3, 4, 3);
            btHoaDon.Name = "btHoaDon";
            btHoaDon.Size = new Size(169, 43);
            btHoaDon.TabIndex = 4;
            btHoaDon.TabStop = false;
            btHoaDon.Text = "Hóa đơn";
            btHoaDon.TextAlign = ContentAlignment.MiddleLeft;
            btHoaDon.UseVisualStyleBackColor = true;
            btHoaDon.MouseHover += btHoaDon_MouseHover;
            // 
            // btNCC
            // 
            btNCC.FlatAppearance.BorderSize = 0;
            btNCC.FlatAppearance.MouseDownBackColor = Color.White;
            btNCC.FlatStyle = FlatStyle.Flat;
            btNCC.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btNCC.ForeColor = Color.White;
            btNCC.Location = new Point(39, 519);
            btNCC.Margin = new Padding(4, 3, 4, 3);
            btNCC.Name = "btNCC";
            btNCC.Size = new Size(279, 43);
            btNCC.TabIndex = 3;
            btNCC.TabStop = false;
            btNCC.Text = "Nhà cung cấp";
            btNCC.TextAlign = ContentAlignment.MiddleLeft;
            btNCC.UseVisualStyleBackColor = true;
            btNCC.Click += btNCC_Click;
            // 
            // btKH
            // 
            btKH.FlatAppearance.BorderSize = 0;
            btKH.FlatAppearance.MouseDownBackColor = Color.White;
            btKH.FlatStyle = FlatStyle.Flat;
            btKH.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btKH.ForeColor = Color.White;
            btKH.Location = new Point(39, 430);
            btKH.Margin = new Padding(4, 3, 4, 3);
            btKH.Name = "btKH";
            btKH.Size = new Size(223, 43);
            btKH.TabIndex = 2;
            btKH.TabStop = false;
            btKH.Text = "Khách Hàng";
            btKH.TextAlign = ContentAlignment.MiddleLeft;
            btKH.UseVisualStyleBackColor = true;
            btKH.Click += btKH_Click;
            // 
            // btHangHoa
            // 
            btHangHoa.FlatAppearance.BorderSize = 0;
            btHangHoa.FlatAppearance.MouseDownBackColor = Color.White;
            btHangHoa.FlatStyle = FlatStyle.Flat;
            btHangHoa.Font = new Font("Arial", 13.8F, FontStyle.Bold, GraphicsUnit.Point, 0);
            btHangHoa.ForeColor = Color.White;
            btHangHoa.Location = new Point(39, 335);
            btHangHoa.Margin = new Padding(4, 3, 4, 3);
            btHangHoa.Name = "btHangHoa";
            btHangHoa.Size = new Size(210, 43);
            btHangHoa.TabIndex = 1;
            btHangHoa.TabStop = false;
            btHangHoa.Text = "Hàng hóa";
            btHangHoa.TextAlign = ContentAlignment.MiddleLeft;
            btHangHoa.UseVisualStyleBackColor = true;
            btHangHoa.Click += btHangHoa_Click;
            // 
            // logo
            // 
            logo.Image = (Image)resources.GetObject("logo.Image");
            logo.Location = new Point(32, 14);
            logo.Margin = new Padding(4, 3, 4, 3);
            logo.Name = "logo";
            logo.Size = new Size(94, 76);
            logo.SizeMode = PictureBoxSizeMode.StretchImage;
            logo.TabIndex = 0;
            logo.TabStop = false;
            // 
            // ThemHH
            // 
            AutoScaleDimensions = new SizeF(11F, 23F);
            AutoScaleMode = AutoScaleMode.Font;
            BackColor = Color.WhiteSmoke;
            ClientSize = new Size(1924, 984);
            Controls.Add(sidebar);
            Controls.Add(HoaDon);
            Controls.Add(title);
            Font = new Font("Arial", 12F, FontStyle.Regular, GraphicsUnit.Point, 0);
            ForeColor = SystemColors.ControlDark;
            Margin = new Padding(2, 3, 2, 3);
            Name = "ThemHH";
            Text = "ThemHH";
            WindowState = FormWindowState.Maximized;
            Load += ThemHH_Load;
            HoaDon.ResumeLayout(false);
            HoaDon.PerformLayout();
            title.ResumeLayout(false);
            title.PerformLayout();
            sidebar.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)logo).EndInit();
            ResumeLayout(false);
        }




        #endregion

        private Microsoft.Data.SqlClient.SqlCommand sqlCommand1;
        private Button btHuy;
        private Panel HoaDon;
        private Button btHT;
        private TextBox txtTenHH;
        private Label label2;
        private TextBox txtMaHH;
        private Label label1;
        private TextBox txtHangHoa;
        private Panel title;
        private TextBox txtLoai;
        private Label label9;
        private TextBox txtDonVi;
        private Label label8;
        private TextBox txtGia;
        private Label label6;
        private TextBox txtSL;
        private Label label5;
        private TextBox textBox7;
        private Panel sidebar;
        private Button btNH;
        private Button btBH;
        private Button btCNNCC;
        private Button btCNKH;
        private Button btHDN;
        private Button btHDB;
        private Button btNo;
        private Button btHoaDon;
        private Button btNCC;
        private Button btKH;
        private Button btHangHoa;
        private PictureBox logo;
    }
}