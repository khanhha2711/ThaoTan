﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;

namespace final
{
    public partial class ThemHH : Form
    {
        string scon = "Data Source=PC;Initial Catalog=THAOTAN;Integrated Security=True;Encrypt=False;Trust Server Certificate=True";

        public ThemHH()
        {
            InitializeComponent();
        }
        private void ThemHH_Load(object sender, EventArgs e)
        {
            string tenBang = "HHDV"; // Thay đổi tên bảng theo nhu cầu

            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (SqlCommand command = new SqlCommand("SELECT dbo.TaoMaMoi(@TenBang) AS NewMaHH", connection))
                {
                    command.Parameters.AddWithValue("@TenBang", tenBang);
                    connection.Open();
                    SqlDataReader reader = command.ExecuteReader();

                    if (reader.Read())
                    {
                        // Lấy mã hàng hóa mới và hiển thị trong TextBox
                        txtMaHH.Text = reader["NewMaHH"].ToString();
                        txtMaHH.Enabled = false;
                    }
                }
            }

        }

        //menu
        private void btBH_Click(object sender, EventArgs e)
        {
            this.Close();
            BanHang banHang = new BanHang();
            banHang.Show();
        }

        private void btNH_Click(object sender, EventArgs e)
        {
            this.Close();
            NhapHang nhapHang = new NhapHang();
            nhapHang.Show();
        }
        private void btHangHoa_Click(object sender, EventArgs e)
        {
            this.Close();
            frmHangHoa frm = new frmHangHoa();
            frm.Show();
        }

        private void btKH_Click(object sender, EventArgs e)
        {
            this.Close();
            KhachHang KhacHang = new KhachHang();
            KhacHang.Show();
        }

        private void btNCC_Click(object sender, EventArgs e)
        {
            this.Close();
            NCC nCC = new NCC();
            nCC.Show();
        }
        private void btHoaDon_MouseHover(object sender, EventArgs e)
        {
            btHDN.Visible = true;
            btHDB.Visible = true;
        }

        private void btHDB_Click(object sender, EventArgs e)
        {
            this.Close();
            HDBH hDBH = new HDBH();
            hDBH.Show();
        }

        private void btHDN_Click(object sender, EventArgs e)
        {
            this.Close();
            HDNH dnH = new HDNH();
            dnH.Show();
        }

        private void btNo_MouseHover(object sender, EventArgs e)
        {
            btCNKH.Visible = true;
            btCNNCC.Visible = true;
        }

        private void btCNKH_Click(object sender, EventArgs e)
        {
            this.Close();
            NoKH noKH = new NoKH();
            noKH.Show();
        }

        private void btCNNCC_Click(object sender, EventArgs e)
        {
            this.Close();
            NoNCC NoNCC = new NoNCC();
            NoNCC.Show();
        }
        //menu//

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        //button//
        private void btHuy_Click(object sender, EventArgs e)
        {
            txtTenHH.Clear();
            txtDonVi.Clear();
            txtGia.Clear();
            txtLoai.Clear();
            txtSL.Clear();
        }

        private void btHT_Click(object sender, EventArgs e)
        {
            DialogResult result = MessageBox.Show("Bạn có chắc chắn muốn cập nhật thông tin không?", "Xác nhận", MessageBoxButtons.YesNo);
            if (result == DialogResult.Yes)
            {
                if (KtraData())
                {
                    // Gọi thủ tục lưu trữ để cập nhật dữ liệu
                    InsertData();
                }
               
            }

        }
        //button//
        private void InsertData()
        {
            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (SqlCommand command = new SqlCommand("pInsertHH", connection))
                {
                    command.CommandType = System.Data.CommandType.StoredProcedure;

                    // Thêm các tham số
                    command.Parameters.AddWithValue("@MaHH", txtMaHH.Text);
                    command.Parameters.AddWithValue("@TenHH", txtTenHH.Text);
                    command.Parameters.AddWithValue("@Loai", txtLoai.Text);
                    command.Parameters.AddWithValue("@DonVi", txtDonVi.Text);
                    command.Parameters.AddWithValue("@GiaBan", Convert.ToDecimal(txtGia.Text));
                    command.Parameters.AddWithValue("@SoLuong", Convert.ToDecimal(txtSL.Text));

                    try
                    {
                        connection.Open();
                        int rowsAffected = command.ExecuteNonQuery();
                        if (rowsAffected > 0)
                        {
                            MessageBox.Show("Thêm thành công!", "Thông báo");
                        }
                        else
                        {
                            MessageBox.Show("Không thành công hãy thử lại", "Thông báo");
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show("Lỗi: " + ex.Message);
                    }
                }
            }
        }

        private bool CheckTenHHDVExists(string tenHHDV)
        {
            bool exists = false;

            using (SqlConnection connection = new SqlConnection(scon))
            {
                using (var command = new SqlCommand("pSrTHH", connection))
                {
                    command.CommandType = CommandType.StoredProcedure;

                    // Thêm tham số vào thủ tục
                    command.Parameters.Add(new SqlParameter("@TenHH", tenHHDV));

                    // Tham số đầu ra
                    var existsParameter = new SqlParameter("@ret", SqlDbType.Bit)
                    {
                        Direction = ParameterDirection.Output
                    };
                    command.Parameters.Add(existsParameter);

                    // Mở kết nối và thực thi thủ tục
                    connection.Open();
                    command.ExecuteNonQuery();

                    // Lấy giá trị từ tham số đầu ra
                    exists = (bool)existsParameter.Value;
                }
            }

            return exists;
        }

        private bool KtraData()
        {
            string maHHDV = txtMaHH.Text;
            string tenHHDV = txtTenHH.Text;
            decimal gia = decimal.Parse(txtGia.Text);
            decimal soLuong = decimal.Parse(txtSL.Text);
            string donvi = txtDonVi.Text;
            string loai = txtLoai.Text;


            // Kiểm tra sự tồn tại của mã hàng hóa
            if (CheckTenHHDVExists(tenHHDV))
            {
                MessageBox.Show("Hàng hóa đã tồn tại trong cơ sở dữ liệu.", "Thông báo");
                return false;
            }


            // Kiểm tra xem các trường không được để trống
            if (string.IsNullOrWhiteSpace(txtTenHH.Text) ||
                string.IsNullOrWhiteSpace(txtLoai.Text) ||
                string.IsNullOrWhiteSpace(txtDonVi.Text) ||
                string.IsNullOrWhiteSpace(txtGia.Text) ||
                string.IsNullOrWhiteSpace(txtSL.Text))
            {
                MessageBox.Show("Vui lòng điền đầy đủ thông tin.", "Thông báo");
                return false;
            }


            // Kiểm tra giá bán và số lượng
            if (Convert.ToDecimal(gia) <= 0)
            {
                MessageBox.Show("Giá bán phải lớn hơn 0.", "Thông báo");
                return false;
            }

            if (Convert.ToDecimal(soLuong) < 0)
            {
                MessageBox.Show("Số lượng không thể âm.", "Thông báo");
                return false;
            }

            return true;
        }

        private void txtGia_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLoai_TextChanged(object sender, EventArgs e)
        {


        }

        private void txtTenHH_TextChanged(object sender, EventArgs e)
        {


        }

        private void txtTenHH_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string tenHHDV = txtTenHH.Text;
                if (CheckTenHHDVExists(tenHHDV))
                {
                    MessageBox.Show("Hàng hóa đã tồn tại trong cơ sở dữ liệu.", "Thông báo");
                }
            }

        }

        private void txtMaHH_TextChanged(object sender, EventArgs e)
        {

        }

        private void back_Click(object sender, EventArgs e)
        {
            this.Close();
            frmHangHoa frmHangHoa = new frmHangHoa();
            frmHangHoa.Show();
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }

}
