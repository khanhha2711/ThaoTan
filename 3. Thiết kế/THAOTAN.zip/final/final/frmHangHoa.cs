﻿using System.Data;
using System.Windows.Forms;
using Microsoft.Data.SqlClient;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;
using static final.BanHang;

namespace final
{
    public partial class frmHangHoa : Form
    {
        string scon = "Data Source=PC;Initial Catalog=THAOTAN;Integrated Security=True;Encrypt=False;Trust Server Certificate=True";
        public frmHangHoa()
        {
            InitializeComponent();
            
        }
        private void frmHangHoa_Load(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(scon);
            try
            {
                con.Open();
                string squery = "SELECT * FROM HHDV WHERE Loai <> 'X'";
                SqlDataAdapter adapter = new SqlDataAdapter(squery, con);
                DataSet ds = new DataSet();
                adapter.Fill(ds, "HHDV");
                data.DataSource = ds.Tables["HHDV"];
                data.Columns["MaHHDV"].HeaderText = "Mã HHDV"; // Thay "ID" bằng tên cột thực tế
                data.Columns["TenHHDV"].HeaderText = "Tên HHDV"; // Thay "Name" bằng tên cột thực tế
                data.Columns["Loai"].HeaderText= "Loại";
                data.Columns["DonVi"].HeaderText = "Đơn vị";
                data.Columns["GiaBan"].HeaderText = "Giá bán";
                data.Columns["SLHHDV"].HeaderText = "Số lượng";
             
            }
            catch (Exception ex)
            {

                MessageBox.Show("Xay ra loi DB");
            }
            finally
            {
                con.Close(); // Đảm bảo kết nối được đóng trong mọi trường hợp
            }
        }
        //menu
        private void BH_click(object sender, EventArgs e)
        {
            this.Close();
            BanHang banHang = new BanHang();
            banHang.Show();
        }

        private void NH_click(object sender, EventArgs e)
        {
            this.Close();
            NhapHang nhapHang = new NhapHang();
            nhapHang.Show();

        }

        private void btHangHoa_Click(object sender, EventArgs e)
        {

        }

        private void btKH_Click(object sender, EventArgs e)
        {
            this.Close();
            KhachHang KhacHang = new KhachHang();
            KhacHang.Show();
        }

        private void btNCC_Click(object sender, EventArgs e)
        {
            this.Close();
            NCC nCC = new NCC();
            nCC.Show();
        }
        private void btHoaDon_MouseHover(object sender, EventArgs e)
        {
            btHDN.Visible = true;
            btBan.Visible = true;
        }

        private void btHDB_Click_2(object sender, EventArgs e)
        {
            this.Close();
            HDBH hDBH = new HDBH();
            hDBH.Show();
        }

        private void btHDN_Click(object sender, EventArgs e)
        {
            this.Close();
            HDNH dnH = new HDNH();
            dnH.Show();
        }

        private void btNo_MouseHover(object sender, EventArgs e)
        {
            btCNKH.Visible = true;
            btCNNCC.Visible = true;
        }

        private void btCNKH_Click(object sender, EventArgs e)
        {
            this.Close();
            NoKH noKH = new NoKH();
            noKH.Show();
        }

        private void btCNNCC_Click(object sender, EventArgs e)
        {
            this.Close();
            NoNCC NoNCC = new NoNCC();
            NoNCC.Show();
        }
        //menu//

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void data_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void numericUpDown1_ValueChanged(object sender, EventArgs e)
        {

        }

        private void data_CellContentClick_1(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void data_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                // Lấy dữ liệu từ hàng đã chọn
                var selectedRow = data.Rows[e.RowIndex];
                string maHHDV = selectedRow.Cells["MaHHDV"].Value.ToString();
                string tenHHDV = selectedRow.Cells["TenHHDV"].Value.ToString();
                string loai = selectedRow.Cells["Loai"].Value.ToString();
                string donVi = selectedRow.Cells["DonVi"].Value.ToString();
                decimal giaBan = Convert.ToDecimal(selectedRow.Cells["GiaBan"].Value);
                int slHHDV = Convert.ToInt32(selectedRow.Cells["SLHHDV"].Value);

                // Tạo và hiển thị Form2 để chỉnh sửa thông tin
                EditHH editHH = new EditHH(maHHDV, tenHHDV, loai, donVi, giaBan, slHHDV);
                editHH.Show();
            }

        }


        private void txtMaHH_TextChanged(object sender, EventArgs e)
        {
            string srMaHH = txtMaHH.Text;

        }

        private void txtMaHH_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string searchValue = txtMaHH.Text.Trim();

                // Kiểm tra nếu DataGridView có dữ liệu
                if (data.Rows.Count > 0)
                {
                    bool found = false; // Biến để theo dõi xem có tìm thấy hay không

                    // Tìm kiếm trong từng hàng
                    foreach (DataGridViewRow row in data.Rows)
                    {
                        // Kiểm tra nếu hàng không phải là hàng tiêu đề
                        if (row.Cells["MaHHDV"].Value != null && row.Cells["MaHHDV"].Value.ToString().ToLower().Contains(searchValue.ToLower()))
                        {
                            // Chọn hàng tìm thấy
                            row.Selected = true;
                            data.CurrentCell = row.Cells[0]; // Chọn ô đầu tiên của hàng
                            found = true; // Đánh dấu là đã tìm thấy
                            break; // Dừng vòng lặp khi tìm thấy
                        }
                    }

                    if (!found)
                    {
                        // Nếu không tìm thấy
                        MessageBox.Show("Không tìm thấy thông tin hàng", "Kết quả tìm kiếm", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Không có dữ liệu để tìm kiếm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                // Xóa nội dung trong TextBox sau khi tìm kiếm
                txtMaHH.Text = string.Empty;
            }
        }

        private void txtTenHH_TextChanged(object sender, EventArgs e)
        {
            

        }

        private void txtTenHH_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode == Keys.Enter)
            {
                string searchValue = txtTenHH.Text.Trim();

                // Kiểm tra nếu DataGridView có dữ liệu
                if (data.Rows.Count > 0)
                {
                    bool found = false; // Biến để theo dõi xem có tìm thấy hay không

                    // Tìm kiếm trong từng hàng
                    foreach (DataGridViewRow row in data.Rows)
                    {
                        // Kiểm tra nếu hàng không phải là hàng tiêu đề
                        if (row.Cells["TenHHDV"].Value != null && row.Cells["TenHHDV"].Value.ToString().ToLower().Contains(searchValue.ToLower()))
                        {
                            // Chọn hàng tìm thấy
                            row.Selected = true;
                            data.CurrentCell = row.Cells[0]; // Chọn ô đầu tiên của hàng
                            found = true; // Đánh dấu là đã tìm thấy
                            break; // Dừng vòng lặp khi tìm thấy
                        }
                    }

                    if (!found)
                    {
                        // Nếu không tìm thấy
                        MessageBox.Show("Không tìm thấy thông tin hàng", "Kết quả tìm kiếm", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Không có dữ liệu để tìm kiếm.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }

                // Xóa nội dung trong TextBox sau khi tìm kiếm
                txtTenHH.Text = string.Empty;
            }

        }

        private void btInsert_Click(object sender, EventArgs e)
        {
            this.Close();
            ThemHH them = new ThemHH();
            them.Show();
        }

       

        
    }
}
